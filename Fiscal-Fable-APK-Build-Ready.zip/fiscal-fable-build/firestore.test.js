const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_cfo_01";
const BOB_UID = "bob_cfo_02";
const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validClientPayload(uid) {
  const now = new Date(Date.now() - 5000);
  return {
    userId: uid,
    companyName: "Sahyadri Precision Pvt Ltd",
    industry: "Industrial Manufacturing",
    country: "India",
    currency: "INR",
    financialYear: "FY 2025-26",
    accountingPeriod: "Q2 (Jul-Sep 2025)",
    accountingStandard: "Ind AS (Schedule III)",
    businessProfile: "Mid-market precision CNC components supplier in Pune.",
    contactName: "Aarav Deshmukh",
    contactEmail: "aarav@sahyadri.in",
    contactPhone: "+91 9820012345",
    status: "ACTIVE",
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any client data", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("clients").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("clients")
      .doc("client_1")
      .set(validClientPayload(ALICE_UID))
  );
});

test("Client CRUD, cross-user isolation, and @DocumentId id-key guard", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  const clientRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("clients")
    .doc("client_1");

  await assertSucceeds(clientRef.set(validClientPayload(ALICE_UID)));

  // Reject ghost 'id' field
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("clients")
      .doc("client_2")
      .set({ ...validClientPayload(ALICE_UID), id: "client_2" })
  );

  // Reject cross-user read and write
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("clients").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("clients")
      .doc("client_1")
      .update({ companyName: "Hijacked Corp" })
  );

  // Valid partial update by Alice
  await assertSucceeds(
    clientRef.update({
      accountingPeriod: "Q3 (Oct-Dec 2025)",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Document, ExtractedFigure validation, Analysis, Forecast & Advisory parity", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const clientRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("clients")
    .doc("client_1");

  const now = new Date(Date.now() - 5000);

  // Orphaned document write fails before client exists
  await assertFails(
    clientRef.collection("documents").doc("doc_1").set({
      userId: ALICE_UID,
      clientId: "client_1",
      fileName: "pnl_q2.pdf",
      mimeType: "application/pdf",
      documentType: "PNL",
      reportingPeriod: "Q2 FY26",
      currency: "INR",
      unitScale: "LAKHS",
      extractionStatus: "NEEDS_VALIDATION",
      ocrUsed: true,
      pageCount: 2,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(clientRef.set(validClientPayload(ALICE_UID)));

  await assertSucceeds(
    clientRef.collection("documents").doc("doc_1").set({
      userId: ALICE_UID,
      clientId: "client_1",
      fileName: "pnl_q2.pdf",
      mimeType: "application/pdf",
      documentType: "PNL",
      reportingPeriod: "Q2 FY26",
      currency: "INR",
      unitScale: "LAKHS",
      extractionStatus: "NEEDS_VALIDATION",
      ocrUsed: true,
      pageCount: 2,
      sourceSummary: "Extracted Statement of Profit and Loss (Ind AS 1)",
      missingFieldsNote: "None",
      createdAt: now,
      updatedAt: now,
    })
  );

  // ExtractedFigure create & human validation toggle
  const figRef = clientRef.collection("extractedFigures").doc("fig_1");
  await assertSucceeds(
    figRef.set({
      userId: ALICE_UID,
      clientId: "client_1",
      documentId: "doc_1",
      documentName: "pnl_q2.pdf",
      reportingPeriod: "Q2 FY26",
      statementCategory: "PNL",
      fieldKey: "revenue",
      label: "Revenue from Operations",
      indAsReference: "Ind AS 115 · Schedule III",
      amount: 1450.5,
      currency: "INR",
      sourceCitation: "pnl_q2.pdf · Page 1, Line 1",
      confidence: "HIGH",
      ambiguityNote: "",
      validated: false,
      validatedBy: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    figRef.update({
      amount: 1455.0,
      validated: true,
      validatedBy: "Kavish (CFO)",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Forecast with native Maps array
  await assertSucceeds(
    clientRef.collection("forecasts").doc("fc_1").set({
      userId: ALICE_UID,
      clientId: "client_1",
      reportingPeriod: "Q2 FY26",
      horizonMonths: 6,
      revenueGrowthExpectedPct: 8.5,
      cogsPctOfRevenue: 58.0,
      opexGrowthPct: 4.0,
      targetDsoDays: 42.0,
      monthlyFixedCosts: 22.0,
      breakEvenMonthlyRevenue: 52.38,
      assumptionsSummary: "Based on validated Q2 FY26 Ind AS run-rate.",
      conservativeSummary: "Conservative case assumes 3% growth.",
      expectedSummary: "Expected case assumes 8.5% growth.",
      optimisticSummary: "Optimistic case assumes 14% growth.",
      projections: [
        {
          monthLabel: "M1",
          conservativeCash: 18.0,
          expectedCash: 22.5,
          optimisticCash: 27.0,
          expectedRevenue: 495.0,
          expectedExpense: 420.0,
        },
      ],
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("CFO Report approval lifecycle locks approved reports and keeps auditLogs immutable", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const clientRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("clients")
    .doc("client_1");

  const now = new Date(Date.now() - 5000);
  await assertSucceeds(clientRef.set(validClientPayload(ALICE_UID)));

  const reportRef = clientRef.collection("reports").doc("rep_1");
  await assertSucceeds(
    reportRef.set({
      userId: ALICE_UID,
      clientId: "client_1",
      clientName: "Sahyadri Precision Pvt Ltd",
      reportType: "Quarterly CFO Report",
      reportTitle: "Q2 FY26 CFO Management Pack",
      reportingPeriod: "Q2 FY26",
      currency: "INR",
      executiveSummary: "Strong EBITDA expansion driven by raw material discipline.",
      financialObservations: "Gross margin expanded 180 bps.",
      riskIdentification: "Receivable days rose to 58 days.",
      recommendationsText: "Enforce 45-day credit terms.",
      managementActionPoints: "Weekly AR ageing review.",
      conclusion: "Healthy liquidity with selective working capital tightening.",
      reviewStatus: "DRAFT",
      cfoReviewNotes: "",
      approvedBy: "",
      approvedByEmail: "",
      approvedAtLabel: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Edit draft
  await assertSucceeds(
    reportRef.update({
      reviewStatus: "IN_REVIEW",
      cfoReviewNotes: "Ready for partner sign-off.",
      updatedAt: new Date(Date.now() - 2000),
    })
  );

  // Approve report
  await assertSucceeds(
    reportRef.update({
      reviewStatus: "APPROVED",
      cfoReviewNotes: "Approved for client delivery.",
      approvedBy: "Kavish CFO",
      approvedByEmail: "kavish2728@gmail.com",
      approvedAtLabel: "19 Nov 2026, 06:00 IST",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal lock: cannot edit or delete APPROVED report
  await assertFails(
    reportRef.update({
      executiveSummary: "Tampered after approval",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(reportRef.delete());

  // Audit log creation succeeds; update/delete fail
  const logRef = clientRef.collection("auditLogs").doc("log_1");
  await assertSucceeds(
    logRef.set({
      userId: ALICE_UID,
      clientId: "client_1",
      reportId: "rep_1",
      reportTitle: "Q2 FY26 CFO Management Pack",
      action: "APPROVED",
      actorName: "Kavish CFO",
      actorEmail: "kavish2728@gmail.com",
      notes: "Signed off for export.",
      createdAt: now,
    })
  );
  await assertFails(logRef.update({ notes: "Altered log" }));
  await assertFails(logRef.delete());
});
