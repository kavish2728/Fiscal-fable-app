package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CfoProfileRoomEntity::class,
        ClientRoomEntity::class,
        FinancialDocumentRoomEntity::class,
        ExtractedFigureRoomEntity::class,
        FinancialAnalysisRoomEntity::class,
        FpaForecastRoomEntity::class,
        BusinessAdvisoryRoomEntity::class,
        CfoReportRoomEntity::class,
        ApprovalAuditLogRoomEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class FiscalFableDatabase : RoomDatabase() {
    abstract fun cfoDao(): CfoDao

    companion object {
        @Volatile
        private var INSTANCE: FiscalFableDatabase? = null

        fun getInstance(context: Context): FiscalFableDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FiscalFableDatabase::class.java,
                    "fiscal_fable_cfo.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
