package com.example.core

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

object IndAsFormatter {

    private val indianLocale = Locale("en", "IN")

    fun currencySymbol(currency: String): String = when (currency.uppercase(Locale.ROOT)) {
        "INR" -> "₹"
        "USD" -> "$"
        "GBP" -> "£"
        "EUR" -> "€"
        "AED" -> "AED "
        "SGD" -> "S$"
        else -> "$currency "
    }

    /**
     * Formats an amount assuming values stored in Lakhs when useLakhsNotation is true for INR,
     * or full Indian grouping otherwise.
     */
    fun formatMoney(
        amountInBaseUnits: Double,
        currency: String = "INR",
        preferLakhsCrores: Boolean = true
    ): String {
        val sym = currencySymbol(currency)
        val absVal = abs(amountInBaseUnits)
        val sign = if (amountInBaseUnits < 0) "-" else ""

        if (currency.equals("INR", ignoreCase = true) && preferLakhsCrores) {
            return when {
                absVal >= 10_000_000.0 -> {
                    val crores = absVal / 10_000_000.0
                    "$sign$sym${String.format(indianLocale, "%.2f", crores)} Cr"
                }
                absVal >= 100_000.0 -> {
                    val lakhs = absVal / 100_000.0
                    "$sign$sym${String.format(indianLocale, "%.2f", lakhs)} L"
                }
                else -> {
                    val nf = NumberFormat.getNumberInstance(indianLocale).apply {
                        maximumFractionDigits = 2
                        minimumFractionDigits = 0
                    }
                    "$sign$sym${nf.format(absVal)}"
                }
            }
        }

        return when {
            absVal >= 1_000_000_000.0 -> "$sign$sym${String.format(Locale.US, "%.2fB", absVal / 1_000_000_000.0)}"
            absVal >= 1_000_000.0 -> "$sign$sym${String.format(Locale.US, "%.2fM", absVal / 1_000_000.0)}"
            else -> {
                val nf = NumberFormat.getNumberInstance(Locale.US).apply {
                    maximumFractionDigits = 2
                    minimumFractionDigits = 0
                }
                "$sign$sym${nf.format(absVal)}"
            }
        }
    }

    fun formatCompactNumber(value: Double, currency: String = "INR"): String {
        val sym = currencySymbol(currency)
        val absVal = abs(value)
        val sign = if (value < 0) "-" else ""
        return if (currency.equals("INR", ignoreCase = true)) {
            when {
                absVal >= 10_000_000.0 -> "$sign$sym${String.format(indianLocale, "%.1f", absVal / 10_000_000.0)}Cr"
                absVal >= 100_000.0 -> "$sign$sym${String.format(indianLocale, "%.1f", absVal / 100_000.0)}L"
                absVal >= 1_000.0 -> "$sign$sym${String.format(indianLocale, "%.1f", absVal / 1_000.0)}K"
                else -> "$sign$sym${String.format(indianLocale, "%.0f", absVal)}"
            }
        } else {
            when {
                absVal >= 1_000_000.0 -> "$sign$sym${String.format(Locale.US, "%.1f", absVal / 1_000_000.0)}M"
                absVal >= 1_000.0 -> "$sign$sym${String.format(Locale.US, "%.1f", absVal / 1_000.0)}K"
                else -> "$sign$sym${String.format(Locale.US, "%.0f", absVal)}"
            }
        }
    }

    fun formatPct(value: Double): String = String.format(Locale.US, "%.1f%%", value)

    fun formatRatio(value: Double, suffix: String = "x"): String =
        String.format(Locale.US, "%.2f%s", value, suffix)

    fun formatDays(value: Double): String = String.format(Locale.US, "%.0f d", value)
}
