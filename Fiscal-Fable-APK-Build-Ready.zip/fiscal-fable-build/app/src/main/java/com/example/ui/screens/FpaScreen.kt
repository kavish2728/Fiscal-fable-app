package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.IndAsFormatter
import com.example.data.model.ClientEntity
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FpaForecastRecord
import com.example.data.model.FpaScenario
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.FpaCashFlowChart
import com.example.ui.components.KpiTile
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import kotlin.math.roundToInt

@Composable
fun FpaScreen(
    activeClient: ClientEntity?,
    latestAnalysis: FinancialAnalysisRecord?,
    forecasts: List<FpaForecastRecord>,
    preferLakhs: Boolean,
    onGenerateForecast: (Int, Double, Double, Double, Double) -> Unit
) {
    var horizonMonths by remember { mutableIntStateOf(6) }
    var expectedGrowth by remember { mutableDoubleStateOf(10.0) }
    var cogsPct by remember { mutableDoubleStateOf(58.0) }
    var opexGrowth by remember { mutableDoubleStateOf(5.0) }
    var targetDso by remember { mutableDoubleStateOf(45.0) }
    var selectedScenario by remember { mutableStateOf(FpaScenario.EXPECTED) }

    val latestForecast = forecasts.maxByOrNull { it.createdAtMillis }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Cash Flow & FP&A Agent",
                subtitle = "3-scenario forecasting, budget vs actual & break-even planning",
                badge = "${forecasts.size} Models"
            )
        }

        if (activeClient == null || latestAnalysis == null) {
            item {
                EmptyVaultCard(
                    title = "Baseline Financial Analysis Required",
                    description = "Validate extracted documents and complete Financial Analysis first so FP&A forecasts build strictly from verified Ind AS actuals."
                )
            }
        } else {
            item {
                FableCard {
                    Text("Forecast Driver Assumptions", style = MaterialTheme.typography.titleMedium)
                    Text("Horizon: $horizonMonths Months", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(6, 12, 18).forEach { m ->
                            FilterChip(
                                selected = horizonMonths == m,
                                onClick = { horizonMonths = m },
                                label = { Text("${m}M") }
                            )
                        }
                    }

                    Text("Expected Annual Revenue Growth: ${expectedGrowth.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = expectedGrowth.toFloat(),
                        onValueChange = { expectedGrowth = it.toDouble() },
                        valueRange = -10f..40f
                    )

                    Text("COGS % of Revenue: ${cogsPct.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = cogsPct.toFloat(),
                        onValueChange = { cogsPct = it.toDouble() },
                        valueRange = 20f..85f
                    )

                    Text("OpEx Escalation: ${opexGrowth.roundToInt()}% | Target DSO: ${targetDso.roundToInt()} d", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = targetDso.toFloat(),
                        onValueChange = { targetDso = it.toDouble() },
                        valueRange = 15f..120f
                    )

                    Button(
                        onClick = {
                            onGenerateForecast(horizonMonths, expectedGrowth, cogsPct, opexGrowth, targetDso)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("generate_fpa_button")
                    ) {
                        Icon(Icons.Filled.Timeline, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Run 3-Scenario FP&A Model")
                    }
                }
            }

            if (latestForecast != null) {
                val ccy = activeClient.currency
                val pts = latestForecast.parsedProjections()
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FpaScenario.entries.forEach { sc ->
                            FilterChip(
                                selected = selectedScenario == sc,
                                onClick = { selectedScenario = sc },
                                label = { Text(sc.label) }
                            )
                        }
                    }
                }

                item {
                    FableCard {
                        FpaCashFlowChart(
                            points = pts,
                            currency = ccy,
                            highlightedScenario = selectedScenario.label
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KpiTile(
                            label = "Break-Even Rev / Mo",
                            value = IndAsFormatter.formatMoney(latestForecast.breakEvenMonthlyRevenue, ccy, preferLakhs),
                            caption = "Fixed: ${IndAsFormatter.formatCompactNumber(latestForecast.monthlyFixedCosts, ccy)}/mo",
                            tone = BadgeTone.INFO,
                            modifier = Modifier.weight(1f)
                        )
                        val endCash = pts.lastOrNull()?.let {
                            when (selectedScenario) {
                                FpaScenario.CONSERVATIVE -> it.conservativeCash
                                FpaScenario.EXPECTED -> it.expectedCash
                                FpaScenario.OPTIMISTIC -> it.optimisticCash
                            }
                        } ?: 0.0
                        KpiTile(
                            label = "Ending Cash (${selectedScenario.label})",
                            value = IndAsFormatter.formatMoney(endCash, ccy, preferLakhs),
                            caption = "M+${latestForecast.horizonMonths} Forecast",
                            tone = BadgeTone.POSITIVE,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    FableCard {
                        Text("Scenario & Assumptions Commentary", style = MaterialTheme.typography.titleMedium)
                        val summary = when (selectedScenario) {
                            FpaScenario.CONSERVATIVE -> latestForecast.conservativeSummary
                            FpaScenario.EXPECTED -> latestForecast.expectedSummary
                            FpaScenario.OPTIMISTIC -> latestForecast.optimisticSummary
                        }
                        Text(summary, style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        Text("Explicit Model Assumptions (Forecast vs Actuals)", style = MaterialTheme.typography.titleSmall)
                        Text(
                            latestForecast.assumptionsSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                item {
                    FableCard {
                        Text("Budget vs Actual & Forecast Schedule", style = MaterialTheme.typography.titleMedium)
                        pts.forEach { p ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(p.monthLabel, style = MaterialTheme.typography.labelSmall)
                                    StatusBadge(
                                        text = if (p.forecastFlag) "FCST" else "ACT",
                                        tone = if (p.forecastFlag) BadgeTone.VIOLET else BadgeTone.POSITIVE
                                    )
                                }
                                val cashVal = when (selectedScenario) {
                                    FpaScenario.CONSERVATIVE -> p.conservativeCash
                                    FpaScenario.EXPECTED -> p.expectedCash
                                    FpaScenario.OPTIMISTIC -> p.optimisticCash
                                }
                                Text(
                                    "Rev ${IndAsFormatter.formatCompactNumber(p.expectedRevenue, ccy)} · Cash ${IndAsFormatter.formatCompactNumber(cashVal, ccy)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
