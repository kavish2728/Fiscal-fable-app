package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.CfoProfile
import com.example.ui.components.BadgeTone
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@Composable
fun SettingsScreen(
    cfoProfile: CfoProfile,
    preferLakhsCrores: Boolean,
    onToggleLakhsCrores: (Boolean) -> Unit,
    onSaveProfile: (String, String) -> Unit
) {
    var partnerName by remember { mutableStateOf(cfoProfile.partnerName) }
    var partnerTitle by remember { mutableStateOf(cfoProfile.partnerTitle) }

    LaunchedEffect(cfoProfile) {
        partnerName = cfoProfile.partnerName
        partnerTitle = cfoProfile.partnerTitle
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Workspace Settings",
                subtitle = "On-device CFO partner profile & Ind AS standards",
                badge = "Device Vault"
            )
        }

        item {
            FableCard {
                Text("On-Device CFO Partner Profile", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Stored privately on this phone only. Used for CFO approval attribution and immutable audit logs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = partnerName,
                    onValueChange = { partnerName = it },
                    label = { Text("CFO Partner Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("cfo_partner_name_input")
                )
                OutlinedTextField(
                    value = partnerTitle,
                    onValueChange = { partnerTitle = it },
                    label = { Text("Designation / Practice Role") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("cfo_partner_title_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadge("Private On-Device SQLite", BadgeTone.POSITIVE)
                    StatusBadge("App Check Attested AI", BadgeTone.INFO)
                }
                Button(
                    onClick = { onSaveProfile(partnerName, partnerTitle) },
                    modifier = Modifier.fillMaxWidth().testTag("save_cfo_profile_button")
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save CFO Profile")
                }
            }
        }

        item {
            FableCard {
                Text("Indian Accounting Standards (Ind AS) Defaults", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("INR Lakhs / Crores Formatting", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Display Indian currency figures in Lakhs (₹ L) and Crores (₹ Cr) per Schedule III.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = preferLakhsCrores,
                        onCheckedChange = onToggleLakhsCrores
                    )
                }
                Text(
                    "Default Financial Year: April 1 – March 31 (Ind AS / Companies Act, 2013)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            FableCard {
                Text("AI Safety & Compliance Guardrails", style = MaterialTheme.typography.titleMedium)
                Text("• No fabricated figures: deterministic math runs strictly on validated figures.", style = MaterialTheme.typography.bodySmall)
                Text("• Mandatory human validation gate before calculations.", style = MaterialTheme.typography.bodySmall)
                Text("• Mandatory CFO approval lock before PDF/Excel report delivery.", style = MaterialTheme.typography.bodySmall)
                Text("• Strict per-client on-device Room SQLite isolation (no login required).", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
