package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ActionStatus
import com.example.data.model.AdvisoryCategory
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.ClientEntity
import com.example.data.model.FinancialAnalysisRecord
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvisoryScreen(
    activeClient: ClientEntity?,
    latestAnalysis: FinancialAnalysisRecord?,
    advisories: List<BusinessAdvisoryItem>,
    onGenerateAdvisories: () -> Unit,
    onUpdateStatus: (BusinessAdvisoryItem, String) -> Unit
) {
    var filterCategory by remember { mutableStateOf<String?>(null) }
    val filtered = remember(advisories, filterCategory) {
        if (filterCategory == null) advisories else advisories.filter { it.category == filterCategory }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Business Advisory Agent",
                subtitle = "Evidence-backed CFO strategic recommendations & risk controls",
                badge = "${advisories.size} Items"
            )
        }

        if (activeClient == null || latestAnalysis == null) {
            item {
                EmptyVaultCard(
                    title = "Financial Analysis Required",
                    description = "Run Ind AS Financial Analysis on validated figures first so the Business Advisor Agent grounds every recommendation in verified evidence."
                )
            }
        } else {
            item {
                Button(
                    onClick = onGenerateAdvisories,
                    modifier = Modifier.fillMaxWidth().testTag("generate_advisories_button")
                ) {
                    Icon(Icons.Filled.Lightbulb, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Generate CFO Strategic Advisories")
                }
            }

            if (advisories.isNotEmpty()) {
                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = filterCategory == null,
                            onClick = { filterCategory = null },
                            label = { Text("All (${advisories.size})") }
                        )
                        AdvisoryCategory.entries.forEach { cat ->
                            val cnt = advisories.count { it.category == cat.name }
                            if (cnt > 0) {
                                FilterChip(
                                    selected = filterCategory == cat.name,
                                    onClick = { filterCategory = cat.name },
                                    label = { Text("${cat.displayName} ($cnt)") }
                                )
                            }
                        }
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyVaultCard(
                        title = "No Advisories Generated Yet",
                        description = "Tap the button above to diagnose margin levers, working capital bottlenecks, Ind AS risks, and funding options."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { item ->
                    FableCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatusBadge(
                                text = item.category.replace('_', ' '),
                                tone = BadgeTone.VIOLET
                            )
                            StatusBadge(
                                text = "Priority: ${item.priority}",
                                tone = when (item.priority) {
                                    "CRITICAL" -> BadgeTone.RISK
                                    "HIGH" -> BadgeTone.CAUTION
                                    "MEDIUM" -> BadgeTone.INFO
                                    else -> BadgeTone.NEUTRAL
                                }
                            )
                        }

                        AdvisoryField("1. Identified Problem", item.identifiedProblem, bold = true)
                        AdvisoryField("2. Supporting Financial Evidence", item.supportingEvidence)
                        AdvisoryField("3. Business Impact", item.businessImpact)
                        AdvisoryField("4. Recommended Action", item.recommendedAction)
                        AdvisoryField("5. Expected Outcome", item.expectedOutcome)
                        AdvisoryField("6. Relevant Assumptions", item.relevantAssumptions)

                        HorizontalDivider()
                        Text("7. Action Execution Status", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionStatus.entries.forEach { st ->
                                FilterChip(
                                    selected = item.actionStatus == st.name,
                                    onClick = { onUpdateStatus(item, st.name) },
                                    label = { Text(st.name.replace('_', ' '), style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdvisoryField(label: String, body: String, bold: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
