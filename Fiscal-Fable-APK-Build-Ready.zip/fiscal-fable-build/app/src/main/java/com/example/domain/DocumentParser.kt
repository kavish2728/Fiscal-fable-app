package com.example.domain

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream
import kotlin.math.min

sealed class ParsedDocumentContent {
    data class TextTable(
        val fileName: String,
        val mimeType: String,
        val extractedText: String,
        val pageOrSheetCount: Int,
        val ocrRequired: Boolean = false
    ) : ParsedDocumentContent()

    data class PageImages(
        val fileName: String,
        val mimeType: String,
        val bitmaps: List<Bitmap>,
        val totalPages: Int,
        val ocrRequired: Boolean = true
    ) : ParsedDocumentContent()
}

object DocumentParser {

    private const val MAX_INLINE_TEXT_CHARS = 45_000
    private const val MAX_PDF_PAGES_FOR_VISION = 6
    private const val MAX_IMAGE_DIMENSION = 1600

    suspend fun parseUri(context: Context, uri: Uri): Result<ParsedDocumentContent> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val mimeType = resolver.getType(uri) ?: "application/octet-stream"
                val fileName = resolveFileName(context, uri)
                val lower = fileName.lowercase()

                when {
                    mimeType == "application/pdf" || lower.endsWith(".pdf") -> {
                        parsePdfToBitmaps(context, uri, fileName, mimeType)
                    }
                    mimeType.startsWith("image/") || lower.endsWith(".png") ||
                        lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".webp") -> {
                        parseImage(context, uri, fileName, mimeType)
                    }
                    lower.endsWith(".xlsx") ||
                        mimeType == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -> {
                        resolver.openInputStream(uri)?.use { stream ->
                            val (text, sheetCount) = parseXlsxStream(stream)
                            Result.success(
                                ParsedDocumentContent.TextTable(
                                    fileName = fileName,
                                    mimeType = mimeType,
                                    extractedText = text.take(MAX_INLINE_TEXT_CHARS),
                                    pageOrSheetCount = sheetCount,
                                    ocrRequired = false
                                )
                            )
                        } ?: Result.failure(IllegalStateException("Unable to open Excel file."))
                    }
                    lower.endsWith(".csv") || lower.endsWith(".tsv") || lower.endsWith(".txt") ||
                        mimeType.startsWith("text/") || mimeType == "application/csv" -> {
                        resolver.openInputStream(uri)?.use { stream ->
                            val text = stream.bufferedReader().readText()
                            Result.success(
                                ParsedDocumentContent.TextTable(
                                    fileName = fileName,
                                    mimeType = mimeType,
                                    extractedText = text.take(MAX_INLINE_TEXT_CHARS),
                                    pageOrSheetCount = 1,
                                    ocrRequired = false
                                )
                            )
                        } ?: Result.failure(IllegalStateException("Unable to read text/CSV file."))
                    }
                    else -> {
                        // Attempt UTF-8 readable fallback (e.g., XML Spreadsheet .xls)
                        resolver.openInputStream(uri)?.use { stream ->
                            val raw = stream.readBytes()
                            val textPreview = raw.decodeToString()
                            if (textPreview.contains("<Workbook") || textPreview.contains(",")) {
                                Result.success(
                                    ParsedDocumentContent.TextTable(
                                        fileName = fileName,
                                        mimeType = mimeType,
                                        extractedText = textPreview.take(MAX_INLINE_TEXT_CHARS),
                                        pageOrSheetCount = 1,
                                        ocrRequired = false
                                    )
                                )
                            } else {
                                Result.failure(
                                    IllegalArgumentException(
                                        "Legacy binary format ($fileName) is unsupported. Please upload .xlsx, .csv, .pdf, or an image scan."
                                    )
                                )
                            }
                        } ?: Result.failure(IllegalStateException("Unable to open selected file."))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun resolveFileName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                val name = cursor.getString(idx)
                if (!name.isNullOrBlank()) return name
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "financial_document"
    }

    private fun parsePdfToBitmaps(
        context: Context,
        uri: Uri,
        fileName: String,
        mimeType: String
    ): Result<ParsedDocumentContent> {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: return Result.failure(IllegalStateException("Cannot open PDF descriptor."))
        return pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                val pageCount = renderer.pageCount
                val limit = min(pageCount, MAX_PDF_PAGES_FOR_VISION)
                val bitmaps = mutableListOf<Bitmap>()
                for (i in 0 until limit) {
                    renderer.openPage(i).use { page ->
                        val scale = min(2.0f, MAX_IMAGE_DIMENSION.toFloat() / maxOf(page.width, page.height, 1))
                        val targetW = (page.width * scale).toInt().coerceAtLeast(600)
                        val targetH = (page.height * scale).toInt().coerceAtLeast(600)
                        val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                        Canvas(bmp).drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmaps += bmp
                    }
                }
                Result.success(
                    ParsedDocumentContent.PageImages(
                        fileName = fileName,
                        mimeType = mimeType,
                        bitmaps = bitmaps,
                        totalPages = pageCount,
                        ocrRequired = true
                    )
                )
            }
        }
    }

    private fun parseImage(
        context: Context,
        uri: Uri,
        fileName: String,
        mimeType: String
    ): Result<ParsedDocumentContent> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return Result.failure(IllegalStateException("Cannot read image file."))
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > MAX_IMAGE_DIMENSION || bounds.outHeight / sample > MAX_IMAGE_DIMENSION) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            ?: return Result.failure(IllegalStateException("Invalid image format."))
        return Result.success(
            ParsedDocumentContent.PageImages(
                fileName = fileName,
                mimeType = mimeType,
                bitmaps = listOf(bmp),
                totalPages = 1,
                ocrRequired = true
            )
        )
    }

    /**
     * Pure Kotlin .xlsx parser using ZipInputStream + XmlPullParser (no external POI dependency bloat).
     */
    private fun parseXlsxStream(input: InputStream): Pair<String, Int> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory &&
                    (entry.name == "xl/sharedStrings.xml" || entry.name.startsWith("xl/worksheets/sheet"))
                ) {
                    val out = ByteArrayOutputStream()
                    zip.copyTo(out)
                    entries[entry.name] = out.toByteArray()
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheets = entries.keys.filter { it.startsWith("xl/worksheets/sheet") }.sorted()

        val sb = StringBuilder()
        sheets.forEachIndexed { idx, sheetPath ->
            val sheetBytes = entries[sheetPath] ?: return@forEachIndexed
            sb.appendLine("=== Sheet ${idx + 1} ($sheetPath) ===")
            sb.appendLine(parseWorksheetXml(sheetBytes, sharedStrings))
        }
        if (sb.isBlank()) {
            throw IllegalArgumentException("No readable worksheet data found in Excel workbook.")
        }
        return sb.toString() to sheets.size.coerceAtLeast(1)
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val list = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var current = StringBuilder()
        var inSi = false
        var inT = false
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "si" -> { inSi = true; current = StringBuilder() }
                    "t" -> if (inSi) inT = true
                }
                XmlPullParser.TEXT -> if (inSi && inT) current.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) {
                    "t" -> inT = false
                    "si" -> { inSi = false; list += current.toString() }
                }
            }
            event = parser.next()
        }
        return list
    }

    private fun parseWorksheetXml(bytes: ByteArray, sharedStrings: List<String>): String {
        val sb = StringBuilder()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var currentRow = mutableListOf<String>()
        var cellType = ""
        var cellRef = ""
        var cellVal = StringBuilder()
        var inVal = false
        var inInlineStr = false

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> currentRow = mutableListOf()
                    "c" -> {
                        cellType = parser.getAttributeValue(null, "t") ?: ""
                        cellRef = parser.getAttributeValue(null, "r") ?: ""
                        cellVal = StringBuilder()
                    }
                    "v" -> inVal = true
                    "t" -> if (cellType == "inlineStr") inInlineStr = true
                }
                XmlPullParser.TEXT -> {
                    if (inVal || inInlineStr) cellVal.append(parser.text)
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v" -> inVal = false
                    "t" -> inInlineStr = false
                    "c" -> {
                        val raw = cellVal.toString().trim()
                        val resolved = when (cellType) {
                            "s" -> raw.toIntOrNull()?.let { sharedStrings.getOrNull(it) } ?: raw
                            else -> raw
                        }
                        if (resolved.isNotBlank()) {
                            currentRow += if (cellRef.isNotBlank()) "$cellRef:$resolved" else resolved
                        }
                    }
                    "row" -> {
                        if (currentRow.isNotEmpty()) {
                            sb.appendLine(currentRow.joinToString(" | "))
                        }
                    }
                }
            }
            event = parser.next()
        }
        return sb.toString()
    }
}
