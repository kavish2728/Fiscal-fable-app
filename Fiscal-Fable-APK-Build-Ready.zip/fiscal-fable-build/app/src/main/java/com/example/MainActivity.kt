package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Approval
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.configureAppCheck
import com.example.data.local.FiscalFableDatabase
import com.example.data.model.WorkspaceSection
import com.example.data.repository.CfoAiAgentsRepository
import com.example.data.repository.CfoLocalRepository
import com.example.ui.screens.AdvisoryScreen
import com.example.ui.screens.ApprovalsScreen
import com.example.ui.screens.ClientsScreen
import com.example.ui.screens.DocumentIntelligenceScreen
import com.example.ui.screens.FinancialAnalysisScreen
import com.example.ui.screens.FpaScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.FiscalFableTheme
import com.example.ui.viewmodel.FiscalFableViewModel
import com.example.ui.viewmodel.UiStreamState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mandatory: App Check must run before Compose setContent, ViewModels, or Firebase AI calls
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            FiscalFableTheme {
                FiscalFableWorkspace()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FiscalFableWorkspace() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val viewModel: FiscalFableViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val db = FiscalFableDatabase.getInstance(context)
                FiscalFableViewModel(
                    localRepo = CfoLocalRepository(db.cfoDao()),
                    aiRepo = CfoAiAgentsRepository()
                )
            }
        }
    )

    val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
    val selectedClientId by viewModel.selectedClientId.collectAsStateWithLifecycle()
    val clientsState by viewModel.clientsState.collectAsStateWithLifecycle()
    val documentsState by viewModel.documentsState.collectAsStateWithLifecycle()
    val figuresState by viewModel.extractedFiguresState.collectAsStateWithLifecycle()
    val analysesState by viewModel.analysesState.collectAsStateWithLifecycle()
    val forecastsState by viewModel.forecastsState.collectAsStateWithLifecycle()
    val advisoriesState by viewModel.advisoriesState.collectAsStateWithLifecycle()
    val reportsState by viewModel.reportsState.collectAsStateWithLifecycle()
    val auditLogsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
    val agentTask by viewModel.agentTask.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val errorBanner by viewModel.errorBanner.collectAsStateWithLifecycle()
    val cfoProfile by viewModel.cfoProfile.collectAsStateWithLifecycle()
    val preferLakhs = cfoProfile.preferLakhsCrores
    val pendingPeriod by viewModel.pendingUploadPeriod.collectAsStateWithLifecycle()
    val editingReport by viewModel.selectedReportForEdit.collectAsStateWithLifecycle()

    val clients = (clientsState as? UiStreamState.Success)?.data ?: emptyList()
    val activeClient = clients.firstOrNull { it.id == selectedClientId }
    val documents = (documentsState as? UiStreamState.Success)?.data ?: emptyList()
    val figures = (figuresState as? UiStreamState.Success)?.data ?: emptyList()
    val analyses = (analysesState as? UiStreamState.Success)?.data ?: emptyList()
    val forecasts = (forecastsState as? UiStreamState.Success)?.data ?: emptyList()
    val advisories = (advisoriesState as? UiStreamState.Success)?.data ?: emptyList()
    val reports = (reportsState as? UiStreamState.Success)?.data ?: emptyList()
    val auditLogs = (auditLogsState as? UiStreamState.Success)?.data ?: emptyList()

    val latestAnalysis = analyses.maxByOrNull { it.createdAtMillis }
    val latestForecast = forecasts.maxByOrNull { it.createdAtMillis }

    // Support system back gesture inside sub-sections
    BackHandler(enabled = selectedSection != WorkspaceSection.OVERVIEW && editingReport == null) {
        viewModel.selectSection(WorkspaceSection.OVERVIEW)
    }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var clientSwitcherOpen by remember { mutableStateOf(false) }

    val drawerBody: @Composable () -> Unit = {
        ModalDrawerSheet(
            drawerContainerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 16.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text(
                        text = "FISCAL FABLE CFO",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Virtual CFO Intelligence · Ind AS",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                WorkspaceSection.entries.forEach { section ->
                    NavigationDrawerItem(
                        icon = { Icon(sectionIcon(section), contentDescription = null) },
                        label = { Text(section.title) },
                        selected = selectedSection == section,
                        onClick = {
                            viewModel.selectSection(section)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = drawerBody
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWide = maxWidth >= 720.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        navigationIcon = {
                            if (!isWide) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.testTag("menu_drawer_button")
                                ) {
                                    Icon(Icons.Filled.Menu, contentDescription = "Open navigation menu")
                                }
                            }
                        },
                        title = {
                            Column {
                                Text(
                                    text = selectedSection.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = activeClient?.companyName ?: "No client selected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            if (clients.isNotEmpty()) {
                                Box {
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier
                                            .padding(end = 12.dp)
                                            .clickable { clientSwitcherOpen = true }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = activeClient?.companyName?.take(14) ?: "Client",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Icon(
                                                Icons.Filled.ExpandMore,
                                                contentDescription = "Switch client",
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = clientSwitcherOpen,
                                        onDismissRequest = { clientSwitcherOpen = false }
                                    ) {
                                        clients.forEach { c ->
                                            DropdownMenuItem(
                                                text = { Text("${c.companyName} (${c.currency})") },
                                                onClick = {
                                                    viewModel.selectClient(c)
                                                    clientSwitcherOpen = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!isWide) {
                        val quickTabs = listOf(
                            WorkspaceSection.OVERVIEW,
                            WorkspaceSection.DOCUMENTS,
                            WorkspaceSection.ANALYSIS,
                            WorkspaceSection.REPORTS,
                            WorkspaceSection.APPROVALS
                        )
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            quickTabs.forEach { sec ->
                                NavigationBarItem(
                                    selected = selectedSection == sec,
                                    onClick = { viewModel.selectSection(sec) },
                                    icon = { Icon(sectionIcon(sec), contentDescription = sec.title) },
                                    label = { Text(sec.shortTitle, maxLines = 1) }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isWide) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            Spacer(Modifier.height(8.dp))
                            WorkspaceSection.entries.forEach { sec ->
                                NavigationRailItem(
                                    selected = selectedSection == sec,
                                    onClick = { viewModel.selectSection(sec) },
                                    icon = { Icon(sectionIcon(sec), contentDescription = sec.title) },
                                    label = { Text(sec.shortTitle, maxLines = 1) }
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (agentTask.busy) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = agentTask.message,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                )
                            }
                        }

                        if (!errorBanner.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = errorBanner!!,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { viewModel.dismissBanners() }) {
                                        Text("Dismiss")
                                    }
                                }
                            }
                        } else if (!bannerMessage.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = bannerMessage!!,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { viewModel.dismissBanners() }) {
                                        Text("OK")
                                    }
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .widthIn(max = 920.dp)
                                .fillMaxWidth()
                        ) {
                            when (selectedSection) {
                                WorkspaceSection.OVERVIEW -> OverviewScreen(
                                    clients = clients,
                                    activeClient = activeClient,
                                    documents = documents,
                                    figures = figures,
                                    analyses = analyses,
                                    forecasts = forecasts,
                                    advisories = advisories,
                                    reports = reports,
                                    preferLakhs = preferLakhs,
                                    onNavigate = { viewModel.selectSection(it) }
                                )
                                WorkspaceSection.CLIENTS -> ClientsScreen(
                                    clients = clients,
                                    activeClientId = selectedClientId,
                                    onSelectClient = { viewModel.selectClient(it) },
                                    onCreateClient = { client, done -> viewModel.createClient(client, done) },
                                    onUpdateClient = { client, done -> viewModel.updateClient(client, done) }
                                )
                                WorkspaceSection.DOCUMENTS -> DocumentIntelligenceScreen(
                                    activeClient = activeClient,
                                    documents = documents,
                                    figures = figures,
                                    pendingPeriod = pendingPeriod,
                                    preferLakhs = preferLakhs,
                                    onPeriodChange = { viewModel.setPendingUploadPeriod(it) },
                                    onUploadUri = { uri, type, period ->
                                        activeClient?.let {
                                            viewModel.processUploadedDocument(context, uri, it, type, period)
                                        }
                                    },
                                    onUpdateFigure = { fig, amt, lbl, valid ->
                                        activeClient?.let {
                                            viewModel.updateAndValidateFigure(it.id, fig, amt, lbl, valid)
                                        }
                                    },
                                    onConfirmHighConfidence = {
                                        activeClient?.let { viewModel.confirmAllHighConfidence(it.id, figures, documents) }
                                    },
                                    onConfirmAll = {
                                        activeClient?.let { viewModel.confirmAllFigures(it.id, figures, documents) }
                                    },
                                    onRunAnalysisAfterValidation = {
                                        activeClient?.let {
                                            viewModel.runFinancialAnalysis(it, figures, analyses)
                                            viewModel.selectSection(WorkspaceSection.ANALYSIS)
                                        }
                                    }
                                )
                                WorkspaceSection.ANALYSIS -> FinancialAnalysisScreen(
                                    activeClient = activeClient,
                                    figures = figures,
                                    analyses = analyses,
                                    preferLakhs = preferLakhs,
                                    onRunAnalysis = {
                                        activeClient?.let { viewModel.runFinancialAnalysis(it, figures, analyses) }
                                    }
                                )
                                WorkspaceSection.FPA -> FpaScreen(
                                    activeClient = activeClient,
                                    latestAnalysis = latestAnalysis,
                                    forecasts = forecasts,
                                    preferLakhs = preferLakhs,
                                    onGenerateForecast = { h, g, c, o, d ->
                                        activeClient?.let {
                                            viewModel.runFpaForecast(it, latestAnalysis, h, g, c, o, d)
                                        }
                                    }
                                )
                                WorkspaceSection.ADVISORY -> AdvisoryScreen(
                                    activeClient = activeClient,
                                    latestAnalysis = latestAnalysis,
                                    advisories = advisories,
                                    onGenerateAdvisories = {
                                        activeClient?.let { viewModel.runBusinessAdvisor(it, latestAnalysis, latestForecast) }
                                    },
                                    onUpdateStatus = { item, status ->
                                        activeClient?.let { viewModel.updateAdvisoryStatus(it.id, item, status) }
                                    }
                                )
                                WorkspaceSection.REPORTS -> ReportsScreen(
                                    activeClient = activeClient,
                                    latestAnalysis = latestAnalysis,
                                    reports = reports,
                                    editingReport = editingReport,
                                    onOpenEditor = { viewModel.openReportEditor(it) },
                                    onGenerateReport = { reportType ->
                                        activeClient?.let {
                                            viewModel.generateCfoReport(it, reportType, latestAnalysis, latestForecast, advisories)
                                        }
                                    },
                                    onSaveDraftEdits = { rep, status, action, notes ->
                                        activeClient?.let { viewModel.saveReportEdits(it.id, rep, status, action, notes) }
                                    },
                                    onExportPdf = { uri, rep ->
                                        viewModel.exportReportPdf(context, uri, rep, activeClient, latestAnalysis)
                                    },
                                    onExportExcel = { uri, rep ->
                                        viewModel.exportReportExcel(context, uri, rep, activeClient, latestAnalysis, latestForecast, advisories)
                                    }
                                )
                                WorkspaceSection.APPROVALS -> ApprovalsScreen(
                                    activeClient = activeClient,
                                    reports = reports,
                                    auditLogs = auditLogs,
                                    onOpenReport = { rep ->
                                        viewModel.openReportEditor(rep)
                                        viewModel.selectSection(WorkspaceSection.REPORTS)
                                    },
                                    onRequestChanges = { rep, notes ->
                                        activeClient?.let {
                                            viewModel.saveReportEdits(
                                                it.id,
                                                rep.copy(cfoReviewNotes = notes),
                                                "CHANGES_REQUESTED",
                                                "CHANGES_REQUESTED",
                                                notes.ifBlank { "Revisions requested by CFO." }
                                            )
                                        }
                                    },
                                    onApproveReport = { rep, notes ->
                                        activeClient?.let { viewModel.approveReport(it.id, rep, notes) }
                                    },
                                    onExportPdf = { uri, rep ->
                                        viewModel.exportReportPdf(context, uri, rep, activeClient, latestAnalysis)
                                    },
                                    onExportExcel = { uri, rep ->
                                        viewModel.exportReportExcel(context, uri, rep, activeClient, latestAnalysis, latestForecast, advisories)
                                    }
                                )
                                WorkspaceSection.SETTINGS -> SettingsScreen(
                                    cfoProfile = cfoProfile,
                                    preferLakhsCrores = preferLakhs,
                                    onToggleLakhsCrores = { viewModel.toggleLakhsCrores(it) },
                                    onSaveProfile = { name, title -> viewModel.updateCfoProfile(name, title) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun sectionIcon(section: WorkspaceSection): ImageVector = when (section) {
    WorkspaceSection.OVERVIEW -> Icons.Filled.Dashboard
    WorkspaceSection.CLIENTS -> Icons.Filled.Business
    WorkspaceSection.DOCUMENTS -> Icons.Filled.DocumentScanner
    WorkspaceSection.ANALYSIS -> Icons.Filled.Analytics
    WorkspaceSection.FPA -> Icons.Filled.Timeline
    WorkspaceSection.ADVISORY -> Icons.Filled.Lightbulb
    WorkspaceSection.REPORTS -> Icons.Filled.Description
    WorkspaceSection.APPROVALS -> Icons.Filled.Approval
    WorkspaceSection.SETTINGS -> Icons.Filled.Settings
}
