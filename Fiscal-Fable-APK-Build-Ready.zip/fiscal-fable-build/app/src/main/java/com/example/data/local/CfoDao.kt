package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CfoDao {

    // Profile
    @Query("SELECT * FROM cfo_profile WHERE id = 1")
    fun observeProfile(): Flow<CfoProfileRoomEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: CfoProfileRoomEntity)

    // Clients
    @Query("SELECT * FROM clients ORDER BY companyName ASC")
    fun observeClients(): Flow<List<ClientRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: ClientRoomEntity)

    @Update
    suspend fun updateClient(client: ClientRoomEntity)

    @Query("DELETE FROM clients WHERE id = :clientId")
    suspend fun deleteClientById(clientId: String)

    // Documents
    @Query("SELECT * FROM documents WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeDocuments(clientId: String): Flow<List<FinancialDocumentRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: FinancialDocumentRoomEntity)

    @Query("UPDATE documents SET extractionStatus = :status, updatedAtMillis = :updatedAt WHERE id IN (:documentIds) AND clientId = :clientId")
    suspend fun updateDocumentStatuses(clientId: String, documentIds: List<String>, status: String, updatedAt: Long)

    // Extracted Figures
    @Query("SELECT * FROM extracted_figures WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeExtractedFigures(clientId: String): Flow<List<ExtractedFigureRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFigures(figures: List<ExtractedFigureRoomEntity>)

    @Query(
        """
        UPDATE extracted_figures
        SET amount = :amount, label = :label, validated = :validated, validatedBy = :validatedBy, updatedAtMillis = :updatedAt
        WHERE id = :figureId AND clientId = :clientId
        """
    )
    suspend fun updateFigureValidation(
        clientId: String,
        figureId: String,
        amount: Double,
        label: String,
        validated: Boolean,
        validatedBy: String,
        updatedAt: Long
    )

    @Query(
        """
        UPDATE extracted_figures
        SET validated = 1, validatedBy = :validatedBy, updatedAtMillis = :updatedAt
        WHERE id IN (:figureIds) AND clientId = :clientId
        """
    )
    suspend fun markFiguresValidated(
        clientId: String,
        figureIds: List<String>,
        validatedBy: String,
        updatedAt: Long
    )

    @Transaction
    suspend fun saveDocumentWithFigures(
        doc: FinancialDocumentRoomEntity,
        figures: List<ExtractedFigureRoomEntity>
    ) {
        insertDocument(doc)
        if (figures.isNotEmpty()) {
            insertFigures(figures)
        }
    }

    @Transaction
    suspend fun validateFiguresAndDocuments(
        clientId: String,
        figureIds: List<String>,
        documentIds: List<String>,
        validatedBy: String,
        updatedAt: Long
    ) {
        if (figureIds.isNotEmpty()) {
            markFiguresValidated(clientId, figureIds, validatedBy, updatedAt)
        }
        if (documentIds.isNotEmpty()) {
            updateDocumentStatuses(clientId, documentIds, "VALIDATED", updatedAt)
        }
    }

    // Analyses
    @Query("SELECT * FROM analyses WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeAnalyses(clientId: String): Flow<List<FinancialAnalysisRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysis(analysis: FinancialAnalysisRoomEntity)

    // Forecasts
    @Query("SELECT * FROM forecasts WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeForecasts(clientId: String): Flow<List<FpaForecastRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForecast(forecast: FpaForecastRoomEntity)

    // Advisories
    @Query("SELECT * FROM advisories WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeAdvisories(clientId: String): Flow<List<BusinessAdvisoryRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvisories(items: List<BusinessAdvisoryRoomEntity>)

    @Query("UPDATE advisories SET actionStatus = :newStatus, updatedAtMillis = :updatedAt WHERE id = :advisoryId AND clientId = :clientId")
    suspend fun updateAdvisoryStatus(clientId: String, advisoryId: String, newStatus: String, updatedAt: Long)

    // Reports & Audit Logs
    @Query("SELECT * FROM reports WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeReports(clientId: String): Flow<List<CfoReportRoomEntity>>

    @Query("SELECT * FROM reports WHERE id = :reportId AND clientId = :clientId")
    suspend fun getReportById(clientId: String, reportId: String): CfoReportRoomEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: CfoReportRoomEntity)

    @Update
    suspend fun updateReport(report: CfoReportRoomEntity)

    @Query("SELECT * FROM audit_logs WHERE clientId = :clientId ORDER BY createdAtMillis DESC")
    fun observeAuditLogs(clientId: String): Flow<List<ApprovalAuditLogRoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: ApprovalAuditLogRoomEntity)

    @Transaction
    suspend fun createReportWithAudit(report: CfoReportRoomEntity, log: ApprovalAuditLogRoomEntity) {
        insertReport(report)
        insertAuditLog(log)
    }

    @Transaction
    suspend fun updateReportWithAudit(report: CfoReportRoomEntity, log: ApprovalAuditLogRoomEntity) {
        updateReport(report)
        insertAuditLog(log)
    }
}
