package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fiscal Fable CFO — Royal Purple & Serene Lavender Palette
val RoyalViolet = Color(0xFF4C1D95)
val DeepIndigo = Color(0xFF3B1578)
val VividAmethyst = Color(0xFF6D28D9)
val SoftIris = Color(0xFF7C3AED)
val LavenderMist = Color(0xFFF7F5FC)
val LavenderSurface = Color(0xFFF1EDFA)
val LavenderTint = Color(0xFFEDE9FE)
val LavenderBorder = Color(0xFFE2DAF7)
val PureWhite = Color(0xFFFFFFFF)

// Dark Mode Surfaces
val MidnightPlum = Color(0xFF110C1D)
val PlumSurface = Color(0xFF1A132B)
val PlumSurfaceElevated = Color(0xFF241B3A)
val PlumBorder = Color(0xFF372B54)
val OrchidLight = Color(0xFFC4B5FD)

// Typography & Ink
val InkPrimary = Color(0xFF1A132B)
val InkSecondary = Color(0xFF53486E)
val InkMuted = Color(0xFF7D7299)
val InkOnDark = Color(0xFFF5F3FF)

// Financial Semantic Accents
val EmeraldPositive = Color(0xFF0E9F6E)
val EmeraldContainer = Color(0xFFE8F8F2)
val AmberCaution = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val CrimsonRisk = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEE2E2)
val SlateInfo = Color(0xFF4F46E5)
val SlateContainer = Color(0xFFE0E7FF)
