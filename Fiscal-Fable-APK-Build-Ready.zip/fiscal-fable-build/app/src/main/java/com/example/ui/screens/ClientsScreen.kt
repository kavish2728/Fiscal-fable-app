package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ClientEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@Composable
fun ClientsScreen(
    clients: List<ClientEntity>,
    activeClientId: String?,
    onSelectClient: (ClientEntity) -> Unit,
    onCreateClient: (ClientEntity, () -> Unit) -> Unit,
    onUpdateClient: (ClientEntity, () -> Unit) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var editingClient by remember { mutableStateOf<ClientEntity?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Client Directory",
                subtitle = "Isolated multi-client Ind AS workspaces",
                badge = "${clients.size} Active"
            )
        }
        item {
            Button(
                onClick = {
                    editingClient = null
                    showDialog = true
                },
                modifier = Modifier.fillMaxWidth().testTag("add_client_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add Corporate Client")
            }
        }

        if (clients.isEmpty()) {
            item {
                EmptyVaultCard(
                    title = "No Clients Configured",
                    description = "Create a client record with company profile, reporting currency (INR), Indian Financial Year (Apr–Mar), and primary CFO contact.",
                    actionLabel = "Create First Client",
                    onAction = {
                        editingClient = null
                        showDialog = true
                    }
                )
            }
        } else {
            items(clients, key = { it.id }) { client ->
                val isSelected = client.id == activeClientId
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectClient(client) }
                        .testTag("client_card_${client.id}"),
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = client.companyName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (isSelected) {
                                        Spacer(Modifier.width(6.dp))
                                        Icon(
                                            Icons.Filled.CheckCircle,
                                            contentDescription = "Selected Client",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Text(
                                    text = "${client.industry} · ${client.country} (${client.currency})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    editingClient = client
                                    showDialog = true
                                }
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit client")
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatusBadge(client.financialYear, BadgeTone.VIOLET)
                            StatusBadge(client.accountingPeriod, BadgeTone.INFO)
                            StatusBadge(client.accountingStandard, BadgeTone.POSITIVE)
                        }

                        if (client.businessProfile.isNotBlank()) {
                            Text(
                                text = client.businessProfile,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (client.contactName.isNotBlank() || client.contactEmail.isNotBlank()) {
                            Text(
                                text = "Contact: ${client.contactName} · ${client.contactEmail} ${client.contactPhone}".trim(),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ClientEditorDialog(
            initial = editingClient,
            onDismiss = { showDialog = false },
            onSave = { entity ->
                if (editingClient == null) {
                    onCreateClient(entity) { showDialog = false }
                } else {
                    onUpdateClient(entity) { showDialog = false }
                }
            }
        )
    }
}

@Composable
private fun ClientEditorDialog(
    initial: ClientEntity?,
    onDismiss: () -> Unit,
    onSave: (ClientEntity) -> Unit
) {
    var companyName by remember { mutableStateOf(initial?.companyName ?: "") }
    var industry by remember { mutableStateOf(initial?.industry ?: "Manufacturing & Engineering") }
    var country by remember { mutableStateOf(initial?.country ?: "India") }
    var currency by remember { mutableStateOf(initial?.currency ?: "INR") }
    var financialYear by remember { mutableStateOf(initial?.financialYear ?: "FY 2025-26") }
    var accountingPeriod by remember { mutableStateOf(initial?.accountingPeriod ?: "Q2 (Jul-Sep 2025)") }
    var accountingStandard by remember { mutableStateOf(initial?.accountingStandard ?: "Ind AS (Schedule III)") }
    var businessProfile by remember { mutableStateOf(initial?.businessProfile ?: "") }
    var contactName by remember { mutableStateOf(initial?.contactName ?: "") }
    var contactEmail by remember { mutableStateOf(initial?.contactEmail ?: "") }
    var contactPhone by remember { mutableStateOf(initial?.contactPhone ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New Client Workspace" else "Edit Client Workspace") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it },
                    label = { Text("Company Legal Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("client_name_input")
                )
                OutlinedTextField(
                    value = industry,
                    onValueChange = { industry = it },
                    label = { Text("Industry Sector") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = country,
                        onValueChange = { country = it },
                        label = { Text("Country") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = currency,
                        onValueChange = { currency = it.uppercase() },
                        label = { Text("Currency") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = financialYear,
                        onValueChange = { financialYear = it },
                        label = { Text("Financial Year") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = accountingPeriod,
                        onValueChange = { accountingPeriod = it },
                        label = { Text("Period") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = accountingStandard,
                    onValueChange = { accountingStandard = it },
                    label = { Text("Accounting Standard") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = businessProfile,
                    onValueChange = { businessProfile = it },
                    label = { Text("Business Profile & Key Operations") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = contactName,
                    onValueChange = { contactName = it },
                    label = { Text("Primary Contact Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = contactEmail,
                        onValueChange = { contactEmail = it },
                        label = { Text("Email") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = contactPhone,
                        onValueChange = { contactPhone = it },
                        label = { Text("Phone") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val model = (initial ?: ClientEntity()).copy(
                        companyName = companyName,
                        industry = industry,
                        country = country,
                        currency = currency,
                        financialYear = financialYear,
                        accountingPeriod = accountingPeriod,
                        accountingStandard = accountingStandard,
                        businessProfile = businessProfile,
                        contactName = contactName,
                        contactEmail = contactEmail,
                        contactPhone = contactPhone,
                        status = initial?.status ?: "ACTIVE"
                    )
                    onSave(model)
                },
                enabled = companyName.trim().length >= 2,
                modifier = Modifier.testTag("save_client_button")
            ) {
                Text("Save Client")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
