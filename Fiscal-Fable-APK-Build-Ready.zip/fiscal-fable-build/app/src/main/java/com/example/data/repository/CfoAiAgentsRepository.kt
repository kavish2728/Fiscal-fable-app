package com.example.data.repository

import android.util.Log
import com.example.core.IndAsFormatter
import com.example.data.model.AdvisoryCategory
import com.example.data.model.AdvisoryPriority
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.DocumentType
import com.example.data.model.ExtractedFigure
import com.example.data.model.FigureConfidence
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FpaForecastRecord
import com.example.data.model.StatementCategory
import com.example.data.model.UnitScale
import com.example.domain.FinancialCalculator
import com.example.domain.ParsedDocumentContent
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class CfoAiAgentsRepository {

    companion object {
        private const val TAG = "CfoAiAgents"
        private const val MODEL_NAME = "gemini-3.8-flash"
        private const val AI_TIMEOUT_MS = 60_000L
    }

    data class DocumentExtractionOutput(
        val detectedPeriod: String,
        val detectedCurrency: String,
        val detectedUnitScale: UnitScale,
        val sourceSummary: String,
        val missingFieldsNote: String,
        val figures: List<ExtractedFigure>
    )

    data class AnalystNarrativeOutput(
        val executiveSummary: String,
        val trendCommentary: String,
        val unusualMovements: List<String>,
        val indAsNotes: List<String>
    )

    data class FpaCommentaryOutput(
        val assumptionsSummary: String,
        val conservativeSummary: String,
        val expectedSummary: String,
        val optimisticSummary: String
    )

    data class DraftedReportSections(
        val reportTitle: String,
        val executiveSummary: String,
        val financialObservations: String,
        val riskIdentification: String,
        val recommendationsText: String,
        val managementActionPoints: String,
        val conclusion: String
    )

    // 1. Document Intelligence Agent Schema
    private val extractionSchema = Schema.obj(
        properties = mapOf(
            "detectedPeriod" to Schema.string(description = "Detected reporting period e.g. Q2 FY 2025-26"),
            "detectedCurrency" to Schema.string(description = "Detected ISO currency code e.g. INR, USD"),
            "detectedUnitScale" to Schema.enumeration(
                values = listOf("RAW", "THOUSANDS", "LAKHS", "CRORES"),
                description = "Scale of numbers in the source table"
            ),
            "sourceSummary" to Schema.string(description = "Concise summary of the document contents and Ind AS classification"),
            "missingFieldsNote" to Schema.string(description = "Explicitly list key Ind AS line items missing or ambiguous in the document"),
            "figures" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "statementCategory" to Schema.enumeration(
                            values = listOf("PNL", "BALANCE_SHEET", "CASH_FLOW", "WORKING_CAPITAL")
                        ),
                        "fieldKey" to Schema.string(
                            description = "Standard key: revenue, cogs, gross_profit, operating_expenses, ebitda, depreciation, ebit, interest_expense, pbt, tax_expense, net_profit, total_assets, non_current_assets, current_assets, inventory, trade_receivables, cash_and_equivalents, total_equity, total_debt, current_liabilities, trade_payables, operating_cash_flow, investing_cash_flow, financing_cash_flow"
                        ),
                        "label" to Schema.string(description = "Human-readable line item name"),
                        "indAsReference" to Schema.string(description = "Applicable Ind AS or Schedule III reference"),
                        "amountInRawBaseCurrency" to Schema.double(
                            description = "Numeric value converted to raw base currency units (e.g., if table says 145.5 Lakhs INR, output 14550000.0). Never invent values."
                        ),
                        "sourceCitation" to Schema.string(description = "Exact page, row, or cell reference from document"),
                        "confidence" to Schema.enumeration(values = listOf("HIGH", "MEDIUM", "LOW")),
                        "ambiguityNote" to Schema.string(description = "Flag any ambiguity, OCR uncertainty, or mapping assumption")
                    ),
                    optionalProperties = listOf("ambiguityNote")
                ),
                description = "Extracted financial figures strictly observed in the source document"
            )
        )
    )

    // 2. Financial Analyst Agent Schema
    private val analysisSchema = Schema.obj(
        properties = mapOf(
            "executiveSummary" to Schema.string(description = "Grounded executive CFO assessment of profitability, liquidity, solvency, and efficiency"),
            "trendCommentary" to Schema.string(description = "Historical comparison commentary if prior periods are provided, else baseline commentary"),
            "unusualMovements" to Schema.array(
                items = Schema.string(),
                description = "Specific unusual ratios, margin shifts, or balance sheet movements grounded strictly in provided numbers"
            ),
            "indAsNotes" to Schema.array(
                items = Schema.string(),
                description = "Applicable Ind AS compliance observations (Ind AS 115, 116, 2, 12, Schedule III)"
            )
        )
    )

    // 3. Cash Flow & FP&A Agent Schema
    private val fpaSchema = Schema.obj(
        properties = mapOf(
            "assumptionsSummary" to Schema.string(description = "Explicit assumptions list distinguishing actual baseline from forecast drivers"),
            "conservativeSummary" to Schema.string(description = "Conservative scenario liquidity & cash outlook"),
            "expectedSummary" to Schema.string(description = "Expected scenario trajectory and working capital outlook"),
            "optimisticSummary" to Schema.string(description = "Optimistic scenario upside and reinvestment headroom")
        )
    )

    // 4. Business Advisor Agent Schema
    private val advisorySchema = Schema.obj(
        properties = mapOf(
            "recommendations" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "category" to Schema.enumeration(
                            values = AdvisoryCategory.entries.map { it.name }
                        ),
                        "identifiedProblem" to Schema.string(),
                        "supportingEvidence" to Schema.string(description = "Cite exact validated figures/ratios"),
                        "businessImpact" to Schema.string(),
                        "recommendedAction" to Schema.string(),
                        "priority" to Schema.enumeration(values = AdvisoryPriority.entries.map { it.name }),
                        "expectedOutcome" to Schema.string(),
                        "relevantAssumptions" to Schema.string()
                    )
                ),
                description = "3 to 5 actionable CFO recommendations"
            )
        )
    )

    // 5. CFO Reporting Agent Schema
    private val reportSchema = Schema.obj(
        properties = mapOf(
            "reportTitle" to Schema.string(),
            "executiveSummary" to Schema.string(),
            "financialObservations" to Schema.string(),
            "riskIdentification" to Schema.string(),
            "recommendationsText" to Schema.string(),
            "managementActionPoints" to Schema.string(),
            "conclusion" to Schema.string()
        )
    )

    private val extractionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = extractionSchema
                temperature = 0.1f
            }
        )
    }

    private val analysisModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = analysisSchema
                temperature = 0.2f
            }
        )
    }

    private val fpaModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = fpaSchema
                temperature = 0.2f
            }
        )
    }

    private val advisoryModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = advisorySchema
                temperature = 0.25f
            }
        )
    }

    private val reportModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = reportSchema
                temperature = 0.25f
            }
        )
    }

    suspend fun extractFinancialDocument(
        client: ClientEntity,
        docType: DocumentType,
        defaultPeriod: String,
        parsed: ParsedDocumentContent
    ): Result<DocumentExtractionOutput> {
        return try {
            val instructions = """
                You are the Document Intelligence Agent for Fiscal Fable AI CFO, aligned with Indian Accounting Standards (Ind AS & Schedule III of Companies Act, 2013).
                Client: ${client.companyName} | Industry: ${client.industry} | Default Currency: ${client.currency} | Financial Year: ${client.financialYear}.
                Uploaded Document Type Hint: ${docType.displayName} | Default Period Hint: $defaultPeriod.
                STRICT SAFETY RULES:
                1. Extract ONLY figures explicitly visible in the document. NEVER fabricate or guess missing numbers.
                2. If figures are in Lakhs (multiply by 100,000) or Crores (multiply by 10,000,000) or Thousands (multiply by 1,000), convert amountInRawBaseCurrency accurately and set detectedUnitScale accordingly.
                3. Cite exact page/row/cell in sourceCitation.
                4. If a figure is ambiguous, partially obscured by OCR, or lacks clarity on Ind AS mapping, mark confidence as LOW or MEDIUM and explain in ambiguityNote.
                5. List any missing standard Schedule III line items in missingFieldsNote.
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) {
                when (parsed) {
                    is ParsedDocumentContent.TextTable -> {
                        extractionModel.generateContent(
                            "$instructions\n\nDOCUMENT (${parsed.fileName}):\n${parsed.extractedText}"
                        )
                    }
                    is ParsedDocumentContent.PageImages -> {
                        extractionModel.generateContent(
                            content {
                                text("$instructions\n\nPerform OCR and financial extraction across these ${parsed.bitmaps.size} page image(s) of ${parsed.fileName}:")
                                parsed.bitmaps.forEach { bmp -> image(bmp) }
                            }
                        )
                    }
                }
            }

            val jsonText = response.text ?: throw IllegalStateException("Document Intelligence returned an empty response.")
            val root = JSONObject(jsonText)
            val period = root.optString("detectedPeriod", defaultPeriod).ifBlank { defaultPeriod }
            val currency = root.optString("detectedCurrency", client.currency).ifBlank { client.currency }
            val unitScale = com.example.data.model.safeEnum(
                root.optString("detectedUnitScale"),
                UnitScale.RAW
            )
            val sourceSummary = root.optString("sourceSummary", "Extracted from document.")
            val missingNote = root.optString("missingFieldsNote", "")

            val figuresJson = root.optJSONArray("figures")
            val figures = mutableListOf<ExtractedFigure>()
            if (figuresJson != null) {
                for (i in 0 until figuresJson.length()) {
                    val obj = figuresJson.getJSONObject(i)
                    val cat = com.example.data.model.safeEnum(
                        obj.optString("statementCategory"),
                        StatementCategory.PNL
                    )
                    val conf = com.example.data.model.safeEnum(
                        obj.optString("confidence"),
                        FigureConfidence.MEDIUM
                    )
                    figures += ExtractedFigure(
                        clientId = client.id,
                        reportingPeriod = period,
                        statementCategory = cat.name,
                        fieldKey = obj.optString("fieldKey", "other").ifBlank { "other" },
                        label = obj.optString("label", "Line Item"),
                        indAsReference = obj.optString("indAsReference", "Ind AS / Sch. III"),
                        amount = obj.optDouble("amountInRawBaseCurrency", 0.0),
                        currency = currency,
                        sourceCitation = obj.optString("sourceCitation", "Document"),
                        confidence = conf.name,
                        ambiguityNote = obj.optString("ambiguityNote", ""),
                        validated = false,
                        validatedBy = ""
                    )
                }
            }

            Result.success(
                DocumentExtractionOutput(
                    detectedPeriod = period,
                    detectedCurrency = currency,
                    detectedUnitScale = unitScale,
                    sourceSummary = sourceSummary,
                    missingFieldsNote = missingNote,
                    figures = figures
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Document extraction timed out", e)
            Result.failure(Exception("Document extraction timed out after 60s. Please retry with fewer pages."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Document extraction failed", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeFinancials(
        client: ClientEntity,
        reportingPeriod: String,
        metrics: FinancialCalculator.DeterministicMetrics,
        priorAnalyses: List<FinancialAnalysisRecord>
    ): Result<AnalystNarrativeOutput> {
        return try {
            val ccy = client.currency
            val priorBlock = if (priorAnalyses.isEmpty()) {
                "No prior historical analyses recorded for comparison yet."
            } else {
                priorAnalyses.take(3).joinToString("\n") { prev ->
                    "- ${prev.reportingPeriod}: Rev=${IndAsFormatter.formatMoney(prev.revenue, ccy)}, " +
                        "EBITDA=${IndAsFormatter.formatMoney(prev.ebitda, ccy)} (${IndAsFormatter.formatPct(prev.ebitdaMarginPct)}), " +
                        "PAT=${IndAsFormatter.formatMoney(prev.netProfit, ccy)}, " +
                        "CurrRatio=${IndAsFormatter.formatRatio(prev.currentRatio)}, CCC=${IndAsFormatter.formatDays(prev.cashConversionCycle)}"
                }
            }

            val prompt = """
                You are the Financial Analyst Agent for Fiscal Fable AI CFO (aligned with Ind AS & Schedule III).
                Entity: ${client.companyName} (${client.industry}, ${client.country}, Standard: ${client.accountingStandard}).
                Period Under Review: $reportingPeriod | Currency: $ccy.

                VALIDATED DETERMINISTIC P&L & BALANCE SHEET METRICS (DO NOT ALTER OR FABRICATE NUMBERS):
                - Revenue: ${IndAsFormatter.formatMoney(metrics.revenue, ccy)}
                - COGS: ${IndAsFormatter.formatMoney(metrics.cogs, ccy)}
                - Gross Profit: ${IndAsFormatter.formatMoney(metrics.grossProfit, ccy)} (Margin: ${IndAsFormatter.formatPct(metrics.grossMarginPct)})
                - OpEx: ${IndAsFormatter.formatMoney(metrics.operatingExpenses, ccy)}
                - EBITDA: ${IndAsFormatter.formatMoney(metrics.ebitda, ccy)} (Margin: ${IndAsFormatter.formatPct(metrics.ebitdaMarginPct)})
                - Depreciation: ${IndAsFormatter.formatMoney(metrics.depreciation, ccy)}
                - EBIT: ${IndAsFormatter.formatMoney(metrics.ebit, ccy)} (Margin: ${IndAsFormatter.formatPct(metrics.operatingMarginPct)})
                - Interest Expense: ${IndAsFormatter.formatMoney(metrics.interestExpense, ccy)}
                - PBT: ${IndAsFormatter.formatMoney(metrics.pbt, ccy)} | Tax: ${IndAsFormatter.formatMoney(metrics.taxExpense, ccy)}
                - Net Profit (PAT): ${IndAsFormatter.formatMoney(metrics.netProfit, ccy)} (Margin: ${IndAsFormatter.formatPct(metrics.netMarginPct)})
                - Current Assets: ${IndAsFormatter.formatMoney(metrics.currentAssets, ccy)} | Inventory: ${IndAsFormatter.formatMoney(metrics.inventory, ccy)} | Trade Receivables: ${IndAsFormatter.formatMoney(metrics.tradeReceivables, ccy)} | Cash: ${IndAsFormatter.formatMoney(metrics.cashAndEquivalents, ccy)}
                - Total Assets: ${IndAsFormatter.formatMoney(metrics.totalAssets, ccy)} | Total Equity: ${IndAsFormatter.formatMoney(metrics.totalEquity, ccy)} | Total Debt: ${IndAsFormatter.formatMoney(metrics.totalDebt, ccy)}
                - Current Liabilities: ${IndAsFormatter.formatMoney(metrics.currentLiabilities, ccy)} | Trade Payables: ${IndAsFormatter.formatMoney(metrics.tradePayables, ccy)}
                - Operating Cash Flow: ${IndAsFormatter.formatMoney(metrics.operatingCashFlow, ccy)}
                - Ratios: Current Ratio=${IndAsFormatter.formatRatio(metrics.currentRatio)}, Quick Ratio=${IndAsFormatter.formatRatio(metrics.quickRatio)}, Debt/Equity=${IndAsFormatter.formatRatio(metrics.debtToEquity)}, ICR=${IndAsFormatter.formatRatio(metrics.interestCoverage)}, ROA=${IndAsFormatter.formatPct(metrics.roaPct)}, ROE=${IndAsFormatter.formatPct(metrics.roePct)}
                - Working Capital: Receivable Days=${IndAsFormatter.formatDays(metrics.receivableDays)}, Inventory Days=${IndAsFormatter.formatDays(metrics.inventoryDays)}, Payable Days=${IndAsFormatter.formatDays(metrics.payableDays)}, CCC=${IndAsFormatter.formatDays(metrics.cashConversionCycle)}, NWC=${IndAsFormatter.formatMoney(metrics.workingCapital, ccy)}

                HISTORICAL PERIODS FOR COMPARISON:
                $priorBlock

                RULES: Cite only the figures above, do NOT invent external causes as facts (frame possibilities cautiously as hypotheses to verify with management), and highlight specific Ind AS notes (e.g. Ind AS 115 revenue timing, Ind AS 2 inventory, Ind AS 116 leases, MSME 45-day payable compliance if relevant).
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) { analysisModel.generateContent(prompt) }
            val json = JSONObject(response.text ?: throw IllegalStateException("Empty analysis response."))

            val unusual = mutableListOf<String>()
            val uArr = json.optJSONArray("unusualMovements")
            if (uArr != null) {
                for (i in 0 until uArr.length()) unusual += uArr.optString(i)
            }
            val notes = mutableListOf<String>()
            val nArr = json.optJSONArray("indAsNotes")
            if (nArr != null) {
                for (i in 0 until nArr.length()) notes += nArr.optString(i)
            }

            Result.success(
                AnalystNarrativeOutput(
                    executiveSummary = json.optString("executiveSummary"),
                    trendCommentary = json.optString("trendCommentary"),
                    unusualMovements = unusual.filter { it.isNotBlank() }.take(10),
                    indAsNotes = notes.filter { it.isNotBlank() }.take(10)
                )
            )
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Financial Analyst Agent timed out. Please retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Financial analysis failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateFpaCommentary(
        client: ClientEntity,
        analysis: FinancialAnalysisRecord,
        horizonMonths: Int,
        growthExpectedPct: Double,
        cogsPct: Double,
        opexGrowthPct: Double,
        targetDsoDays: Double,
        breakEvenMonthlyRev: Double,
        endConservativeCash: Double,
        endExpectedCash: Double,
        endOptimisticCash: Double
    ): Result<FpaCommentaryOutput> {
        return try {
            val ccy = client.currency
            val prompt = """
                You are the Cash Flow & FP&A Agent for Fiscal Fable AI CFO.
                Client: ${client.companyName} | Baseline Period (Actuals): ${analysis.reportingPeriod} | Currency: $ccy.
                ACTUAL BASELINE:
                - Period Revenue: ${IndAsFormatter.formatMoney(analysis.revenue, ccy)}
                - Cash & Equivalents: ${IndAsFormatter.formatMoney(analysis.cashAndEquivalents, ccy)}
                - Current DSO: ${IndAsFormatter.formatDays(analysis.receivableDays)}
                FORECAST DRIVERS ($horizonMonths-Month Horizon):
                - Expected Annual Revenue Growth: ${IndAsFormatter.formatPct(growthExpectedPct)} (Conservative: ${IndAsFormatter.formatPct(growthExpectedPct - 5.0)}, Optimistic: ${IndAsFormatter.formatPct(growthExpectedPct + 6.0)})
                - Expected COGS % of Revenue: ${IndAsFormatter.formatPct(cogsPct)}
                - OpEx Annual Escalation: ${IndAsFormatter.formatPct(opexGrowthPct)}
                - Target Receivable Days (DSO): ${IndAsFormatter.formatDays(targetDsoDays)}
                - Deterministic Break-Even Monthly Revenue: ${IndAsFormatter.formatMoney(breakEvenMonthlyRev, ccy)}
                PROJECTED ENDING CASH (M+$horizonMonths):
                - Conservative: ${IndAsFormatter.formatMoney(endConservativeCash, ccy)}
                - Expected: ${IndAsFormatter.formatMoney(endExpectedCash, ccy)}
                - Optimistic: ${IndAsFormatter.formatMoney(endOptimisticCash, ccy)}

                Clearly distinguish ACTUAL baseline figures from FORECAST assumptions and projections.
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) { fpaModel.generateContent(prompt) }
            val json = JSONObject(response.text ?: throw IllegalStateException("Empty FP&A response."))
            Result.success(
                FpaCommentaryOutput(
                    assumptionsSummary = json.optString("assumptionsSummary"),
                    conservativeSummary = json.optString("conservativeSummary"),
                    expectedSummary = json.optString("expectedSummary"),
                    optimisticSummary = json.optString("optimisticSummary")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("FP&A Agent timed out. Please retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "FP&A commentary failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateAdvisories(
        client: ClientEntity,
        analysis: FinancialAnalysisRecord,
        forecast: FpaForecastRecord?
    ): Result<List<BusinessAdvisoryItem>> {
        return try {
            val ccy = client.currency
            val prompt = """
                You are the Business Advisor Agent for Fiscal Fable AI CFO (Ind AS & Indian corporate environment).
                Client: ${client.companyName} (${client.industry}) | Period: ${analysis.reportingPeriod} | Currency: $ccy.
                VALIDATED DATA:
                - Revenue: ${IndAsFormatter.formatMoney(analysis.revenue, ccy)}, Gross Margin: ${IndAsFormatter.formatPct(analysis.grossMarginPct)}, EBITDA Margin: ${IndAsFormatter.formatPct(analysis.ebitdaMarginPct)}, Net Margin: ${IndAsFormatter.formatPct(analysis.netMarginPct)}
                - Current Ratio: ${IndAsFormatter.formatRatio(analysis.currentRatio)}, Quick Ratio: ${IndAsFormatter.formatRatio(analysis.quickRatio)}, Debt/Equity: ${IndAsFormatter.formatRatio(analysis.debtToEquity)}, ICR: ${IndAsFormatter.formatRatio(analysis.interestCoverage)}
                - DSO: ${IndAsFormatter.formatDays(analysis.receivableDays)}, DIO: ${IndAsFormatter.formatDays(analysis.inventoryDays)}, DPO: ${IndAsFormatter.formatDays(analysis.payableDays)}, CCC: ${IndAsFormatter.formatDays(analysis.cashConversionCycle)}
                - Operating Cash Flow: ${IndAsFormatter.formatMoney(analysis.operatingCashFlow, ccy)}, Cash: ${IndAsFormatter.formatMoney(analysis.cashAndEquivalents, ccy)}
                ${if (forecast != null) "- Break-Even Monthly Revenue: ${IndAsFormatter.formatMoney(forecast.breakEvenMonthlyRevenue, ccy)}" else ""}

                Generate 4 high-impact, evidence-backed CFO recommendations covering profitability, cost control, working capital, cash flow, pricing, risk, growth, or funding.
                Every item MUST cite exact figures above in supportingEvidence and explicitly state relevantAssumptions.
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) { advisoryModel.generateContent(prompt) }
            val root = JSONObject(response.text ?: throw IllegalStateException("Empty advisory response."))
            val arr = root.optJSONArray("recommendations")
            val list = mutableListOf<BusinessAdvisoryItem>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val cat = com.example.data.model.safeEnum(o.optString("category"), AdvisoryCategory.PROFITABILITY)
                    val pri = com.example.data.model.safeEnum(o.optString("priority"), AdvisoryPriority.HIGH)
                    list += BusinessAdvisoryItem(
                        clientId = client.id,
                        reportingPeriod = analysis.reportingPeriod,
                        category = cat.name,
                        identifiedProblem = o.optString("identifiedProblem"),
                        supportingEvidence = o.optString("supportingEvidence"),
                        businessImpact = o.optString("businessImpact"),
                        recommendedAction = o.optString("recommendedAction"),
                        priority = pri.name,
                        expectedOutcome = o.optString("expectedOutcome"),
                        relevantAssumptions = o.optString("relevantAssumptions"),
                        actionStatus = "OPEN"
                    )
                }
            }
            Result.success(list)
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Business Advisor Agent timed out. Please retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Advisory generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun draftCfoReport(
        client: ClientEntity,
        reportType: String,
        analysis: FinancialAnalysisRecord,
        forecast: FpaForecastRecord?,
        advisories: List<BusinessAdvisoryItem>
    ): Result<DraftedReportSections> {
        return try {
            val ccy = client.currency
            val advSummary = if (advisories.isEmpty()) {
                "No advisory items generated yet."
            } else {
                advisories.take(5).joinToString("\n") {
                    "- [${it.priority}] ${it.identifiedProblem} -> Action: ${it.recommendedAction} (Evidence: ${it.supportingEvidence})"
                }
            }

            val prompt = """
                You are the CFO Reporting Agent for Fiscal Fable CFO.
                Draft a formal, board-ready "$reportType" aligned with Indian Accounting Standards (Ind AS / Schedule III).
                Client: ${client.companyName} | Industry: ${client.industry} | FY: ${client.financialYear} | Period: ${analysis.reportingPeriod} | Currency: $ccy.

                VALIDATED FINANCIALS:
                - Revenue: ${IndAsFormatter.formatMoney(analysis.revenue, ccy)} | Gross Profit: ${IndAsFormatter.formatMoney(analysis.grossProfit, ccy)} (${IndAsFormatter.formatPct(analysis.grossMarginPct)})
                - EBITDA: ${IndAsFormatter.formatMoney(analysis.ebitda, ccy)} (${IndAsFormatter.formatPct(analysis.ebitdaMarginPct)}) | EBIT: ${IndAsFormatter.formatMoney(analysis.ebit, ccy)} | PAT: ${IndAsFormatter.formatMoney(analysis.netProfit, ccy)} (${IndAsFormatter.formatPct(analysis.netMarginPct)})
                - Current Ratio: ${IndAsFormatter.formatRatio(analysis.currentRatio)} | Quick Ratio: ${IndAsFormatter.formatRatio(analysis.quickRatio)} | Debt/Equity: ${IndAsFormatter.formatRatio(analysis.debtToEquity)} | ROE: ${IndAsFormatter.formatPct(analysis.roePct)}
                - Cash Conversion Cycle: ${IndAsFormatter.formatDays(analysis.cashConversionCycle)} (DSO ${IndAsFormatter.formatDays(analysis.receivableDays)}, DIO ${IndAsFormatter.formatDays(analysis.inventoryDays)}, DPO ${IndAsFormatter.formatDays(analysis.payableDays)})
                - Operating Cash Flow: ${IndAsFormatter.formatMoney(analysis.operatingCashFlow, ccy)} | Cash Balance: ${IndAsFormatter.formatMoney(analysis.cashAndEquivalents, ccy)}
                - Analyst Summary: ${analysis.executiveSummary}

                ${if (forecast != null) "FP&A OUTLOOK:\n${forecast.expectedSummary}\nBreak-even Monthly Rev: ${IndAsFormatter.formatMoney(forecast.breakEvenMonthlyRevenue, ccy)}\nAssumptions: ${forecast.assumptionsSummary}" else ""}

                ADVISORY ITEMS:
                $advSummary

                STRICT RULE: Never invent figures; clearly label forecasts as projections; maintain authoritative Fiscal Fable CFO tone ready for human CFO review and approval.
            """.trimIndent()

            val response = withTimeout(AI_TIMEOUT_MS) { reportModel.generateContent(prompt) }
            val json = JSONObject(response.text ?: throw IllegalStateException("Empty report draft response."))
            Result.success(
                DraftedReportSections(
                    reportTitle = json.optString("reportTitle", "${client.companyName} — $reportType (${analysis.reportingPeriod})"),
                    executiveSummary = json.optString("executiveSummary"),
                    financialObservations = json.optString("financialObservations"),
                    riskIdentification = json.optString("riskIdentification"),
                    recommendationsText = json.optString("recommendationsText"),
                    managementActionPoints = json.optString("managementActionPoints"),
                    conclusion = json.optString("conclusion")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("CFO Reporting Agent timed out. Please retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Report drafting failed", e)
            Result.failure(e)
        }
    }
}
