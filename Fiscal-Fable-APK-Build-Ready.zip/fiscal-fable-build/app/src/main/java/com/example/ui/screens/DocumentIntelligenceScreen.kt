package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.IndAsFormatter
import com.example.data.model.ClientEntity
import com.example.data.model.DocumentType
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialDocument
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DocumentIntelligenceScreen(
    activeClient: ClientEntity?,
    documents: List<FinancialDocument>,
    figures: List<ExtractedFigure>,
    pendingPeriod: String,
    preferLakhs: Boolean,
    onPeriodChange: (String) -> Unit,
    onUploadUri: (Uri, DocumentType, String) -> Unit,
    onUpdateFigure: (ExtractedFigure, Double, String, Boolean) -> Unit,
    onConfirmHighConfidence: () -> Unit,
    onConfirmAll: () -> Unit,
    onRunAnalysisAfterValidation: () -> Unit
) {
    val context = LocalContext.current
    var selectedDocType by remember { mutableStateOf(DocumentType.PNL) }
    var editingFigure by remember { mutableStateOf<ExtractedFigure?>(null) }

    val docPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onUploadUri(uri, selectedDocType, pendingPeriod)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadUri(uri, selectedDocType, pendingPeriod)
        }
    }

    val unvalidatedCount = figures.count { !it.validated }
    val validatedCount = figures.count { it.validated }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Document Intelligence Engine",
                subtitle = "PDF (OCR), Excel (.xlsx), CSV ingestion & human validation gate",
                badge = "${documents.size} Docs"
            )
        }

        if (activeClient == null) {
            item {
                EmptyVaultCard(
                    title = "Select a Client First",
                    description = "Choose or create a client in the Clients tab before uploading financial statements."
                )
            }
        } else {
            // Upload & Extraction Card
            item {
                FableCard {
                    Text("Upload Client Financial Statement", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Client: ${activeClient.companyName} (${activeClient.currency} · ${activeClient.accountingStandard})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pendingPeriod,
                        onValueChange = onPeriodChange,
                        label = { Text("Reporting Period (e.g., Q2 FY 2025-26)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Statement Classification", style = MaterialTheme.typography.labelMedium)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DocumentType.entries.forEach { dtype ->
                            FilterChip(
                                selected = selectedDocType == dtype,
                                onClick = { selectedDocType = dtype },
                                label = { Text(dtype.name.replace('_', ' '), style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                docPickerLauncher.launch(
                                    arrayOf(
                                        "application/pdf",
                                        "text/csv",
                                        "text/comma-separated-values",
                                        "text/plain",
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/vnd.ms-excel",
                                        "image/*"
                                    )
                                )
                            },
                            modifier = Modifier.weight(1f).testTag("upload_document_button")
                        ) {
                            Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("PDF / Excel / CSV")
                        }
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.weight(1f).testTag("upload_scan_image_button")
                        ) {
                            Icon(Icons.Filled.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Scanned Page")
                        }
                    }
                }
            }

            // Source Documents List
            if (documents.isNotEmpty()) {
                item {
                    Text("Uploaded Source Documents (${documents.size})", style = MaterialTheme.typography.titleMedium)
                }
                items(documents, key = { it.id }) { doc ->
                    FableCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(doc.fileName, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${doc.documentType} · ${doc.reportingPeriod} · ${doc.currency} (${doc.unitScale})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(
                                text = doc.extractionStatus.replace('_', ' '),
                                tone = if (doc.extractionStatus == "VALIDATED") BadgeTone.POSITIVE else BadgeTone.CAUTION
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (doc.ocrUsed) {
                                StatusBadge("Multimodal OCR", BadgeTone.INFO)
                            }
                            StatusBadge("${doc.pageCount} page/sheet", BadgeTone.NEUTRAL)
                        }
                        if (doc.sourceSummary.isNotBlank()) {
                            Text(doc.sourceSummary, style = MaterialTheme.typography.bodySmall)
                        }
                        if (doc.missingFieldsNote.isNotBlank()) {
                            Text(
                                "Missing / Ambiguous: ${doc.missingFieldsNote}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            // Human Validation Gate Workbench
            item {
                FableCard(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Human Validation Workbench", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "$validatedCount Validated · $unvalidatedCount Pending Verification",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            Icons.Filled.DocumentScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (figures.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onConfirmHighConfidence,
                                modifier = Modifier.weight(1f).testTag("confirm_high_conf_button"),
                                enabled = figures.any { !it.validated && it.confidence == "HIGH" }
                            ) {
                                Text("Confirm High-Conf")
                            }
                            Button(
                                onClick = onConfirmAll,
                                modifier = Modifier.weight(1f).testTag("confirm_all_figures_button"),
                                enabled = unvalidatedCount > 0
                            ) {
                                Text("Validate All")
                            }
                        }
                        if (validatedCount > 0) {
                            Button(
                                onClick = onRunAnalysisAfterValidation,
                                modifier = Modifier.fillMaxWidth().testTag("run_analysis_from_docs_button")
                            ) {
                                Text("Run Financial Analysis ($validatedCount Validated Figures)")
                            }
                        }
                    }
                }
            }

            if (figures.isEmpty()) {
                item {
                    EmptyVaultCard(
                        title = "No Extracted Figures Yet",
                        description = "Upload a PDF financial statement, scanned image, Excel (.xlsx), or CSV file above. Every extracted figure retains its source citation and requires your confirmation."
                    )
                }
            } else {
                items(figures, key = { it.id }) { fig ->
                    FableCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(fig.label, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${fig.statementCategory} · ${fig.indAsReference} · Key: ${fig.fieldKey}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = IndAsFormatter.formatMoney(fig.amount, fig.currency, preferLakhs),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Text(
                            text = "Source: ${fig.sourceCitation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (fig.ambiguityNote.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = fig.ambiguityNote,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                StatusBadge(
                                    text = "Conf: ${fig.confidence}",
                                    tone = when (fig.confidence) {
                                        "HIGH" -> BadgeTone.POSITIVE
                                        "MEDIUM" -> BadgeTone.CAUTION
                                        else -> BadgeTone.RISK
                                    }
                                )
                                StatusBadge(
                                    text = if (fig.validated) "Validated" else "Needs Review",
                                    tone = if (fig.validated) BadgeTone.POSITIVE else BadgeTone.CAUTION
                                )
                            }
                            Row {
                                IconButton(onClick = { editingFigure = fig }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Edit extracted figure")
                                }
                                IconButton(
                                    onClick = {
                                        onUpdateFigure(fig, fig.amount, fig.label, !fig.validated)
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (fig.validated) Icons.Filled.CheckCircle else Icons.Filled.Check,
                                        contentDescription = "Toggle validation",
                                        tint = if (fig.validated) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingFigure?.let { fig ->
        FigureEditDialog(
            figure = fig,
            onDismiss = { editingFigure = null },
            onSave = { newAmount, newLabel ->
                onUpdateFigure(fig, newAmount, newLabel, true)
                editingFigure = null
            }
        )
    }
}

@Composable
private fun FigureEditDialog(
    figure: ExtractedFigure,
    onDismiss: () -> Unit,
    onSave: (Double, String) -> Unit
) {
    var label by remember { mutableStateOf(figure.label) }
    var amountStr by remember { mutableStateOf(figure.amount.toBigDecimal().stripTrailingZeros().toPlainString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Verify & Edit Extracted Figure") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Source: ${figure.sourceCitation}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Line Item Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (${figure.currency})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = amountStr.toDoubleOrNull() ?: figure.amount
                    onSave(parsed, label)
                }
            ) {
                Text("Verify & Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
