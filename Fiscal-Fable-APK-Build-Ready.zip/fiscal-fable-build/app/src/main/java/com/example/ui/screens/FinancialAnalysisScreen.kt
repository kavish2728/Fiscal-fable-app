package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.IndAsFormatter
import com.example.data.model.ClientEntity
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.HealthScoreRow
import com.example.ui.components.KpiTile
import com.example.ui.components.ProfitabilityBarChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@Composable
fun FinancialAnalysisScreen(
    activeClient: ClientEntity?,
    figures: List<ExtractedFigure>,
    analyses: List<FinancialAnalysisRecord>,
    preferLakhs: Boolean,
    onRunAnalysis: () -> Unit
) {
    val validatedCount = figures.count { it.validated }
    val unvalidatedCount = figures.count { !it.validated }
    val latest = analyses.maxByOrNull { it.createdAtMillis }
    val prior = analyses.sortedByDescending { it.createdAtMillis }.drop(1).firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Financial Analyst Agent",
                subtitle = "Ind AS Schedule III P&L, 10 financial ratios, working capital & health",
                badge = "${analyses.size} Snapshots"
            )
        }

        if (activeClient == null) {
            item {
                EmptyVaultCard(
                    title = "No Active Client Selected",
                    description = "Select a client in the Clients Directory to perform Ind AS financial analysis."
                )
            }
        } else {
            item {
                FableCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Analysis Trigger", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Uses $validatedCount validated figure(s) ($unvalidatedCount unvalidated excluded).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Button(
                        onClick = onRunAnalysis,
                        enabled = validatedCount > 0,
                        modifier = Modifier.fillMaxWidth().testTag("run_financial_analysis_button")
                    ) {
                        Icon(Icons.Filled.Analytics, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Calculate Ind AS Ratios & Analyze")
                    }
                }
            }

            if (latest == null) {
                item {
                    EmptyVaultCard(
                        title = "No Financial Analysis Yet",
                        description = "Upload financial documents, validate extracted figures, and click 'Calculate Ind AS Ratios & Analyze' above."
                    )
                }
            } else {
                val ccy = latest.currency
                item {
                    FableCard {
                        ProfitabilityBarChart(analysis = latest, preferLakhs = preferLakhs)
                    }
                }

                // Statement of Profit & Loss (Ind AS 1 / Schedule III)
                item {
                    FableCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Statement of Profit & Loss (Ind AS 1)", style = MaterialTheme.typography.titleMedium)
                            StatusBadge(latest.reportingPeriod, BadgeTone.VIOLET)
                        }
                        StatementRow("Revenue from Operations (Ind AS 115)", IndAsFormatter.formatMoney(latest.revenue, ccy, preferLakhs), bold = true)
                        StatementRow("Cost of Goods Sold", IndAsFormatter.formatMoney(latest.cogs, ccy, preferLakhs))
                        StatementRow("Gross Profit", "${IndAsFormatter.formatMoney(latest.grossProfit, ccy, preferLakhs)} (${IndAsFormatter.formatPct(latest.grossMarginPct)})", bold = true)
                        StatementRow("Operating Expenses", IndAsFormatter.formatMoney(latest.operatingExpenses, ccy, preferLakhs))
                        StatementRow("EBITDA", "${IndAsFormatter.formatMoney(latest.ebitda, ccy, preferLakhs)} (${IndAsFormatter.formatPct(latest.ebitdaMarginPct)})", bold = true)
                        StatementRow("Depreciation & Amortisation", IndAsFormatter.formatMoney(latest.depreciation, ccy, preferLakhs))
                        StatementRow("EBIT (Operating Profit)", "${IndAsFormatter.formatMoney(latest.ebit, ccy, preferLakhs)} (${IndAsFormatter.formatPct(latest.operatingMarginPct)})", bold = true)
                        StatementRow("Finance Costs (Interest)", IndAsFormatter.formatMoney(latest.interestExpense, ccy, preferLakhs))
                        StatementRow("Profit Before Tax (PBT)", IndAsFormatter.formatMoney(latest.pbt, ccy, preferLakhs))
                        StatementRow("Tax Expense (Ind AS 12)", IndAsFormatter.formatMoney(latest.taxExpense, ccy, preferLakhs))
                        HorizontalDivider()
                        StatementRow("Net Profit (PAT)", "${IndAsFormatter.formatMoney(latest.netProfit, ccy, preferLakhs)} (${IndAsFormatter.formatPct(latest.netMarginPct)})", bold = true)
                    }
                }

                // 10 Ratios & Working Capital
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            KpiTile("Current Ratio", IndAsFormatter.formatRatio(latest.currentRatio), "Quick: ${IndAsFormatter.formatRatio(latest.quickRatio)}", BadgeTone.INFO, Modifier.weight(1f))
                            KpiTile("Debt / Equity", IndAsFormatter.formatRatio(latest.debtToEquity), "ICR: ${IndAsFormatter.formatRatio(latest.interestCoverage)}", BadgeTone.VIOLET, Modifier.weight(1f))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            KpiTile("ROE / ROA", IndAsFormatter.formatPct(latest.roePct), "ROA: ${IndAsFormatter.formatPct(latest.roaPct)}", BadgeTone.POSITIVE, Modifier.weight(1f))
                            KpiTile("Cash Cycle (CCC)", IndAsFormatter.formatDays(latest.cashConversionCycle), "NWC: ${IndAsFormatter.formatCompactNumber(latest.workingCapital, ccy)}", BadgeTone.CAUTION, Modifier.weight(1f))
                        }
                    }
                }

                item {
                    FableCard {
                        Text("Working Capital Efficiency", style = MaterialTheme.typography.titleMedium)
                        StatementRow("Accounts Receivable Days (DSO)", IndAsFormatter.formatDays(latest.receivableDays))
                        StatementRow("Inventory Days (DIO)", IndAsFormatter.formatDays(latest.inventoryDays))
                        StatementRow("Accounts Payable Days (DPO)", IndAsFormatter.formatDays(latest.payableDays))
                        HorizontalDivider()
                        StatementRow("Cash Conversion Cycle (DSO + DIO - DPO)", IndAsFormatter.formatDays(latest.cashConversionCycle), bold = true)
                        StatementRow("Net Working Capital", IndAsFormatter.formatMoney(latest.workingCapital, ccy, preferLakhs), bold = true)
                    }
                }

                // 5-Pillar Financial Health
                item {
                    FableCard {
                        Text("5-Pillar Financial Health Assessment", style = MaterialTheme.typography.titleMedium)
                        HealthScoreRow("Profitability", latest.profitabilityScore.toInt())
                        HealthScoreRow("Liquidity", latest.liquidityScore.toInt())
                        HealthScoreRow("Solvency", latest.solvencyScore.toInt())
                        HealthScoreRow("Operational Efficiency", latest.efficiencyScore.toInt())
                        HealthScoreRow("Financial Stability", latest.stabilityScore.toInt())
                    }
                }

                // Historical Comparison if available
                if (prior != null) {
                    item {
                        FableCard {
                            Text("Historical Period Comparison (${prior.reportingPeriod} → ${latest.reportingPeriod})", style = MaterialTheme.typography.titleMedium)
                            val revDelta = latest.revenue - prior.revenue
                            val patDelta = latest.netProfit - prior.netProfit
                            StatementRow("Revenue Variance", IndAsFormatter.formatMoney(revDelta, ccy, preferLakhs), bold = true)
                            StatementRow("EBITDA Margin Shift", "${IndAsFormatter.formatPct(latest.ebitdaMarginPct - prior.ebitdaMarginPct)}")
                            StatementRow("Net Profit Variance", IndAsFormatter.formatMoney(patDelta, ccy, preferLakhs), bold = true)
                        }
                    }
                }

                // AI Financial Analyst Commentary
                item {
                    FableCard {
                        Text("Financial Analyst Agent Commentary", style = MaterialTheme.typography.titleMedium)
                        Text(latest.executiveSummary, style = MaterialTheme.typography.bodyMedium)
                        if (latest.trendCommentary.isNotBlank()) {
                            Text("Trend & Variance Insights", style = MaterialTheme.typography.titleSmall)
                            Text(latest.trendCommentary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (latest.unusualMovements.isNotEmpty()) {
                            Text("Unusual Movements Flagged", style = MaterialTheme.typography.titleSmall)
                            latest.unusualMovements.forEach { flag ->
                                Text("• $flag", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (latest.indAsNotes.isNotEmpty()) {
                            Text("Ind AS & Schedule III Notes", style = MaterialTheme.typography.titleSmall)
                            latest.indAsNotes.forEach { note ->
                                Text("• $note", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatementRow(label: String, value: String, bold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.labelSmall,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            color = if (bold) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}
