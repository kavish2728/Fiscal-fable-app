package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ApprovalAuditLog
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoProfile
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.DocumentType
import com.example.data.model.ExtractionStatus
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FinancialDocument
import com.example.data.model.FpaForecastRecord
import com.example.data.model.WorkspaceSection
import com.example.data.repository.CfoAiAgentsRepository
import com.example.data.repository.CfoLocalRepository
import com.example.domain.DocumentParser
import com.example.domain.FinancialCalculator
import com.example.domain.ParsedDocumentContent
import com.example.domain.ReportExporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface UiStreamState<out T> {
    data object Loading : UiStreamState<Nothing>
    data class Success<T>(val data: T) : UiStreamState<T>
    data class Error(val message: String) : UiStreamState<Nothing>
}

data class AgentTaskStatus(
    val busy: Boolean = false,
    val message: String = ""
)

@OptIn(ExperimentalCoroutinesApi::class)
class FiscalFableViewModel(
    private val localRepo: CfoLocalRepository,
    private val aiRepo: CfoAiAgentsRepository
) : ViewModel() {

    companion object {
        private const val TAG = "FiscalFableVM"
        private const val STOP_TIMEOUT_MS = 5000L
    }

    private val _selectedSection = MutableStateFlow(WorkspaceSection.OVERVIEW)
    val selectedSection: StateFlow<WorkspaceSection> = _selectedSection.asStateFlow()

    private val _selectedClientId = MutableStateFlow<String?>(null)
    val selectedClientId: StateFlow<String?> = _selectedClientId.asStateFlow()

    private val _agentTask = MutableStateFlow(AgentTaskStatus())
    val agentTask: StateFlow<AgentTaskStatus> = _agentTask.asStateFlow()

    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    private val _errorBanner = MutableStateFlow<String?>(null)
    val errorBanner: StateFlow<String?> = _errorBanner.asStateFlow()

    private val _preferLakhsCrores = MutableStateFlow(true)
    val preferLakhsCrores: StateFlow<Boolean> = _preferLakhsCrores.asStateFlow()

    private val _pendingUploadPeriod = MutableStateFlow("Q2 FY 2025-26")
    val pendingUploadPeriod: StateFlow<String> = _pendingUploadPeriod.asStateFlow()

    private val _selectedReportForEdit = MutableStateFlow<CfoReportRecord?>(null)
    val selectedReportForEdit: StateFlow<CfoReportRecord?> = _selectedReportForEdit.asStateFlow()

    val cfoProfile: StateFlow<CfoProfile> =
        localRepo.observeProfile()
            .catch { emit(CfoProfile()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), CfoProfile())

    private fun <T> Flow<List<T>>.toUiState(label: String): StateFlow<UiStreamState<List<T>>> =
        this.map<List<T>, UiStreamState<List<T>>> { UiStreamState.Success(it) }
            .catch { error ->
                if (error is CancellationException) throw error
                Log.w(TAG, "Stream failure ($label)", error)
                emit(UiStreamState.Error(error.message ?: "Failed to load $label"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiStreamState.Loading)

    val clientsState: StateFlow<UiStreamState<List<ClientEntity>>> =
        localRepo.observeClients()
            .map { list ->
                val sorted = list.sortedBy { it.companyName.lowercase() }
                if (_selectedClientId.value == null && sorted.isNotEmpty()) {
                    _selectedClientId.value = sorted.first().id
                    _pendingUploadPeriod.value = sorted.first().accountingPeriod.ifBlank { "Q2 FY 2025-26" }
                } else if (_selectedClientId.value != null && sorted.none { it.id == _selectedClientId.value }) {
                    _selectedClientId.value = sorted.firstOrNull()?.id
                }
                sorted
            }
            .toUiState("clients")

    val documentsState: StateFlow<UiStreamState<List<FinancialDocument>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeDocuments(cid)
        }.toUiState("documents")

    val extractedFiguresState: StateFlow<UiStreamState<List<ExtractedFigure>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeExtractedFigures(cid)
        }.toUiState("extracted figures")

    val analysesState: StateFlow<UiStreamState<List<FinancialAnalysisRecord>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeAnalyses(cid)
        }.toUiState("financial analyses")

    val forecastsState: StateFlow<UiStreamState<List<FpaForecastRecord>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeForecasts(cid)
        }.toUiState("forecasts")

    val advisoriesState: StateFlow<UiStreamState<List<BusinessAdvisoryItem>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeAdvisories(cid)
        }.toUiState("advisories")

    val reportsState: StateFlow<UiStreamState<List<CfoReportRecord>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeReports(cid)
        }.toUiState("reports")

    val auditLogsState: StateFlow<UiStreamState<List<ApprovalAuditLog>>> =
        _selectedClientId.flatMapLatest { cid ->
            if (cid.isNullOrBlank()) flowOf(emptyList())
            else localRepo.observeAuditLogs(cid)
        }.toUiState("audit logs")

    fun selectSection(section: WorkspaceSection) {
        _selectedSection.value = section
    }

    fun selectClient(client: ClientEntity) {
        _selectedClientId.value = client.id
        _pendingUploadPeriod.value = client.accountingPeriod.ifBlank { "Q2 FY 2025-26" }
        _selectedReportForEdit.value = null
    }

    fun toggleLakhsCrores(enabled: Boolean) {
        _preferLakhsCrores.value = enabled
        viewModelScope.launch {
            localRepo.saveProfile(cfoProfile.value.copy(preferLakhsCrores = enabled))
        }
    }

    fun updateCfoProfile(name: String, title: String) {
        viewModelScope.launch {
            localRepo.saveProfile(
                cfoProfile.value.copy(
                    partnerName = name,
                    partnerTitle = title
                )
            ).onSuccess {
                _bannerMessage.value = "Saved on-device CFO Partner profile."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save profile."
            }
        }
    }

    fun setPendingUploadPeriod(period: String) {
        _pendingUploadPeriod.value = period
    }

    fun dismissBanners() {
        _bannerMessage.value = null
        _errorBanner.value = null
    }

    fun openReportEditor(report: CfoReportRecord?) {
        _selectedReportForEdit.value = report
    }

    private fun actorName(): String =
        cfoProfile.value.partnerName.ifBlank { "Managing CFO Partner" }

    private fun actorRoleLabel(): String =
        cfoProfile.value.partnerTitle.ifBlank { "On-Device CFO" }

    fun createClient(client: ClientEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Creating isolated client workspace...")
            val res = localRepo.createClient(client)
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess { newId ->
                _selectedClientId.value = newId
                _pendingUploadPeriod.value = client.accountingPeriod
                _bannerMessage.value = "Client '${client.companyName}' created in private on-device vault."
                onDone()
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to create client."
            }
        }
    }

    fun updateClient(client: ClientEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Updating client profile...")
            val res = localRepo.updateClient(client)
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                _bannerMessage.value = "Updated profile for ${client.companyName}."
                onDone()
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to update client."
            }
        }
    }

    fun processUploadedDocument(
        context: Context,
        uri: Uri,
        client: ClientEntity,
        docType: DocumentType,
        reportingPeriod: String
    ) {
        viewModelScope.launch {
            _errorBanner.value = null
            _agentTask.value = AgentTaskStatus(true, "Reading document & preparing OCR / table parser...")
            val parsedResult = DocumentParser.parseUri(context, uri)
            if (parsedResult.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = parsedResult.exceptionOrNull()?.localizedMessage ?: "Failed to parse file."
                return@launch
            }
            val parsed = parsedResult.getOrThrow()
            val fileName = when (parsed) {
                is ParsedDocumentContent.TextTable -> parsed.fileName
                is ParsedDocumentContent.PageImages -> parsed.fileName
            }
            val mimeType = when (parsed) {
                is ParsedDocumentContent.TextTable -> parsed.mimeType
                is ParsedDocumentContent.PageImages -> parsed.mimeType
            }
            val pages = when (parsed) {
                is ParsedDocumentContent.TextTable -> parsed.pageOrSheetCount.toLong()
                is ParsedDocumentContent.PageImages -> parsed.totalPages.toLong()
            }
            val ocrUsed = when (parsed) {
                is ParsedDocumentContent.TextTable -> parsed.ocrRequired
                is ParsedDocumentContent.PageImages -> parsed.ocrRequired
            }

            _agentTask.value = AgentTaskStatus(
                true,
                if (ocrUsed) "Document Intelligence Agent running multimodal OCR & Ind AS mapping..."
                else "Document Intelligence Agent mapping Excel/CSV figures to Ind AS Schedule III..."
            )

            val aiResult = aiRepo.extractFinancialDocument(client, docType, reportingPeriod, parsed)
            if (aiResult.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = aiResult.exceptionOrNull()?.localizedMessage
                    ?: "Document Intelligence extraction failed."
                return@launch
            }
            val extracted = aiResult.getOrThrow()

            val doc = FinancialDocument(
                clientId = client.id,
                fileName = fileName,
                mimeType = mimeType,
                documentType = docType.name,
                reportingPeriod = extracted.detectedPeriod,
                currency = extracted.detectedCurrency,
                unitScale = extracted.detectedUnitScale.name,
                extractionStatus = if (extracted.figures.isEmpty()) {
                    ExtractionStatus.FAILED.name
                } else {
                    ExtractionStatus.NEEDS_VALIDATION.name
                },
                ocrUsed = ocrUsed,
                pageCount = pages,
                sourceSummary = extracted.sourceSummary,
                missingFieldsNote = extracted.missingFieldsNote
            )

            val saveRes = localRepo.saveDocumentAndFigures(client.id, doc, extracted.figures)
            _agentTask.value = AgentTaskStatus(false)
            saveRes.onSuccess {
                _bannerMessage.value = "Extracted ${extracted.figures.size} line items from $fileName. Please validate figures below before running analysis."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save extracted figures."
            }
        }
    }

    fun updateAndValidateFigure(
        clientId: String,
        figure: ExtractedFigure,
        newAmount: Double,
        newLabel: String,
        validated: Boolean
    ) {
        viewModelScope.launch {
            val res = localRepo.updateExtractedFigure(
                clientId = clientId,
                figureId = figure.id,
                amount = newAmount,
                label = newLabel,
                validated = validated,
                validatedBy = if (validated) actorName() else ""
            )
            res.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to update figure."
            }
        }
    }

    fun confirmAllHighConfidence(
        clientId: String,
        figures: List<ExtractedFigure>,
        documents: List<FinancialDocument>
    ) {
        val targetFigs = figures.filter { !it.validated && it.confidence == "HIGH" }
        if (targetFigs.isEmpty()) {
            _bannerMessage.value = "No unvalidated HIGH-confidence figures pending."
            return
        }
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Validating ${targetFigs.size} high-confidence figures...")
            val docIds = documents.filter { d ->
                figures.filter { it.documentId == d.id }.all { it.validated || it.id in targetFigs.map { f -> f.id } }
            }.map { it.id }
            val res = localRepo.validateAllFigures(
                clientId = clientId,
                figureIds = targetFigs.map { it.id },
                documentIds = docIds,
                validatedBy = actorName()
            )
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                _bannerMessage.value = "Confirmed ${targetFigs.size} high-confidence figures."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to confirm figures."
            }
        }
    }

    fun confirmAllFigures(
        clientId: String,
        figures: List<ExtractedFigure>,
        documents: List<FinancialDocument>
    ) {
        val unvalidated = figures.filter { !it.validated }
        if (unvalidated.isEmpty()) return
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Validating ${unvalidated.size} figures...")
            val res = localRepo.validateAllFigures(
                clientId = clientId,
                figureIds = unvalidated.map { it.id },
                documentIds = documents.map { it.id },
                validatedBy = actorName()
            )
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                _bannerMessage.value = "All ${unvalidated.size} figures validated by ${actorName()}."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Validation failed."
            }
        }
    }

    fun runFinancialAnalysis(
        client: ClientEntity,
        figures: List<ExtractedFigure>,
        priorAnalyses: List<FinancialAnalysisRecord>,
        periodDays: Double = 90.0
    ) {
        val validated = figures.filter { it.validated }
        if (validated.isEmpty()) {
            _errorBanner.value = "Validation Gate: Please validate extracted figures in Document Intelligence before running Financial Analysis."
            return
        }
        viewModelScope.launch {
            _errorBanner.value = null
            _agentTask.value = AgentTaskStatus(true, "Computing deterministic Ind AS ratios & invoking Financial Analyst Agent...")
            val metrics = FinancialCalculator.computeFromValidatedFigures(validated, periodDays)
            val period = validated.firstOrNull()?.reportingPeriod?.ifBlank { client.accountingPeriod }
                ?: client.accountingPeriod

            val narrativeRes = aiRepo.analyzeFinancials(client, period, metrics, priorAnalyses)
            if (narrativeRes.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = narrativeRes.exceptionOrNull()?.localizedMessage ?: "Analyst Agent failed."
                return@launch
            }
            val narrative = narrativeRes.getOrThrow()

            val record = FinancialAnalysisRecord(
                clientId = client.id,
                reportingPeriod = period,
                currency = client.currency,
                revenue = metrics.revenue,
                cogs = metrics.cogs,
                grossProfit = metrics.grossProfit,
                operatingExpenses = metrics.operatingExpenses,
                ebitda = metrics.ebitda,
                depreciation = metrics.depreciation,
                ebit = metrics.ebit,
                interestExpense = metrics.interestExpense,
                pbt = metrics.pbt,
                taxExpense = metrics.taxExpense,
                netProfit = metrics.netProfit,
                totalAssets = metrics.totalAssets,
                currentAssets = metrics.currentAssets,
                inventory = metrics.inventory,
                tradeReceivables = metrics.tradeReceivables,
                cashAndEquivalents = metrics.cashAndEquivalents,
                totalEquity = metrics.totalEquity,
                totalDebt = metrics.totalDebt,
                currentLiabilities = metrics.currentLiabilities,
                tradePayables = metrics.tradePayables,
                operatingCashFlow = metrics.operatingCashFlow,
                investingCashFlow = metrics.investingCashFlow,
                financingCashFlow = metrics.financingCashFlow,
                grossMarginPct = metrics.grossMarginPct,
                ebitdaMarginPct = metrics.ebitdaMarginPct,
                operatingMarginPct = metrics.operatingMarginPct,
                netMarginPct = metrics.netMarginPct,
                currentRatio = metrics.currentRatio,
                quickRatio = metrics.quickRatio,
                debtToEquity = metrics.debtToEquity,
                interestCoverage = metrics.interestCoverage,
                roaPct = metrics.roaPct,
                roePct = metrics.roePct,
                receivableDays = metrics.receivableDays,
                inventoryDays = metrics.inventoryDays,
                payableDays = metrics.payableDays,
                cashConversionCycle = metrics.cashConversionCycle,
                workingCapital = metrics.workingCapital,
                profitabilityScore = metrics.profitabilityScore.toLong(),
                liquidityScore = metrics.liquidityScore.toLong(),
                solvencyScore = metrics.solvencyScore.toLong(),
                efficiencyScore = metrics.efficiencyScore.toLong(),
                stabilityScore = metrics.stabilityScore.toLong(),
                executiveSummary = narrative.executiveSummary,
                trendCommentary = narrative.trendCommentary,
                unusualMovements = narrative.unusualMovements,
                indAsNotes = narrative.indAsNotes
            )

            val saveRes = localRepo.saveAnalysis(client.id, record)
            _agentTask.value = AgentTaskStatus(false)
            saveRes.onSuccess {
                _bannerMessage.value = "Ind AS Financial Analysis saved for $period."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save analysis."
            }
        }
    }

    fun runFpaForecast(
        client: ClientEntity,
        latestAnalysis: FinancialAnalysisRecord?,
        horizonMonths: Int,
        expectedGrowthPct: Double,
        cogsPct: Double,
        opexGrowthPct: Double,
        targetDsoDays: Double
    ) {
        if (latestAnalysis == null) {
            _errorBanner.value = "Run Financial Analysis on validated figures before generating FP&A scenarios."
            return
        }
        viewModelScope.launch {
            _errorBanner.value = null
            _agentTask.value = AgentTaskStatus(true, "FP&A Agent building 3-scenario cash flow & break-even model...")
            val projections = FinancialCalculator.buildDeterministicProjections(
                latestAnalysis = latestAnalysis,
                horizonMonths = horizonMonths,
                expectedGrowthAnnualPct = expectedGrowthPct,
                cogsPctOfRevenue = cogsPct,
                opexGrowthAnnualPct = opexGrowthPct
            )
            val monthlyFixedCosts = (latestAnalysis.operatingExpenses + latestAnalysis.interestExpense) / 3.0
            val breakEvenRev = FinancialCalculator.calculateBreakEvenMonthlyRevenue(monthlyFixedCosts, cogsPct)
            val lastPoint = projections.lastOrNull()

            val commentaryRes = aiRepo.generateFpaCommentary(
                client = client,
                analysis = latestAnalysis,
                horizonMonths = horizonMonths,
                growthExpectedPct = expectedGrowthPct,
                cogsPct = cogsPct,
                opexGrowthPct = opexGrowthPct,
                targetDsoDays = targetDsoDays,
                breakEvenMonthlyRev = breakEvenRev,
                endConservativeCash = lastPoint?.conservativeCash ?: 0.0,
                endExpectedCash = lastPoint?.expectedCash ?: 0.0,
                endOptimisticCash = lastPoint?.optimisticCash ?: 0.0
            )
            if (commentaryRes.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = commentaryRes.exceptionOrNull()?.localizedMessage ?: "FP&A Agent failed."
                return@launch
            }
            val comm = commentaryRes.getOrThrow()

            val forecastRecord = FpaForecastRecord(
                clientId = client.id,
                reportingPeriod = latestAnalysis.reportingPeriod,
                horizonMonths = horizonMonths.toLong(),
                revenueGrowthExpectedPct = expectedGrowthPct,
                cogsPctOfRevenue = cogsPct,
                opexGrowthPct = opexGrowthPct,
                targetDsoDays = targetDsoDays,
                monthlyFixedCosts = monthlyFixedCosts,
                breakEvenMonthlyRevenue = breakEvenRev,
                assumptionsSummary = comm.assumptionsSummary,
                conservativeSummary = comm.conservativeSummary,
                expectedSummary = comm.expectedSummary,
                optimisticSummary = comm.optimisticSummary,
                projections = projections
            )

            val saveRes = localRepo.saveForecast(client.id, forecastRecord)
            _agentTask.value = AgentTaskStatus(false)
            saveRes.onSuccess {
                _bannerMessage.value = "$horizonMonths-month Conservative / Expected / Optimistic forecast saved."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save FP&A forecast."
            }
        }
    }

    fun runBusinessAdvisor(
        client: ClientEntity,
        latestAnalysis: FinancialAnalysisRecord?,
        latestForecast: FpaForecastRecord?
    ) {
        if (latestAnalysis == null) {
            _errorBanner.value = "Run Financial Analysis on validated figures before generating Business Advisory."
            return
        }
        viewModelScope.launch {
            _errorBanner.value = null
            _agentTask.value = AgentTaskStatus(true, "Business Advisor Agent diagnosing risks, working capital & growth levers...")
            val aiRes = aiRepo.generateAdvisories(client, latestAnalysis, latestForecast)
            if (aiRes.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = aiRes.exceptionOrNull()?.localizedMessage ?: "Business Advisor Agent failed."
                return@launch
            }
            val items = aiRes.getOrThrow()
            val saveRes = localRepo.saveAdvisories(client.id, items)
            _agentTask.value = AgentTaskStatus(false)
            saveRes.onSuccess {
                _bannerMessage.value = "Generated ${items.size} structured CFO advisory recommendations."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save advisories."
            }
        }
    }

    fun updateAdvisoryStatus(clientId: String, item: BusinessAdvisoryItem, newStatus: String) {
        viewModelScope.launch {
            val res = localRepo.updateAdvisoryStatus(clientId, item.id, newStatus)
            res.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to update action status."
            }
        }
    }

    fun generateCfoReport(
        client: ClientEntity,
        reportType: String,
        latestAnalysis: FinancialAnalysisRecord?,
        latestForecast: FpaForecastRecord?,
        advisories: List<BusinessAdvisoryItem>
    ) {
        if (latestAnalysis == null) {
            _errorBanner.value = "Please run Financial Analysis on validated figures before generating a CFO report."
            return
        }
        viewModelScope.launch {
            _errorBanner.value = null
            _agentTask.value = AgentTaskStatus(true, "CFO Reporting Agent drafting $reportType...")
            val draftRes = aiRepo.draftCfoReport(client, reportType, latestAnalysis, latestForecast, advisories)
            if (draftRes.isFailure) {
                _agentTask.value = AgentTaskStatus(false)
                _errorBanner.value = draftRes.exceptionOrNull()?.localizedMessage ?: "CFO Reporting Agent failed."
                return@launch
            }
            val drafted = draftRes.getOrThrow()
            val report = CfoReportRecord(
                clientId = client.id,
                clientName = client.companyName,
                reportType = reportType,
                reportTitle = drafted.reportTitle,
                reportingPeriod = latestAnalysis.reportingPeriod,
                currency = client.currency,
                executiveSummary = drafted.executiveSummary,
                financialObservations = drafted.financialObservations,
                riskIdentification = drafted.riskIdentification,
                recommendationsText = drafted.recommendationsText,
                managementActionPoints = drafted.managementActionPoints,
                conclusion = drafted.conclusion,
                reviewStatus = "DRAFT"
            )

            val saveRes = localRepo.createReport(client.id, report, actorName(), actorRoleLabel())
            _agentTask.value = AgentTaskStatus(false)
            saveRes.onSuccess {
                _bannerMessage.value = "Draft '$reportType' created. Review, edit, and approve in Reports or Approvals."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to save report draft."
            }
        }
    }

    fun saveReportEdits(
        clientId: String,
        edited: CfoReportRecord,
        newStatus: String,
        actionLabel: String,
        auditNotes: String
    ) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Saving report revision...")
            val res = localRepo.updateReportDraft(
                clientId = clientId,
                report = edited,
                newStatus = newStatus,
                actionLabel = actionLabel,
                actorName = actorName(),
                actorRoleLabel = actorRoleLabel(),
                auditNotes = auditNotes
            )
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                _selectedReportForEdit.value = null
                _bannerMessage.value = "Report '${edited.reportTitle}' updated ($newStatus)."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Failed to update report."
            }
        }
    }

    fun approveReport(clientId: String, report: CfoReportRecord, reviewNotes: String) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Recording CFO approval & locking report...")
            val stamp = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date())
            val res = localRepo.approveReport(
                clientId = clientId,
                report = report,
                approverName = actorName(),
                approverRoleLabel = actorRoleLabel(),
                approvedAtLabel = stamp,
                reviewNotes = reviewNotes
            )
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                _selectedReportForEdit.value = null
                _bannerMessage.value = "Approved '${report.reportTitle}'. PDF and Excel delivery exports unlocked."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Approval failed."
            }
        }
    }

    fun exportReportPdf(
        context: Context,
        uri: Uri,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?
    ) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Generating branded Fiscal Fable PDF report...")
            val res = ReportExporter.exportPdfToUri(context, uri, report, client, analysis)
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                if (client != null) {
                    localRepo.logExportAudit(client.id, report, "EXPORTED_PDF", actorName(), actorRoleLabel())
                }
                _bannerMessage.value = "PDF exported successfully."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "PDF export failed."
            }
        }
    }

    fun exportReportExcel(
        context: Context,
        uri: Uri,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?,
        forecast: FpaForecastRecord?,
        advisories: List<BusinessAdvisoryItem>
    ) {
        viewModelScope.launch {
            _agentTask.value = AgentTaskStatus(true, "Generating multi-sheet Excel (.xlsx) workbook...")
            val res = ReportExporter.exportExcelToUri(context, uri, report, client, analysis, forecast, advisories)
            _agentTask.value = AgentTaskStatus(false)
            res.onSuccess {
                if (client != null) {
                    localRepo.logExportAudit(client.id, report, "EXPORTED_EXCEL", actorName(), actorRoleLabel())
                }
                _bannerMessage.value = "Excel (.xlsx) workbook exported successfully."
            }.onFailure { e ->
                _errorBanner.value = e.localizedMessage ?: "Excel export failed."
            }
        }
    }
}
