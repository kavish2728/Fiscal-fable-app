package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ALL_CFO_REPORT_TYPES
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.FinancialAnalysisRecord
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsScreen(
    activeClient: ClientEntity?,
    latestAnalysis: FinancialAnalysisRecord?,
    reports: List<CfoReportRecord>,
    editingReport: CfoReportRecord?,
    onOpenEditor: (CfoReportRecord?) -> Unit,
    onGenerateReport: (String) -> Unit,
    onSaveDraftEdits: (CfoReportRecord, String, String, String) -> Unit,
    onExportPdf: (android.net.Uri, CfoReportRecord) -> Unit,
    onExportExcel: (android.net.Uri, CfoReportRecord) -> Unit
) {
    var selectedType by remember { mutableStateOf(ALL_CFO_REPORT_TYPES[1]) }
    var pendingExportReport by remember { mutableStateOf<CfoReportRecord?>(null) }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val rep = pendingExportReport
        if (uri != null && rep != null) {
            onExportPdf(uri, rep)
        }
        pendingExportReport = null
    }

    val excelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri ->
        val rep = pendingExportReport
        if (uri != null && rep != null) {
            onExportExcel(uri, rep)
        }
        pendingExportReport = null
    }

    if (editingReport != null) {
        BackHandler { onOpenEditor(null) }
        ReportEditorView(
            report = editingReport,
            onBack = { onOpenEditor(null) },
            onSave = onSaveDraftEdits,
            onExportPdf = {
                pendingExportReport = editingReport
                pdfLauncher.launch("${editingReport.clientName.replace(' ', '_')}_${editingReport.reportingPeriod}.pdf")
            },
            onExportExcel = {
                pendingExportReport = editingReport
                excelLauncher.launch("${editingReport.clientName.replace(' ', '_')}_${editingReport.reportingPeriod}.xlsx")
            }
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "CFO Report Generator",
                subtitle = "12 executive Ind AS report packs with mandatory CFO review gate",
                badge = "${reports.size} Reports"
            )
        }

        if (activeClient == null || latestAnalysis == null) {
            item {
                EmptyVaultCard(
                    title = "Validated Financial Analysis Required",
                    description = "Complete Document Validation and Financial Analysis first so CFO reports reflect verified Ind AS figures."
                )
            }
        } else {
            item {
                FableCard {
                    Text("Select Report Template (12 Formats)", style = MaterialTheme.typography.titleMedium)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        ALL_CFO_REPORT_TYPES.forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(type, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Button(
                        onClick = { onGenerateReport(selectedType) },
                        modifier = Modifier.fillMaxWidth().testTag("generate_cfo_report_button")
                    ) {
                        Icon(Icons.Filled.Description, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Draft $selectedType")
                    }
                }
            }

            if (reports.isEmpty()) {
                item {
                    EmptyVaultCard(
                        title = "No CFO Reports Drafted",
                        description = "Choose any of the 12 templates above to draft a Fiscal Fable CFO branded pack ready for review and approval."
                    )
                }
            } else {
                items(reports, key = { it.id }) { rep ->
                    val approved = rep.reviewStatus == "APPROVED"
                    FableCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rep.reportTitle, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${rep.reportType} · ${rep.reportingPeriod}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(
                                text = rep.reviewStatus.replace('_', ' '),
                                tone = when (rep.reviewStatus) {
                                    "APPROVED" -> BadgeTone.POSITIVE
                                    "CHANGES_REQUESTED" -> BadgeTone.RISK
                                    "IN_REVIEW" -> BadgeTone.INFO
                                    else -> BadgeTone.CAUTION
                                }
                            )
                        }
                        Text(
                            text = rep.executiveSummary,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 3
                        )
                        if (approved) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Approved by ${rep.approvedBy} (${rep.approvedAtLabel})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Client delivery export locked until CFO approval",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onOpenEditor(rep) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (approved) "View" else "Edit / Review")
                            }
                            Button(
                                onClick = {
                                    pendingExportReport = rep
                                    pdfLauncher.launch("${rep.clientName.replace(' ', '_')}_${rep.reportingPeriod}.pdf")
                                },
                                enabled = approved,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("PDF")
                            }
                            OutlinedButton(
                                onClick = {
                                    pendingExportReport = rep
                                    excelLauncher.launch("${rep.clientName.replace(' ', '_')}_${rep.reportingPeriod}.xlsx")
                                },
                                enabled = approved,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.TableView, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Excel")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportEditorView(
    report: CfoReportRecord,
    onBack: () -> Unit,
    onSave: (CfoReportRecord, String, String, String) -> Unit,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val locked = report.reviewStatus == "APPROVED"
    var title by remember(report.id) { mutableStateOf(report.reportTitle) }
    var execSummary by remember(report.id) { mutableStateOf(report.executiveSummary) }
    var observations by remember(report.id) { mutableStateOf(report.financialObservations) }
    var risks by remember(report.id) { mutableStateOf(report.riskIdentification) }
    var recs by remember(report.id) { mutableStateOf(report.recommendationsText) }
    var actions by remember(report.id) { mutableStateOf(report.managementActionPoints) }
    var conclusion by remember(report.id) { mutableStateOf(report.conclusion) }
    var notes by remember(report.id) { mutableStateOf(report.cfoReviewNotes) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to reports")
                    }
                    Column {
                        Text("FISCAL FABLE CFO REPORT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(report.reportType, style = MaterialTheme.typography.titleMedium)
                    }
                }
                StatusBadge(report.reviewStatus, if (locked) BadgeTone.POSITIVE else BadgeTone.CAUTION)
            }
        }

        item {
            FableCard {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Report Title") },
                    enabled = !locked,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = execSummary,
                    onValueChange = { execSummary = it },
                    label = { Text("1. Executive Summary") },
                    enabled = !locked,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = observations,
                    onValueChange = { observations = it },
                    label = { Text("2. Key Financial Observations") },
                    enabled = !locked,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = risks,
                    onValueChange = { risks = it },
                    label = { Text("3. Risk Identification & Ind AS Controls") },
                    enabled = !locked,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = recs,
                    onValueChange = { recs = it },
                    label = { Text("4. Strategic Recommendations") },
                    enabled = !locked,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = actions,
                    onValueChange = { actions = it },
                    label = { Text("5. Management Action Points") },
                    enabled = !locked,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = conclusion,
                    onValueChange = { conclusion = it },
                    label = { Text("6. CFO Conclusion") },
                    enabled = !locked,
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Internal CFO Review Notes") },
                    enabled = !locked,
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider()
                if (!locked) {
                    val updated = report.copy(
                        reportTitle = title,
                        executiveSummary = execSummary,
                        financialObservations = observations,
                        riskIdentification = risks,
                        recommendationsText = recs,
                        managementActionPoints = actions,
                        conclusion = conclusion,
                        cfoReviewNotes = notes
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onSave(updated, "DRAFT", "EDITED", "Saved draft revisions.") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save Draft")
                        }
                        Button(
                            onClick = { onSave(updated, "IN_REVIEW", "SUBMITTED_FOR_REVIEW", "Submitted for CFO partner approval.") },
                            modifier = Modifier.weight(1f).testTag("submit_for_approval_button")
                        ) {
                            Text("Submit for Approval")
                        }
                    }
                } else {
                    Text(
                        "Locked & Approved by ${report.approvedBy} (${report.approvedByEmail}) on ${report.approvedAtLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(onClick = onExportPdf, modifier = Modifier.weight(1f)) {
                            Text("Export PDF")
                        }
                        OutlinedButton(onClick = onExportExcel, modifier = Modifier.weight(1f)) {
                            Text("Export Excel")
                        }
                    }
                }
            }
        }
    }
}
