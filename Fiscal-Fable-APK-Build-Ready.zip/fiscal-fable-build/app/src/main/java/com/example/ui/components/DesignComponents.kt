package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.IndAsFormatter
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FpaProjectionPoint
import com.example.ui.theme.AmberCaution
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPositive
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.SlateContainer
import com.example.ui.theme.SlateInfo
import com.example.ui.theme.SoftIris
import kotlin.math.max
import kotlin.math.min

@Composable
fun FableCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = containerColor,
        tonalElevation = 1.dp,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    badge: String? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!badge.isNullOrBlank()) {
            Spacer(Modifier.width(8.dp))
            StatusBadge(text = badge, tone = BadgeTone.VIOLET)
        }
    }
}

enum class BadgeTone { VIOLET, POSITIVE, CAUTION, RISK, INFO, NEUTRAL }

@Composable
fun StatusBadge(
    text: String,
    tone: BadgeTone = BadgeTone.VIOLET
) {
    val (bg, fg) = when (tone) {
        BadgeTone.VIOLET -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        BadgeTone.POSITIVE -> EmeraldContainer to EmeraldPositive
        BadgeTone.CAUTION -> AmberContainer to AmberCaution
        BadgeTone.RISK -> CrimsonContainer to CrimsonRisk
        BadgeTone.INFO -> SlateContainer to SlateInfo
        BadgeTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = bg
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun KpiTile(
    label: String,
    value: String,
    caption: String,
    tone: BadgeTone = BadgeTone.VIOLET,
    modifier: Modifier = Modifier
) {
    FableCard(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        StatusBadge(text = caption, tone = tone)
    }
}

@Composable
fun HealthScoreRow(
    label: String,
    score: Int
) {
    val barColor = when {
        score >= 70 -> EmeraldPositive
        score >= 45 -> AmberCaution
        else -> CrimsonRisk
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(
                "$score / 100",
                style = MaterialTheme.typography.labelSmall,
                color = barColor
            )
        }
        LinearProgressIndicator(
            progress = { (score / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(50)),
            color = barColor,
            trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        )
    }
}

@Composable
fun ProfitabilityBarChart(
    analysis: FinancialAnalysisRecord,
    preferLakhs: Boolean
) {
    val items = listOf(
        "Revenue" to analysis.revenue,
        "Gross" to analysis.grossProfit,
        "EBITDA" to analysis.ebitda,
        "EBIT" to analysis.ebit,
        "PAT" to analysis.netProfit
    )
    val maxVal = max(items.maxOfOrNull { kotlin.math.abs(it.second) } ?: 1.0, 1.0)
    val primaryCol = RoyalViolet
    val accentCol = SoftIris
    val posCol = EmeraldPositive
    val negCol = CrimsonRisk
    val gridCol = MaterialTheme.colorScheme.outline

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Ind AS Profitability Bridge (${analysis.reportingPeriod})",
            style = MaterialTheme.typography.titleMedium
        )
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
        ) {
            val count = items.size
            val slotW = size.width / count
            val barW = slotW * 0.46f
            val baseY = size.height - 12f
            val chartH = size.height - 28f

            // Baseline gridlines
            for (g in 0..3) {
                val y = baseY - (chartH * g / 3f)
                drawLine(
                    color = gridCol,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
            }

            items.forEachIndexed { idx, (_, value) ->
                val ratio = (kotlin.math.abs(value) / maxVal).toFloat().coerceIn(0.04f, 1f)
                val barH = chartH * ratio
                val x = idx * slotW + (slotW - barW) / 2f
                val y = baseY - barH
                val color = when {
                    value < 0 -> negCol
                    idx == 0 -> primaryCol
                    idx == 4 -> posCol
                    else -> accentCol
                }
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, y),
                    size = Size(barW, barH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            items.forEach { (label, value) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        IndAsFormatter.formatCompactNumber(value, analysis.currency),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun FpaCashFlowChart(
    points: List<FpaProjectionPoint>,
    currency: String,
    highlightedScenario: String
) {
    if (points.isEmpty()) return
    val allVals = points.flatMap {
        listOf(it.conservativeCash, it.expectedCash, it.optimisticCash)
    }
    val minV = min(allVals.minOrNull() ?: 0.0, 0.0)
    val maxV = max(allVals.maxOrNull() ?: 1.0, minV + 1.0)
    val span = (maxV - minV).coerceAtLeast(1.0)

    val consColor = AmberCaution
    val expColor = RoyalViolet
    val optColor = EmeraldPositive
    val actualColor = SlateInfo
    val gridColor = MaterialTheme.colorScheme.outline

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Actual vs Forecast Cash Trajectory", style = MaterialTheme.typography.titleMedium)
            StatusBadge(text = highlightedScenario, tone = BadgeTone.VIOLET)
        }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
        ) {
            val padX = 18f
            val padY = 18f
            val usableW = size.width - padX * 2
            val usableH = size.height - padY * 2

            for (i in 0..3) {
                val y = padY + (usableH * i / 3f)
                drawLine(gridColor, Offset(padX, y), Offset(size.width - padX, y), strokeWidth = 1f)
            }

            fun xAt(i: Int): Float = if (points.size <= 1) padX else padX + (usableW * i / (points.size - 1))
            fun yAt(v: Double): Float = padY + usableH - (((v - minV) / span).toFloat() * usableH)

            // Draw boundary separating Actual (index 0..2) from Forecast (3+)
            val firstForecastIdx = points.indexOfFirst { it.forecastFlag }
            if (firstForecastIdx > 0) {
                val boundaryX = (xAt(firstForecastIdx - 1) + xAt(firstForecastIdx)) / 2f
                drawLine(
                    color = SoftIris.copy(alpha = 0.5f),
                    start = Offset(boundaryX, padY),
                    end = Offset(boundaryX, size.height - padY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                )
            }

            fun drawSeries(values: List<Double>, color: Color, dashed: Boolean, strokeW: Float) {
                val path = Path()
                values.forEachIndexed { idx, v ->
                    val pt = Offset(xAt(idx), yAt(v))
                    if (idx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                }
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(
                        width = strokeW,
                        cap = StrokeCap.Round,
                        pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 8f)) else null
                    )
                )
                values.forEachIndexed { idx, v ->
                    drawCircle(color = color, radius = 4.5f, center = Offset(xAt(idx), yAt(v)))
                }
            }

            drawSeries(points.map { it.conservativeCash }, consColor, dashed = true, strokeW = 4f)
            drawSeries(points.map { it.optimisticCash }, optColor, dashed = true, strokeW = 4f)
            drawSeries(points.map { it.expectedCash }, expColor, dashed = false, strokeW = 6f)

            val actualPts = points.filter { !it.forecastFlag }
            if (actualPts.isNotEmpty()) {
                drawSeries(actualPts.map { it.actualCash }, actualColor, dashed = false, strokeW = 7f)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ChartLegendDot("Actual", actualColor)
            ChartLegendDot("Conservative", consColor)
            ChartLegendDot("Expected", expColor)
            ChartLegendDot("Optimistic", optColor)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Start: ${IndAsFormatter.formatCompactNumber(points.first().expectedCash, currency)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "End (Exp): ${IndAsFormatter.formatCompactNumber(points.last().expectedCash, currency)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun ChartLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EmptyVaultCard(
    title: String,
    description: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    FableCard {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_vault),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!actionLabel.isNullOrBlank() && onAction != null) {
                Button(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}
