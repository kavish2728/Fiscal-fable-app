package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ApprovalAuditLog
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ApprovalsScreen(
    activeClient: ClientEntity?,
    reports: List<CfoReportRecord>,
    auditLogs: List<ApprovalAuditLog>,
    onOpenReport: (CfoReportRecord) -> Unit,
    onRequestChanges: (CfoReportRecord, String) -> Unit,
    onApproveReport: (CfoReportRecord, String) -> Unit,
    onExportPdf: (Uri, CfoReportRecord) -> Unit,
    onExportExcel: (Uri, CfoReportRecord) -> Unit
) {
    var actionTarget by remember { mutableStateOf<Pair<CfoReportRecord, Boolean>?>(null) } // true = approve, false = request changes
    var reviewNotes by remember { mutableStateOf("") }
    var pendingExportReport by remember { mutableStateOf<CfoReportRecord?>(null) }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val rep = pendingExportReport
        if (uri != null && rep != null) onExportPdf(uri, rep)
        pendingExportReport = null
    }

    val excelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri ->
        val rep = pendingExportReport
        if (uri != null && rep != null) onExportExcel(uri, rep)
        pendingExportReport = null
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.US) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "CFO Approval Centre",
                subtitle = "Governance sign-off gate & immutable approval audit trail",
                badge = "${reports.count { it.reviewStatus != "APPROVED" }} Pending"
            )
        }

        if (activeClient == null) {
            item {
                EmptyVaultCard(
                    title = "Select a Client",
                    description = "Choose a client in the Clients tab to review and approve generated CFO reports."
                )
            }
        } else if (reports.isEmpty()) {
            item {
                EmptyVaultCard(
                    title = "Approval Queue Empty",
                    description = "Draft a report in CFO Reports first. No report may be exported externally until explicitly approved by the CFO."
                )
            }
        } else {
            items(reports, key = { it.id }) { rep ->
                val approved = rep.reviewStatus == "APPROVED"
                val genDate = if (rep.createdAtMillis > 0L) dateFormatter.format(Date(rep.createdAtMillis)) else "Today"

                FableCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rep.reportTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${rep.clientName} · ${rep.reportingPeriod} · Generated $genDate",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusBadge(
                            text = rep.reviewStatus.replace('_', ' '),
                            tone = when (rep.reviewStatus) {
                                "APPROVED" -> BadgeTone.POSITIVE
                                "CHANGES_REQUESTED" -> BadgeTone.RISK
                                "IN_REVIEW" -> BadgeTone.INFO
                                else -> BadgeTone.CAUTION
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusBadge("Review: ${rep.reviewStatus}", BadgeTone.NEUTRAL)
                        StatusBadge(
                            text = if (approved) "Approved: ${rep.approvedBy}" else "Approval: Pending",
                            tone = if (approved) BadgeTone.POSITIVE else BadgeTone.CAUTION
                        )
                    }

                    if (approved) {
                        Text(
                            "Signed off by ${rep.approvedBy} (${rep.approvedByEmail}) on ${rep.approvedAtLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(onClick = { onOpenReport(rep) }, modifier = Modifier.weight(1f)) {
                                Text("Open")
                            }
                            Button(
                                onClick = {
                                    pendingExportReport = rep
                                    pdfLauncher.launch("${rep.clientName.replace(' ', '_')}_${rep.reportingPeriod}.pdf")
                                },
                                modifier = Modifier.weight(1f).testTag("approval_export_pdf_${rep.id}")
                            ) {
                                Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("PDF")
                            }
                            OutlinedButton(
                                onClick = {
                                    pendingExportReport = rep
                                    excelLauncher.launch("${rep.clientName.replace(' ', '_')}_${rep.reportingPeriod}.xlsx")
                                },
                                modifier = Modifier.weight(1f).testTag("approval_export_excel_${rep.id}")
                            ) {
                                Icon(Icons.Filled.TableView, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Excel")
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(onClick = { onOpenReport(rep) }, modifier = Modifier.weight(1f)) {
                                Text("Open / Edit")
                            }
                            OutlinedButton(
                                onClick = {
                                    reviewNotes = rep.cfoReviewNotes
                                    actionTarget = rep to false
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Changes")
                            }
                            Button(
                                onClick = {
                                    reviewNotes = rep.cfoReviewNotes
                                    actionTarget = rep to true
                                },
                                modifier = Modifier.weight(1f).testTag("approve_report_btn_${rep.id}")
                            ) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Approve")
                            }
                        }
                    }
                }
            }
        }

        if (auditLogs.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Immutable Governance Audit Log", style = MaterialTheme.typography.titleMedium)
                }
            }
            items(auditLogs.sortedByDescending { it.createdAtMillis }, key = { it.id }) { log ->
                FableCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(log.reportTitle, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusBadge(log.action.replace('_', ' '), BadgeTone.INFO)
                    }
                    Text(
                        "${log.actorName} (${log.actorEmail})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (log.notes.isNotBlank()) {
                        Text(log.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    actionTarget?.let { (rep, isApprove) ->
        AlertDialog(
            onDismissRequest = { actionTarget = null },
            title = { Text(if (isApprove) "Approve Report for Delivery" else "Request Revisions") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (isApprove) "Approving locks '${rep.reportTitle}' against further edits, records your sign-off timestamp, and unlocks PDF/Excel delivery."
                        else "Specify required revisions for '${rep.reportTitle}'.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reviewNotes,
                        onValueChange = { reviewNotes = it },
                        label = { Text("CFO Sign-Off / Review Notes") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isApprove) onApproveReport(rep, reviewNotes)
                        else onRequestChanges(rep, reviewNotes)
                        actionTarget = null
                    },
                    modifier = Modifier.testTag("confirm_approval_dialog_btn")
                ) {
                    Text(if (isApprove) "Confirm Approval" else "Send Back for Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { actionTarget = null }) { Text("Cancel") }
            }
        )
    }
}
