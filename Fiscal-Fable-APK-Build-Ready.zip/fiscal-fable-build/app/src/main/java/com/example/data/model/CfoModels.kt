package com.example.data.model

enum class WorkspaceSection(val title: String, val shortTitle: String) {
    OVERVIEW("Overview", "Overview"),
    CLIENTS("Clients", "Clients"),
    DOCUMENTS("Document Intelligence", "Docs"),
    ANALYSIS("Financial Analysis", "Analysis"),
    FPA("Cash Flow & FP&A", "FP&A"),
    ADVISORY("Business Advisory", "Advisory"),
    REPORTS("CFO Reports", "Reports"),
    APPROVALS("Approvals", "Approvals"),
    SETTINGS("Settings", "Settings")
}

enum class ClientStatus { ACTIVE, ONBOARDING, ARCHIVED }

enum class DocumentType(val displayName: String) {
    PNL("Profit & Loss Statement (Ind AS 1)"),
    BALANCE_SHEET("Balance Sheet (Schedule III)"),
    CASH_FLOW("Cash Flow Statement (Ind AS 7)"),
    TRIAL_BALANCE("Trial Balance"),
    GENERAL_LEDGER("General Ledger"),
    AR_REPORT("Accounts Receivable Ageing"),
    AP_REPORT("Accounts Payable Ageing"),
    BANK_STATEMENT("Bank Statement"),
    BUDGET_FORECAST("Budget / Forecast Sheet"),
    OTHER("Other Financial Document")
}

enum class UnitScale(val label: String, val multiplier: Double) {
    RAW("Actuals (1x)", 1.0),
    THOUSANDS("Thousands (K)", 1_000.0),
    LAKHS("Lakhs (₹ L)", 100_000.0),
    CRORES("Crores (₹ Cr)", 10_000_000.0)
}

enum class ExtractionStatus { UPLOADED, PROCESSING, NEEDS_VALIDATION, VALIDATED, FAILED }

enum class StatementCategory(val displayName: String) {
    PNL("Profit & Loss (Ind AS 1)"),
    BALANCE_SHEET("Balance Sheet (Sch. III)"),
    CASH_FLOW("Cash Flow (Ind AS 7)"),
    WORKING_CAPITAL("Working Capital")
}

enum class FigureConfidence { HIGH, MEDIUM, LOW }

enum class AdvisoryCategory(val displayName: String) {
    PROFITABILITY("Profitability"),
    COST_CONTROL("Cost Control"),
    CASH_FLOW("Cash Flow"),
    WORKING_CAPITAL("Working Capital"),
    PRICING("Pricing Strategy"),
    RISK("Financial Risk"),
    GROWTH("Growth Strategy"),
    FUNDING("Funding & Capital")
}

enum class AdvisoryPriority { CRITICAL, HIGH, MEDIUM, LOW }

enum class ActionStatus { OPEN, IN_PROGRESS, IMPLEMENTED }

enum class ReviewStatus(val displayName: String) {
    DRAFT("Draft"),
    IN_REVIEW("In Review"),
    CHANGES_REQUESTED("Changes Requested"),
    APPROVED("Approved")
}

enum class FpaScenario(val label: String) {
    CONSERVATIVE("Conservative"),
    EXPECTED("Expected"),
    OPTIMISTIC("Optimistic")
}

val ALL_CFO_REPORT_TYPES = listOf(
    "Monthly Management Report",
    "Quarterly CFO Report",
    "Annual Financial Performance Report",
    "Profitability Analysis Report",
    "Cash Flow Analysis and Forecast",
    "Budget vs Actual Report",
    "FP&A Report",
    "Financial Health Assessment",
    "Working Capital Report",
    "Financial Risk Assessment",
    "Strategic Business Review",
    "Investor Financial Summary"
)

inline fun <reified T : Enum<T>> safeEnum(raw: String?, default: T): T {
    if (raw.isNullOrBlank()) return default
    return enumValues<T>().firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: default
}

data class CfoProfile(
    val partnerName: String = "Managing CFO Partner",
    val partnerTitle: String = "Virtual CFO · Ind AS Practice",
    val preferLakhsCrores: Boolean = true
)

data class ClientEntity(
    val id: String = "",
    val companyName: String = "",
    val industry: String = "",
    val country: String = "India",
    val currency: String = "INR",
    val financialYear: String = "FY 2025-26",
    val accountingPeriod: String = "Q2 (Jul-Sep 2025)",
    val accountingStandard: String = "Ind AS (Schedule III)",
    val businessProfile: String = "",
    val contactName: String = "",
    val contactEmail: String = "",
    val contactPhone: String = "",
    val status: String = ClientStatus.ACTIVE.name,
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class FinancialDocument(
    val id: String = "",
    val clientId: String = "",
    val fileName: String = "",
    val mimeType: String = "",
    val documentType: String = DocumentType.PNL.name,
    val reportingPeriod: String = "",
    val currency: String = "INR",
    val unitScale: String = UnitScale.RAW.name,
    val extractionStatus: String = ExtractionStatus.UPLOADED.name,
    val ocrUsed: Boolean = false,
    val pageCount: Long = 1L,
    val sourceSummary: String = "",
    val missingFieldsNote: String = "",
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class ExtractedFigure(
    val id: String = "",
    val clientId: String = "",
    val documentId: String = "",
    val documentName: String = "",
    val reportingPeriod: String = "",
    val statementCategory: String = StatementCategory.PNL.name,
    val fieldKey: String = "",
    val label: String = "",
    val indAsReference: String = "",
    val amount: Double = 0.0,
    val currency: String = "INR",
    val sourceCitation: String = "",
    val confidence: String = FigureConfidence.MEDIUM.name,
    val ambiguityNote: String = "",
    val validated: Boolean = false,
    val validatedBy: String = "",
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class FinancialAnalysisRecord(
    val id: String = "",
    val clientId: String = "",
    val reportingPeriod: String = "",
    val currency: String = "INR",
    val revenue: Double = 0.0,
    val cogs: Double = 0.0,
    val grossProfit: Double = 0.0,
    val operatingExpenses: Double = 0.0,
    val ebitda: Double = 0.0,
    val depreciation: Double = 0.0,
    val ebit: Double = 0.0,
    val interestExpense: Double = 0.0,
    val pbt: Double = 0.0,
    val taxExpense: Double = 0.0,
    val netProfit: Double = 0.0,
    val totalAssets: Double = 0.0,
    val currentAssets: Double = 0.0,
    val inventory: Double = 0.0,
    val tradeReceivables: Double = 0.0,
    val cashAndEquivalents: Double = 0.0,
    val totalEquity: Double = 0.0,
    val totalDebt: Double = 0.0,
    val currentLiabilities: Double = 0.0,
    val tradePayables: Double = 0.0,
    val operatingCashFlow: Double = 0.0,
    val investingCashFlow: Double = 0.0,
    val financingCashFlow: Double = 0.0,
    val grossMarginPct: Double = 0.0,
    val ebitdaMarginPct: Double = 0.0,
    val operatingMarginPct: Double = 0.0,
    val netMarginPct: Double = 0.0,
    val currentRatio: Double = 0.0,
    val quickRatio: Double = 0.0,
    val debtToEquity: Double = 0.0,
    val interestCoverage: Double = 0.0,
    val roaPct: Double = 0.0,
    val roePct: Double = 0.0,
    val receivableDays: Double = 0.0,
    val inventoryDays: Double = 0.0,
    val payableDays: Double = 0.0,
    val cashConversionCycle: Double = 0.0,
    val workingCapital: Double = 0.0,
    val profitabilityScore: Long = 0L,
    val liquidityScore: Long = 0L,
    val solvencyScore: Long = 0L,
    val efficiencyScore: Long = 0L,
    val stabilityScore: Long = 0L,
    val executiveSummary: String = "",
    val trendCommentary: String = "",
    val unusualMovements: List<String> = emptyList(),
    val indAsNotes: List<String> = emptyList(),
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class FpaProjectionPoint(
    val monthLabel: String = "",
    val actualCash: Double = 0.0,
    val conservativeCash: Double = 0.0,
    val expectedCash: Double = 0.0,
    val optimisticCash: Double = 0.0,
    val expectedRevenue: Double = 0.0,
    val expectedExpense: Double = 0.0,
    val budgetRevenue: Double = 0.0,
    val budgetExpense: Double = 0.0,
    val forecastFlag: Boolean = true
) {
    fun toMap(): Map<String, Any> = mapOf(
        "monthLabel" to monthLabel,
        "actualCash" to actualCash,
        "conservativeCash" to conservativeCash,
        "expectedCash" to expectedCash,
        "optimisticCash" to optimisticCash,
        "expectedRevenue" to expectedRevenue,
        "expectedExpense" to expectedExpense,
        "budgetRevenue" to budgetRevenue,
        "budgetExpense" to budgetExpense,
        "forecastFlag" to forecastFlag
    )
}

data class FpaForecastRecord(
    val id: String = "",
    val clientId: String = "",
    val reportingPeriod: String = "",
    val horizonMonths: Long = 6L,
    val revenueGrowthExpectedPct: Double = 8.0,
    val cogsPctOfRevenue: Double = 58.0,
    val opexGrowthPct: Double = 4.0,
    val targetDsoDays: Double = 45.0,
    val monthlyFixedCosts: Double = 0.0,
    val breakEvenMonthlyRevenue: Double = 0.0,
    val assumptionsSummary: String = "",
    val conservativeSummary: String = "",
    val expectedSummary: String = "",
    val optimisticSummary: String = "",
    val projections: List<FpaProjectionPoint> = emptyList(),
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
) {
    fun parsedProjections(): List<FpaProjectionPoint> = projections
}

data class BusinessAdvisoryItem(
    val id: String = "",
    val clientId: String = "",
    val reportingPeriod: String = "",
    val category: String = AdvisoryCategory.PROFITABILITY.name,
    val identifiedProblem: String = "",
    val supportingEvidence: String = "",
    val businessImpact: String = "",
    val recommendedAction: String = "",
    val priority: String = AdvisoryPriority.HIGH.name,
    val expectedOutcome: String = "",
    val relevantAssumptions: String = "",
    val actionStatus: String = ActionStatus.OPEN.name,
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class CfoReportRecord(
    val id: String = "",
    val clientId: String = "",
    val clientName: String = "",
    val reportType: String = "Quarterly CFO Report",
    val reportTitle: String = "",
    val reportingPeriod: String = "",
    val currency: String = "INR",
    val executiveSummary: String = "",
    val financialObservations: String = "",
    val riskIdentification: String = "",
    val recommendationsText: String = "",
    val managementActionPoints: String = "",
    val conclusion: String = "",
    val reviewStatus: String = ReviewStatus.DRAFT.name,
    val cfoReviewNotes: String = "",
    val approvedBy: String = "",
    val approvedByEmail: String = "",
    val approvedAtLabel: String = "",
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class ApprovalAuditLog(
    val id: String = "",
    val clientId: String = "",
    val reportId: String = "",
    val reportTitle: String = "",
    val action: String = "GENERATED",
    val actorName: String = "",
    val actorEmail: String = "",
    val notes: String = "",
    val createdAtMillis: Long = 0L
)
