package com.example.domain

import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FpaProjectionPoint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Deterministic financial engine aligned with Indian Accounting Standards (Ind AS & Schedule III).
 * Never fabricates numbers: consumes only human-validated ExtractedFigure entries.
 */
object FinancialCalculator {

    data class DeterministicMetrics(
        val revenue: Double,
        val cogs: Double,
        val grossProfit: Double,
        val operatingExpenses: Double,
        val ebitda: Double,
        val depreciation: Double,
        val ebit: Double,
        val interestExpense: Double,
        val pbt: Double,
        val taxExpense: Double,
        val netProfit: Double,
        val totalAssets: Double,
        val currentAssets: Double,
        val inventory: Double,
        val tradeReceivables: Double,
        val cashAndEquivalents: Double,
        val totalEquity: Double,
        val totalDebt: Double,
        val currentLiabilities: Double,
        val tradePayables: Double,
        val operatingCashFlow: Double,
        val investingCashFlow: Double,
        val financingCashFlow: Double,
        val grossMarginPct: Double,
        val ebitdaMarginPct: Double,
        val operatingMarginPct: Double,
        val netMarginPct: Double,
        val currentRatio: Double,
        val quickRatio: Double,
        val debtToEquity: Double,
        val interestCoverage: Double,
        val roaPct: Double,
        val roePct: Double,
        val receivableDays: Double,
        val inventoryDays: Double,
        val payableDays: Double,
        val cashConversionCycle: Double,
        val workingCapital: Double,
        val profitabilityScore: Int,
        val liquidityScore: Int,
        val solvencyScore: Int,
        val efficiencyScore: Int,
        val stabilityScore: Int,
        val periodDays: Double = 365.0
    )

    fun computeFromValidatedFigures(
        figures: List<ExtractedFigure>,
        periodDays: Double = 90.0
    ): DeterministicMetrics {
        val validated = figures.filter { it.validated }

        fun sumKeys(vararg keys: String): Double {
            val keySet = keys.map { it.lowercase() }.toSet()
            return validated
                .filter { it.fieldKey.lowercase() in keySet }
                .sumOf { it.amount }
        }

        val revenue = sumKeys("revenue", "revenue_from_operations", "sales", "turnover")
        val cogs = sumKeys("cogs", "cost_of_goods_sold", "cost_of_materials_consumed")
        val rawGrossProfit = sumKeys("gross_profit")
        val grossProfit = if (rawGrossProfit != 0.0) rawGrossProfit else (revenue - cogs)

        val operatingExpenses = sumKeys(
            "operating_expenses", "opex", "employee_benefits", "other_expenses"
        )
        val depreciation = sumKeys("depreciation", "depreciation_and_amortisation")
        val rawEbitda = sumKeys("ebitda")
        val ebitda = if (rawEbitda != 0.0) rawEbitda else (grossProfit - operatingExpenses)

        val rawEbit = sumKeys("ebit", "operating_profit")
        val ebit = if (rawEbit != 0.0) rawEbit else (ebitda - depreciation)

        val interestExpense = sumKeys("interest_expense", "finance_costs")
        val rawPbt = sumKeys("pbt", "profit_before_tax")
        val pbt = if (rawPbt != 0.0) rawPbt else (ebit - interestExpense)

        val taxExpense = sumKeys("tax_expense", "income_tax")
        val rawNetProfit = sumKeys("net_profit", "pat", "profit_after_tax")
        val netProfit = if (rawNetProfit != 0.0) rawNetProfit else (pbt - taxExpense)

        val inventory = sumKeys("inventory", "inventories")
        val tradeReceivables = sumKeys("trade_receivables", "accounts_receivable")
        val cashAndEquivalents = sumKeys("cash_and_equivalents", "cash", "bank_balance")
        val rawCurrentAssets = sumKeys("current_assets", "total_current_assets")
        val currentAssets = if (rawCurrentAssets != 0.0) rawCurrentAssets else (inventory + tradeReceivables + cashAndEquivalents)

        val nonCurrentAssets = sumKeys("non_current_assets", "fixed_assets", "ppe")
        val rawTotalAssets = sumKeys("total_assets")
        val totalAssets = if (rawTotalAssets != 0.0) rawTotalAssets else (currentAssets + nonCurrentAssets)

        val totalEquity = sumKeys("total_equity", "shareholders_equity", "net_worth")
        val totalDebt = sumKeys("total_debt", "borrowings", "short_term_debt", "long_term_debt")
        val tradePayables = sumKeys("trade_payables", "accounts_payable")
        val rawCurrentLiabilities = sumKeys("current_liabilities", "total_current_liabilities")
        val currentLiabilities = if (rawCurrentLiabilities != 0.0) rawCurrentLiabilities else tradePayables

        val operatingCashFlow = sumKeys("operating_cash_flow", "ocf", "cash_from_operations")
        val investingCashFlow = sumKeys("investing_cash_flow", "icf", "cash_from_investing")
        val financingCashFlow = sumKeys("financing_cash_flow", "fcf", "cash_from_financing")

        val grossMarginPct = safePct(grossProfit, revenue)
        val ebitdaMarginPct = safePct(ebitda, revenue)
        val operatingMarginPct = safePct(ebit, revenue)
        val netMarginPct = safePct(netProfit, revenue)

        val currentRatio = safeDiv(currentAssets, currentLiabilities)
        val quickRatio = safeDiv(currentAssets - inventory, currentLiabilities)
        val debtToEquity = safeDiv(totalDebt, totalEquity)
        val interestCoverage = safeDiv(ebit, interestExpense)

        val annualizationFactor = if (periodDays in 1.0..364.0) 365.0 / periodDays else 1.0
        val annualizedNetProfit = netProfit * annualizationFactor
        val roaPct = safePct(annualizedNetProfit, totalAssets)
        val roePct = safePct(annualizedNetProfit, totalEquity)

        val receivableDays = if (revenue > 0.0) (tradeReceivables / revenue) * periodDays else 0.0
        val inventoryDays = if (cogs > 0.0) (inventory / cogs) * periodDays else 0.0
        val payableDays = if (cogs > 0.0) (tradePayables / cogs) * periodDays else 0.0
        val cashConversionCycle = receivableDays + inventoryDays - payableDays
        val workingCapital = currentAssets - currentLiabilities

        val profScore = scoreRange(ebitdaMarginPct, low = 4.0, high = 22.0)
        val liqScore = scoreRange(currentRatio, low = 0.8, high = 2.0)
        val solScore = if (totalEquity <= 0.0 && totalDebt > 0.0) 20 else scoreInverse(debtToEquity, best = 0.3, worst = 2.5)
        val effScore = scoreInverse(cashConversionCycle, best = 20.0, worst = 120.0)
        val stabScore = ((profScore + liqScore + solScore + effScore) / 4.0).roundToInt().coerceIn(0, 100)

        return DeterministicMetrics(
            revenue = revenue,
            cogs = cogs,
            grossProfit = grossProfit,
            operatingExpenses = operatingExpenses,
            ebitda = ebitda,
            depreciation = depreciation,
            ebit = ebit,
            interestExpense = interestExpense,
            pbt = pbt,
            taxExpense = taxExpense,
            netProfit = netProfit,
            totalAssets = totalAssets,
            currentAssets = currentAssets,
            inventory = inventory,
            tradeReceivables = tradeReceivables,
            cashAndEquivalents = cashAndEquivalents,
            totalEquity = totalEquity,
            totalDebt = totalDebt,
            currentLiabilities = currentLiabilities,
            tradePayables = tradePayables,
            operatingCashFlow = operatingCashFlow,
            investingCashFlow = investingCashFlow,
            financingCashFlow = financingCashFlow,
            grossMarginPct = grossMarginPct,
            ebitdaMarginPct = ebitdaMarginPct,
            operatingMarginPct = operatingMarginPct,
            netMarginPct = netMarginPct,
            currentRatio = currentRatio,
            quickRatio = quickRatio,
            debtToEquity = debtToEquity,
            interestCoverage = interestCoverage,
            roaPct = roaPct,
            roePct = roePct,
            receivableDays = receivableDays,
            inventoryDays = inventoryDays,
            payableDays = payableDays,
            cashConversionCycle = cashConversionCycle,
            workingCapital = workingCapital,
            profitabilityScore = profScore,
            liquidityScore = liqScore,
            solvencyScore = solScore,
            efficiencyScore = effScore,
            stabilityScore = stabScore,
            periodDays = periodDays
        )
    }

    fun calculateBreakEvenMonthlyRevenue(
        monthlyFixedCosts: Double,
        cogsPctOfRevenue: Double
    ): Double {
        val contributionMarginRatio = (100.0 - cogsPctOfRevenue).coerceIn(1.0, 99.0) / 100.0
        return monthlyFixedCosts / contributionMarginRatio
    }

    fun buildDeterministicProjections(
        latestAnalysis: FinancialAnalysisRecord?,
        horizonMonths: Int,
        expectedGrowthAnnualPct: Double,
        cogsPctOfRevenue: Double,
        opexGrowthAnnualPct: Double
    ): List<FpaProjectionPoint> {
        val baseMonthlyRev = ((latestAnalysis?.revenue ?: 0.0) / 3.0).coerceAtLeast(0.0)
        val baseMonthlyOpex = ((latestAnalysis?.operatingExpenses ?: 0.0) / 3.0).coerceAtLeast(0.0)
        val startingCash = (latestAnalysis?.cashAndEquivalents ?: 0.0).coerceAtLeast(0.0)
        val baseActualOcfMonthly = ((latestAnalysis?.operatingCashFlow ?: (latestAnalysis?.ebitda ?: 0.0)) / 3.0)

        val monthLabels = listOf("M-2 (Act)", "M-1 (Act)", "M0 (Act)") + (1..horizonMonths).map { "M+$it (Fcst)" }

        val points = mutableListOf<FpaProjectionPoint>()
        // Historical actual baseline points (3 prior months)
        val priorCash2 = (startingCash - baseActualOcfMonthly * 2.0).coerceAtLeast(0.0)
        val priorCash1 = (startingCash - baseActualOcfMonthly).coerceAtLeast(0.0)
        val actualCashList = listOf(priorCash2, priorCash1, startingCash)

        for (i in 0..2) {
            points += FpaProjectionPoint(
                monthLabel = monthLabels[i],
                actualCash = actualCashList[i],
                conservativeCash = actualCashList[i],
                expectedCash = actualCashList[i],
                optimisticCash = actualCashList[i],
                expectedRevenue = baseMonthlyRev,
                expectedExpense = (baseMonthlyRev * (cogsPctOfRevenue / 100.0)) + baseMonthlyOpex,
                budgetRevenue = baseMonthlyRev * 1.02,
                budgetExpense = ((baseMonthlyRev * (cogsPctOfRevenue / 100.0)) + baseMonthlyOpex) * 0.98,
                forecastFlag = false
            )
        }

        var consCash = startingCash
        var expCash = startingCash
        var optCash = startingCash

        val expMonthlyGrowth = expectedGrowthAnnualPct / 100.0 / 12.0
        val consMonthlyGrowth = (expectedGrowthAnnualPct - 5.0) / 100.0 / 12.0
        val optMonthlyGrowth = (expectedGrowthAnnualPct + 6.0) / 100.0 / 12.0
        val opexMonthlyGrowth = opexGrowthAnnualPct / 100.0 / 12.0

        for (m in 1..horizonMonths) {
            val factorCons = Math.pow(1.0 + consMonthlyGrowth, m.toDouble())
            val factorExp = Math.pow(1.0 + expMonthlyGrowth, m.toDouble())
            val factorOpt = Math.pow(1.0 + optMonthlyGrowth, m.toDouble())
            val opexFactor = Math.pow(1.0 + opexMonthlyGrowth, m.toDouble())

            val revCons = baseMonthlyRev * factorCons
            val revExp = baseMonthlyRev * factorExp
            val revOpt = baseMonthlyRev * factorOpt

            val cogsRatioCons = ((cogsPctOfRevenue + 2.5).coerceAtMost(95.0)) / 100.0
            val cogsRatioExp = (cogsPctOfRevenue.coerceIn(5.0, 95.0)) / 100.0
            val cogsRatioOpt = ((cogsPctOfRevenue - 2.0).coerceAtLeast(5.0)) / 100.0

            val opexMonth = baseMonthlyOpex * opexFactor

            val netCons = revCons * (1.0 - cogsRatioCons) - opexMonth * 1.02
            val netExp = revExp * (1.0 - cogsRatioExp) - opexMonth
            val netOpt = revOpt * (1.0 - cogsRatioOpt) - opexMonth * 0.98

            consCash += netCons * 0.85
            expCash += netExp * 0.88
            optCash += netOpt * 0.90

            points += FpaProjectionPoint(
                monthLabel = "M+$m",
                actualCash = 0.0,
                conservativeCash = consCash,
                expectedCash = expCash,
                optimisticCash = optCash,
                expectedRevenue = revExp,
                expectedExpense = (revExp * cogsRatioExp) + opexMonth,
                budgetRevenue = baseMonthlyRev * (1.0 + (expMonthlyGrowth * m * 1.03)),
                budgetExpense = ((baseMonthlyRev * cogsRatioExp) + opexMonth) * 0.99,
                forecastFlag = true
            )
        }
        return points
    }

    private fun safeDiv(num: Double, den: Double): Double =
        if (den == 0.0) 0.0 else num / den

    private fun safePct(part: Double, whole: Double): Double =
        if (whole == 0.0) 0.0 else (part / whole) * 100.0

    private fun scoreRange(value: Double, low: Double, high: Double): Int {
        if (high <= low) return 50
        val norm = ((value - low) / (high - low)).coerceIn(0.0, 1.0)
        return (20 + norm * 80).roundToInt().coerceIn(0, 100)
    }

    private fun scoreInverse(value: Double, best: Double, worst: Double): Int {
        if (worst <= best) return 50
        val norm = ((worst - value) / (worst - best)).coerceIn(0.0, 1.0)
        return (20 + norm * 80).roundToInt().coerceIn(0, 100)
    }
}
