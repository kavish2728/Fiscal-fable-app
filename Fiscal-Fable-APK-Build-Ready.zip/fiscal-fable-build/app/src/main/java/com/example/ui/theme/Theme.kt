package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val FiscalFableLightColorScheme = lightColorScheme(
    primary = RoyalViolet,
    onPrimary = PureWhite,
    primaryContainer = LavenderTint,
    onPrimaryContainer = DeepIndigo,
    secondary = VividAmethyst,
    onSecondary = PureWhite,
    secondaryContainer = LavenderSurface,
    onSecondaryContainer = InkPrimary,
    tertiary = SoftIris,
    onTertiary = PureWhite,
    tertiaryContainer = SlateContainer,
    onTertiaryContainer = SlateInfo,
    background = LavenderMist,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = LavenderSurface,
    onSurfaceVariant = InkSecondary,
    outline = LavenderBorder,
    outlineVariant = LavenderTint,
    error = CrimsonRisk,
    onError = PureWhite,
    errorContainer = CrimsonContainer,
    onErrorContainer = CrimsonRisk
)

private val FiscalFableDarkColorScheme = darkColorScheme(
    primary = OrchidLight,
    onPrimary = DeepIndigo,
    primaryContainer = RoyalViolet,
    onPrimaryContainer = InkOnDark,
    secondary = SoftIris,
    onSecondary = PureWhite,
    secondaryContainer = PlumSurfaceElevated,
    onSecondaryContainer = InkOnDark,
    tertiary = OrchidLight,
    onTertiary = MidnightPlum,
    background = MidnightPlum,
    onBackground = InkOnDark,
    surface = PlumSurface,
    onSurface = InkOnDark,
    surfaceVariant = PlumSurfaceElevated,
    onSurfaceVariant = OrchidLight,
    outline = PlumBorder,
    outlineVariant = PlumSurfaceElevated,
    error = CrimsonRisk,
    onError = PureWhite,
    errorContainer = PlumSurfaceElevated,
    onErrorContainer = CrimsonContainer
)

val FiscalFableShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun FiscalFableTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val useDark = darkTheme || isSystemInDarkTheme()
    val colorScheme = if (useDark) FiscalFableDarkColorScheme else FiscalFableLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FiscalFableTypography,
        shapes = FiscalFableShapes,
        content = content
    )
}
