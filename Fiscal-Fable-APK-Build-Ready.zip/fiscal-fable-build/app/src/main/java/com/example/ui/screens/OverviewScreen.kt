package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.IndAsFormatter
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FinancialDocument
import com.example.data.model.FpaForecastRecord
import com.example.data.model.WorkspaceSection
import com.example.ui.components.BadgeTone
import com.example.ui.components.EmptyVaultCard
import com.example.ui.components.FableCard
import com.example.ui.components.HealthScoreRow
import com.example.ui.components.KpiTile
import com.example.ui.components.ProfitabilityBarChart
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DeepIndigo
import com.example.ui.theme.EmeraldPositive
import com.example.ui.theme.RoyalViolet

@Composable
fun OverviewScreen(
    clients: List<ClientEntity>,
    activeClient: ClientEntity?,
    documents: List<FinancialDocument>,
    figures: List<ExtractedFigure>,
    analyses: List<FinancialAnalysisRecord>,
    forecasts: List<FpaForecastRecord>,
    advisories: List<BusinessAdvisoryItem>,
    reports: List<CfoReportRecord>,
    preferLakhs: Boolean,
    onNavigate: (WorkspaceSection) -> Unit
) {
    val latestAnalysis = analyses.maxByOrNull { it.createdAtMillis }
    val unvalidatedCount = figures.count { !it.validated }
    val validatedCount = figures.count { it.validated }
    val pendingReports = reports.count { it.reviewStatus != "APPROVED" }
    val approvedReports = reports.count { it.reviewStatus == "APPROVED" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Editorial Hero Header
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                tonalElevation = 2.dp
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(152.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_cfo_hero_banner),
                        contentDescription = "Fiscal Fable Overview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(DeepIndigo.copy(alpha = 0.90f), RoyalViolet.copy(alpha = 0.72f))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier.fillMaxSize().padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FISCAL FABLE CFO COMMAND",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                            )
                            StatusBadge(
                                text = "${clients.size} Client${if (clients.size == 1) "" else "s"}",
                                tone = BadgeTone.VIOLET
                            )
                        }
                        Column {
                            Text(
                                text = activeClient?.companyName ?: "Select or Create a Client",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (activeClient != null) {
                                    "${activeClient.industry} · ${activeClient.financialYear} · ${activeClient.accountingStandard}"
                                } else {
                                    "Financial Intelligence · Strategic Clarity · Smarter Decisions"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }
        }

        if (activeClient == null) {
            item {
                EmptyVaultCard(
                    title = "Welcome to Fiscal Fable AI CFO",
                    description = "Start Step 1 by adding a corporate client in the Clients Directory. Each client's documents, Ind AS ratios, FP&A scenarios, and reports are strictly isolated.",
                    actionLabel = "Add First Client",
                    onAction = { onNavigate(WorkspaceSection.CLIENTS) }
                )
            }
        } else {
            // Unvalidated Figures Human Gate Warning
            if (unvalidatedCount > 0) {
                item {
                    FableCard(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Human Validation Required ($unvalidatedCount figures)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    text = "AI extracted figures from uploaded statements must be verified before financial analysis.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = { onNavigate(WorkspaceSection.DOCUMENTS) },
                                modifier = Modifier.testTag("overview_validate_button")
                            ) {
                                Text("Validate")
                            }
                        }
                    }
                }
            }

            // KPI Summary Grid
            item {
                val ccy = activeClient.currency
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        KpiTile(
                            label = "Validated Revenue",
                            value = latestAnalysis?.let { IndAsFormatter.formatMoney(it.revenue, ccy, preferLakhs) } ?: "—",
                            caption = latestAnalysis?.reportingPeriod ?: "Awaiting Analysis",
                            tone = if (latestAnalysis != null) BadgeTone.VIOLET else BadgeTone.NEUTRAL,
                            modifier = Modifier.weight(1f)
                        )
                        KpiTile(
                            label = "EBITDA Margin",
                            value = latestAnalysis?.let { IndAsFormatter.formatPct(it.ebitdaMarginPct) } ?: "—",
                            caption = latestAnalysis?.let { IndAsFormatter.formatMoney(it.ebitda, ccy, preferLakhs) } ?: "Ind AS 1",
                            tone = if ((latestAnalysis?.ebitdaMarginPct ?: 0.0) >= 12.0) BadgeTone.POSITIVE else BadgeTone.CAUTION,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        KpiTile(
                            label = "Cash Conversion",
                            value = latestAnalysis?.let { IndAsFormatter.formatDays(it.cashConversionCycle) } ?: "—",
                            caption = "CR: ${latestAnalysis?.let { IndAsFormatter.formatRatio(it.currentRatio) } ?: "—"}",
                            tone = if ((latestAnalysis?.currentRatio ?: 0.0) >= 1.2) BadgeTone.POSITIVE else BadgeTone.CAUTION,
                            modifier = Modifier.weight(1f)
                        )
                        KpiTile(
                            label = "CFO Approvals",
                            value = "$approvedReports / ${reports.size}",
                            caption = if (pendingReports > 0) "$pendingReports Pending Review" else "All Clear",
                            tone = if (pendingReports > 0) BadgeTone.CAUTION else BadgeTone.POSITIVE,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 10-Step Agentic Workflow Tracker
            item {
                FableCard {
                    Text(
                        text = "10-Step Virtual CFO Pipeline",
                        style = MaterialTheme.typography.titleMedium
                    )
                    val steps = listOf(
                        Triple("1–2. Client & Document Upload", "${documents.size} document(s) in vault", documents.isNotEmpty()) to WorkspaceSection.DOCUMENTS,
                        Triple("3–4. AI Extraction & Human Validation", "$validatedCount validated · $unvalidatedCount pending", validatedCount > 0 && unvalidatedCount == 0) to WorkspaceSection.DOCUMENTS,
                        Triple("5. Ind AS Financial Analysis", "${analyses.size} period snapshot(s)", analyses.isNotEmpty()) to WorkspaceSection.ANALYSIS,
                        Triple("6. Cash Flow & 3-Scenario FP&A", "${forecasts.size} forecast model(s)", forecasts.isNotEmpty()) to WorkspaceSection.FPA,
                        Triple("7. Business Advisory Agent", "${advisories.size} structured recommendation(s)", advisories.isNotEmpty()) to WorkspaceSection.ADVISORY,
                        Triple("8–10. CFO Report & Final Approval", "$approvedReports approved · $pendingReports in review", approvedReports > 0) to WorkspaceSection.APPROVALS
                    )
                    steps.forEach { (meta, targetSection) ->
                        val (title, detail, done) = meta
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onNavigate(targetSection) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (done) Icons.Filled.CheckCircle else Icons.Filled.PendingActions,
                                contentDescription = null,
                                tint = if (done) EmeraldPositive else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.titleSmall)
                                Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusBadge(
                                text = if (done) "Ready" else "Open",
                                tone = if (done) BadgeTone.POSITIVE else BadgeTone.INFO
                            )
                        }
                    }
                }
            }

            if (latestAnalysis != null) {
                item {
                    FableCard {
                        ProfitabilityBarChart(analysis = latestAnalysis, preferLakhs = preferLakhs)
                    }
                }
                item {
                    FableCard {
                        Text("5-Pillar Financial Health", style = MaterialTheme.typography.titleMedium)
                        HealthScoreRow("Profitability", latestAnalysis.profitabilityScore.toInt())
                        HealthScoreRow("Liquidity", latestAnalysis.liquidityScore.toInt())
                        HealthScoreRow("Solvency", latestAnalysis.solvencyScore.toInt())
                        HealthScoreRow("Efficiency", latestAnalysis.efficiencyScore.toInt())
                        HealthScoreRow("Overall Stability", latestAnalysis.stabilityScore.toInt())
                    }
                }
            }

            // Quick Actions
            item {
                FableCard {
                    Text("Quick Workspace Actions", style = MaterialTheme.typography.titleMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onNavigate(WorkspaceSection.DOCUMENTS) },
                            modifier = Modifier.weight(1f).testTag("quick_upload_btn")
                        ) {
                            Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Upload Doc")
                        }
                        OutlinedButton(
                            onClick = { onNavigate(WorkspaceSection.REPORTS) },
                            modifier = Modifier.weight(1f).testTag("quick_reports_btn")
                        ) {
                            Icon(Icons.Filled.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("CFO Report")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onNavigate(WorkspaceSection.FPA) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Timeline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("FP&A Model")
                        }
                        OutlinedButton(
                            onClick = { onNavigate(WorkspaceSection.ADVISORY) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Lightbulb, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Advisory")
                        }
                    }
                }
            }
        }
    }
}
