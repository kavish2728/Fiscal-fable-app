package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.ApprovalAuditLog
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoProfile
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FinancialDocument
import com.example.data.model.FpaForecastRecord
import com.example.data.model.FpaProjectionPoint
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "cfo_profile")
data class CfoProfileRoomEntity(
    @PrimaryKey val id: Int = 1,
    val partnerName: String = "Managing CFO Partner",
    val partnerTitle: String = "Virtual CFO · Ind AS Practice",
    val preferLakhsCrores: Boolean = true
) {
    fun toDomain() = CfoProfile(
        partnerName = partnerName,
        partnerTitle = partnerTitle,
        preferLakhsCrores = preferLakhsCrores
    )
}

@Entity(tableName = "clients")
data class ClientRoomEntity(
    @PrimaryKey val id: String,
    val companyName: String,
    val industry: String,
    val country: String,
    val currency: String,
    val financialYear: String,
    val accountingPeriod: String,
    val accountingStandard: String,
    val businessProfile: String,
    val contactName: String,
    val contactEmail: String,
    val contactPhone: String,
    val status: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = ClientEntity(
        id = id,
        companyName = companyName,
        industry = industry,
        country = country,
        currency = currency,
        financialYear = financialYear,
        accountingPeriod = accountingPeriod,
        accountingStandard = accountingStandard,
        businessProfile = businessProfile,
        contactName = contactName,
        contactEmail = contactEmail,
        contactPhone = contactPhone,
        status = status,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "documents",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class FinancialDocumentRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val fileName: String,
    val mimeType: String,
    val documentType: String,
    val reportingPeriod: String,
    val currency: String,
    val unitScale: String,
    val extractionStatus: String,
    val ocrUsed: Boolean,
    val pageCount: Long,
    val sourceSummary: String,
    val missingFieldsNote: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = FinancialDocument(
        id = id,
        clientId = clientId,
        fileName = fileName,
        mimeType = mimeType,
        documentType = documentType,
        reportingPeriod = reportingPeriod,
        currency = currency,
        unitScale = unitScale,
        extractionStatus = extractionStatus,
        ocrUsed = ocrUsed,
        pageCount = pageCount,
        sourceSummary = sourceSummary,
        missingFieldsNote = missingFieldsNote,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "extracted_figures",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId"), Index("documentId")]
)
data class ExtractedFigureRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val documentId: String,
    val documentName: String,
    val reportingPeriod: String,
    val statementCategory: String,
    val fieldKey: String,
    val label: String,
    val indAsReference: String,
    val amount: Double,
    val currency: String,
    val sourceCitation: String,
    val confidence: String,
    val ambiguityNote: String,
    val validated: Boolean,
    val validatedBy: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = ExtractedFigure(
        id = id,
        clientId = clientId,
        documentId = documentId,
        documentName = documentName,
        reportingPeriod = reportingPeriod,
        statementCategory = statementCategory,
        fieldKey = fieldKey,
        label = label,
        indAsReference = indAsReference,
        amount = amount,
        currency = currency,
        sourceCitation = sourceCitation,
        confidence = confidence,
        ambiguityNote = ambiguityNote,
        validated = validated,
        validatedBy = validatedBy,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "analyses",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class FinancialAnalysisRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val reportingPeriod: String,
    val currency: String,
    val revenue: Double,
    val cogs: Double,
    val grossProfit: Double,
    val operatingExpenses: Double,
    val ebitda: Double,
    val depreciation: Double,
    val ebit: Double,
    val interestExpense: Double,
    val pbt: Double,
    val taxExpense: Double,
    val netProfit: Double,
    val totalAssets: Double,
    val currentAssets: Double,
    val inventory: Double,
    val tradeReceivables: Double,
    val cashAndEquivalents: Double,
    val totalEquity: Double,
    val totalDebt: Double,
    val currentLiabilities: Double,
    val tradePayables: Double,
    val operatingCashFlow: Double,
    val investingCashFlow: Double,
    val financingCashFlow: Double,
    val grossMarginPct: Double,
    val ebitdaMarginPct: Double,
    val operatingMarginPct: Double,
    val netMarginPct: Double,
    val currentRatio: Double,
    val quickRatio: Double,
    val debtToEquity: Double,
    val interestCoverage: Double,
    val roaPct: Double,
    val roePct: Double,
    val receivableDays: Double,
    val inventoryDays: Double,
    val payableDays: Double,
    val cashConversionCycle: Double,
    val workingCapital: Double,
    val profitabilityScore: Long,
    val liquidityScore: Long,
    val solvencyScore: Long,
    val efficiencyScore: Long,
    val stabilityScore: Long,
    val executiveSummary: String,
    val trendCommentary: String,
    val unusualMovementsJson: String,
    val indAsNotesJson: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = FinancialAnalysisRecord(
        id = id,
        clientId = clientId,
        reportingPeriod = reportingPeriod,
        currency = currency,
        revenue = revenue,
        cogs = cogs,
        grossProfit = grossProfit,
        operatingExpenses = operatingExpenses,
        ebitda = ebitda,
        depreciation = depreciation,
        ebit = ebit,
        interestExpense = interestExpense,
        pbt = pbt,
        taxExpense = taxExpense,
        netProfit = netProfit,
        totalAssets = totalAssets,
        currentAssets = currentAssets,
        inventory = inventory,
        tradeReceivables = tradeReceivables,
        cashAndEquivalents = cashAndEquivalents,
        totalEquity = totalEquity,
        totalDebt = totalDebt,
        currentLiabilities = currentLiabilities,
        tradePayables = tradePayables,
        operatingCashFlow = operatingCashFlow,
        investingCashFlow = investingCashFlow,
        financingCashFlow = financingCashFlow,
        grossMarginPct = grossMarginPct,
        ebitdaMarginPct = ebitdaMarginPct,
        operatingMarginPct = operatingMarginPct,
        netMarginPct = netMarginPct,
        currentRatio = currentRatio,
        quickRatio = quickRatio,
        debtToEquity = debtToEquity,
        interestCoverage = interestCoverage,
        roaPct = roaPct,
        roePct = roePct,
        receivableDays = receivableDays,
        inventoryDays = inventoryDays,
        payableDays = payableDays,
        cashConversionCycle = cashConversionCycle,
        workingCapital = workingCapital,
        profitabilityScore = profitabilityScore,
        liquidityScore = liquidityScore,
        solvencyScore = solvencyScore,
        efficiencyScore = efficiencyScore,
        stabilityScore = stabilityScore,
        executiveSummary = executiveSummary,
        trendCommentary = trendCommentary,
        unusualMovements = decodeStringList(unusualMovementsJson),
        indAsNotes = decodeStringList(indAsNotesJson),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "forecasts",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class FpaForecastRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val reportingPeriod: String,
    val horizonMonths: Long,
    val revenueGrowthExpectedPct: Double,
    val cogsPctOfRevenue: Double,
    val opexGrowthPct: Double,
    val targetDsoDays: Double,
    val monthlyFixedCosts: Double,
    val breakEvenMonthlyRevenue: Double,
    val assumptionsSummary: String,
    val conservativeSummary: String,
    val expectedSummary: String,
    val optimisticSummary: String,
    val projectionsJson: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = FpaForecastRecord(
        id = id,
        clientId = clientId,
        reportingPeriod = reportingPeriod,
        horizonMonths = horizonMonths,
        revenueGrowthExpectedPct = revenueGrowthExpectedPct,
        cogsPctOfRevenue = cogsPctOfRevenue,
        opexGrowthPct = opexGrowthPct,
        targetDsoDays = targetDsoDays,
        monthlyFixedCosts = monthlyFixedCosts,
        breakEvenMonthlyRevenue = breakEvenMonthlyRevenue,
        assumptionsSummary = assumptionsSummary,
        conservativeSummary = conservativeSummary,
        expectedSummary = expectedSummary,
        optimisticSummary = optimisticSummary,
        projections = decodeProjectionPoints(projectionsJson),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "advisories",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class BusinessAdvisoryRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val reportingPeriod: String,
    val category: String,
    val identifiedProblem: String,
    val supportingEvidence: String,
    val businessImpact: String,
    val recommendedAction: String,
    val priority: String,
    val expectedOutcome: String,
    val relevantAssumptions: String,
    val actionStatus: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = BusinessAdvisoryItem(
        id = id,
        clientId = clientId,
        reportingPeriod = reportingPeriod,
        category = category,
        identifiedProblem = identifiedProblem,
        supportingEvidence = supportingEvidence,
        businessImpact = businessImpact,
        recommendedAction = recommendedAction,
        priority = priority,
        expectedOutcome = expectedOutcome,
        relevantAssumptions = relevantAssumptions,
        actionStatus = actionStatus,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "reports",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class CfoReportRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val clientName: String,
    val reportType: String,
    val reportTitle: String,
    val reportingPeriod: String,
    val currency: String,
    val executiveSummary: String,
    val financialObservations: String,
    val riskIdentification: String,
    val recommendationsText: String,
    val managementActionPoints: String,
    val conclusion: String,
    val reviewStatus: String,
    val cfoReviewNotes: String,
    val approvedBy: String,
    val approvedByEmail: String,
    val approvedAtLabel: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    fun toDomain() = CfoReportRecord(
        id = id,
        clientId = clientId,
        clientName = clientName,
        reportType = reportType,
        reportTitle = reportTitle,
        reportingPeriod = reportingPeriod,
        currency = currency,
        executiveSummary = executiveSummary,
        financialObservations = financialObservations,
        riskIdentification = riskIdentification,
        recommendationsText = recommendationsText,
        managementActionPoints = managementActionPoints,
        conclusion = conclusion,
        reviewStatus = reviewStatus,
        cfoReviewNotes = cfoReviewNotes,
        approvedBy = approvedBy,
        approvedByEmail = approvedByEmail,
        approvedAtLabel = approvedAtLabel,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}

@Entity(
    tableName = "audit_logs",
    foreignKeys = [
        ForeignKey(
            entity = ClientRoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class ApprovalAuditLogRoomEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val reportId: String,
    val reportTitle: String,
    val action: String,
    val actorName: String,
    val actorEmail: String,
    val notes: String,
    val createdAtMillis: Long
) {
    fun toDomain() = ApprovalAuditLog(
        id = id,
        clientId = clientId,
        reportId = reportId,
        reportTitle = reportTitle,
        action = action,
        actorName = actorName,
        actorEmail = actorEmail,
        notes = notes,
        createdAtMillis = createdAtMillis
    )
}

internal fun encodeStringList(items: List<String>): String =
    JSONArray(items).toString()

internal fun decodeStringList(raw: String): List<String> = runCatching {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { arr.optString(it) }
}.getOrDefault(emptyList())

internal fun encodeProjectionPoints(points: List<FpaProjectionPoint>): String {
    val arr = JSONArray()
    points.forEach { pt ->
        arr.put(JSONObject().apply {
            put("monthLabel", pt.monthLabel)
            put("actualCash", pt.actualCash)
            put("conservativeCash", pt.conservativeCash)
            put("expectedCash", pt.expectedCash)
            put("optimisticCash", pt.optimisticCash)
            put("expectedRevenue", pt.expectedRevenue)
            put("expectedExpense", pt.expectedExpense)
            put("budgetRevenue", pt.budgetRevenue)
            put("budgetExpense", pt.budgetExpense)
            put("forecastFlag", pt.forecastFlag)
        })
    }
    return arr.toString()
}

internal fun decodeProjectionPoints(raw: String): List<FpaProjectionPoint> = runCatching {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val obj = arr.getJSONObject(i)
        FpaProjectionPoint(
            monthLabel = obj.optString("monthLabel"),
            actualCash = obj.optDouble("actualCash", 0.0),
            conservativeCash = obj.optDouble("conservativeCash", 0.0),
            expectedCash = obj.optDouble("expectedCash", 0.0),
            optimisticCash = obj.optDouble("optimisticCash", 0.0),
            expectedRevenue = obj.optDouble("expectedRevenue", 0.0),
            expectedExpense = obj.optDouble("expectedExpense", 0.0),
            budgetRevenue = obj.optDouble("budgetRevenue", 0.0),
            budgetExpense = obj.optDouble("budgetExpense", 0.0),
            forecastFlag = obj.optBoolean("forecastFlag", true)
        )
    }
}.getOrDefault(emptyList())
