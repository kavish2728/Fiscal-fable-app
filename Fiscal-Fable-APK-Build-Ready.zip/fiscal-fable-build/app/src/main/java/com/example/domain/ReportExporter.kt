package com.example.domain

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.core.IndAsFormatter
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FpaForecastRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Generates branded Fiscal Fable CFO PDF reports (via Android PdfDocument)
 * and genuine multi-sheet OpenXML .xlsx workbooks (via ZipOutputStream).
 */
object ReportExporter {

    suspend fun exportPdfToUri(
        context: Context,
        uri: Uri,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                writePdfDocument(out, report, client, analysis)
                Result.success(Unit)
            } ?: Result.failure(IllegalStateException("Could not open PDF destination."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportExcelToUri(
        context: Context,
        uri: Uri,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?,
        forecast: FpaForecastRecord?,
        advisories: List<BusinessAdvisoryItem>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                writeXlsxWorkbook(out, report, client, analysis, forecast, advisories)
                Result.success(Unit)
            } ?: Result.failure(IllegalStateException("Could not open Excel destination."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun writePdfDocument(
        output: OutputStream,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?
    ) {
        val doc = PdfDocument()
        val pageWidth = 595 // A4 points
        val pageHeight = 842
        val margin = 42f
        val contentWidth = (pageWidth - margin * 2).toInt()

        val brandBgPaint = Paint().apply { color = Color.parseColor("#4C1D95") }
        val accentLinePaint = Paint().apply {
            color = Color.parseColor("#EDE9FE")
            strokeWidth = 1.5f
        }
        val titlePaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            isAntiAlias = true
        }
        val subBrandPaint = TextPaint().apply {
            color = Color.parseColor("#DDD6FE")
            textSize = 9.5f
            isAntiAlias = true
        }
        val headingPaint = TextPaint().apply {
            color = Color.parseColor("#3B1578")
            textSize = 13f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = TextPaint().apply {
            color = Color.parseColor("#1F1930")
            textSize = 10f
            isAntiAlias = true
        }
        val mutedPaint = TextPaint().apply {
            color = Color.parseColor("#5B5175")
            textSize = 9f
            isAntiAlias = true
        }

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas: Canvas = page.canvas

        fun drawHeader(c: Canvas, isFirst: Boolean) {
            c.drawRect(0f, 0f, pageWidth.toFloat(), if (isFirst) 86f else 54f, brandBgPaint)
            c.drawText("FISCAL FABLE CFO", margin, 28f, titlePaint)
            if (isFirst) {
                c.drawText(
                    "Financial Intelligence · Ind AS Advisory · Confidential Management Pack",
                    margin,
                    44f,
                    subBrandPaint
                )
                c.drawText(
                    "${report.clientName}  |  ${report.reportingPeriod}  |  Status: ${report.reviewStatus}",
                    margin,
                    66f,
                    subBrandPaint
                )
            } else {
                c.drawText("${report.reportTitle} — Page $pageNum", margin, 42f, subBrandPaint)
            }
        }

        fun drawFooter(c: Canvas) {
            val stamp = if (report.reviewStatus == "APPROVED") {
                "APPROVED by ${report.approvedBy} (${report.approvedAtLabel}) · Fiscal Fable AI CFO"
            } else {
                "DRAFT / UNAPPROVED — FOR INTERNAL REVIEW ONLY · Fiscal Fable AI CFO"
            }
            c.drawLine(margin, pageHeight - 40f, pageWidth - margin, pageHeight - 40f, accentLinePaint)
            c.drawText(stamp, margin, pageHeight - 24f, mutedPaint)
        }

        drawHeader(canvas, true)
        var y = 108f

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - 56f) {
                drawFooter(canvas)
                doc.finishPage(page)
                pageNum++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                drawHeader(canvas, false)
                y = 76f
            }
        }

        fun drawParagraphSection(title: String, body: String) {
            if (body.isBlank()) return
            ensureSpace(50f)
            canvas.drawText(title, margin, y, headingPaint)
            y += 8f
            val layout = StaticLayout.Builder
                .obtain(body, 0, body.length, bodyPaint, contentWidth)
                .setLineSpacing(2.5f, 1.0f)
                .build()
            if (y + layout.height > pageHeight - 56f) {
                // Split safely onto next page if tall
                ensureSpace(layout.height + 20f)
            }
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + 16f
        }

        // Report Title & Client Meta
        canvas.drawText(report.reportTitle, margin, y, headingPaint)
        y += 16f
        val meta = buildString {
            append("Report Type: ${report.reportType}\n")
            append("Entity: ${report.clientName}")
            if (client != null) {
                append(" (${client.industry} · ${client.accountingStandard} · FY: ${client.financialYear})")
            }
            append("\nReporting Period: ${report.reportingPeriod} · Currency: ${report.currency}")
        }
        drawParagraphSection("Client & Engagement Metadata", meta)

        if (analysis != null) {
            val ccy = analysis.currency
            val summaryTable = buildString {
                append("Revenue from Operations: ${IndAsFormatter.formatMoney(analysis.revenue, ccy)} | ")
                append("Gross Profit: ${IndAsFormatter.formatMoney(analysis.grossProfit, ccy)} (${IndAsFormatter.formatPct(analysis.grossMarginPct)})\n")
                append("EBITDA: ${IndAsFormatter.formatMoney(analysis.ebitda, ccy)} (${IndAsFormatter.formatPct(analysis.ebitdaMarginPct)}) | ")
                append("Net Profit (PAT): ${IndAsFormatter.formatMoney(analysis.netProfit, ccy)} (${IndAsFormatter.formatPct(analysis.netMarginPct)})\n")
                append("Current Ratio: ${IndAsFormatter.formatRatio(analysis.currentRatio)} | ")
                append("Debt-to-Equity: ${IndAsFormatter.formatRatio(analysis.debtToEquity)} | ")
                append("Cash Conversion Cycle: ${IndAsFormatter.formatDays(analysis.cashConversionCycle)}")
            }
            drawParagraphSection("Validated Ind AS Key Metrics Snapshot", summaryTable)
        }

        drawParagraphSection("1. Executive Summary", report.executiveSummary)
        drawParagraphSection("2. Key Financial Observations", report.financialObservations)
        drawParagraphSection("3. Risk Identification & Controls", report.riskIdentification)
        drawParagraphSection("4. Strategic Recommendations", report.recommendationsText)
        drawParagraphSection("5. Management Action Points", report.managementActionPoints)
        drawParagraphSection("6. CFO Conclusion", report.conclusion)

        if (report.cfoReviewNotes.isNotBlank()) {
            drawParagraphSection("CFO Review Sign-Off Notes", report.cfoReviewNotes)
        }

        drawFooter(canvas)
        doc.finishPage(page)
        doc.writeTo(output)
        doc.close()
    }

    private fun writeXlsxWorkbook(
        output: OutputStream,
        report: CfoReportRecord,
        client: ClientEntity?,
        analysis: FinancialAnalysisRecord?,
        forecast: FpaForecastRecord?,
        advisories: List<BusinessAdvisoryItem>
    ) {
        val sheets = mutableListOf<Pair<String, List<List<String>>>>()

        // Sheet 1: Executive Report
        val sheet1Rows = mutableListOf(
            listOf("FISCAL FABLE AI CFO — MANAGEMENT REPORT EXPORT"),
            listOf("Client", report.clientName),
            listOf("Industry", client?.industry ?: ""),
            listOf("Accounting Standard", client?.accountingStandard ?: "Ind AS (Schedule III)"),
            listOf("Report Title", report.reportTitle),
            listOf("Report Type", report.reportType),
            listOf("Reporting Period", report.reportingPeriod),
            listOf("Currency", report.currency),
            listOf("Approval Status", report.reviewStatus),
            listOf("Approved By", report.approvedBy),
            listOf("Approved At", report.approvedAtLabel),
            listOf(""),
            listOf("Section", "Content"),
            listOf("Executive Summary", report.executiveSummary),
            listOf("Financial Observations", report.financialObservations),
            listOf("Risk Identification", report.riskIdentification),
            listOf("Recommendations", report.recommendationsText),
            listOf("Management Action Points", report.managementActionPoints),
            listOf("Conclusion", report.conclusion)
        )
        sheets += "Executive_Summary" to sheet1Rows

        // Sheet 2: Ind AS P&L and Ratios
        if (analysis != null) {
            val sheet2Rows = listOf(
                listOf("Ind AS Financial Statement & Ratios", analysis.reportingPeriod, analysis.currency),
                listOf("Line Item / Metric", "Value", "Notes"),
                listOf("Revenue from Operations", analysis.revenue.toString(), "Ind AS 115"),
                listOf("Cost of Goods Sold", analysis.cogs.toString(), "Schedule III"),
                listOf("Gross Profit", analysis.grossProfit.toString(), "Margin: ${IndAsFormatter.formatPct(analysis.grossMarginPct)}"),
                listOf("Operating Expenses", analysis.operatingExpenses.toString(), ""),
                listOf("EBITDA", analysis.ebitda.toString(), "Margin: ${IndAsFormatter.formatPct(analysis.ebitdaMarginPct)}"),
                listOf("Depreciation & Amortisation", analysis.depreciation.toString(), "Ind AS 16 / 116"),
                listOf("EBIT", analysis.ebit.toString(), "Margin: ${IndAsFormatter.formatPct(analysis.operatingMarginPct)}"),
                listOf("Finance Costs (Interest)", analysis.interestExpense.toString(), ""),
                listOf("Profit Before Tax (PBT)", analysis.pbt.toString(), ""),
                listOf("Tax Expense", analysis.taxExpense.toString(), "Ind AS 12"),
                listOf("Net Profit (PAT)", analysis.netProfit.toString(), "Margin: ${IndAsFormatter.formatPct(analysis.netMarginPct)}"),
                listOf("Current Ratio", analysis.currentRatio.toString(), "Current Assets / Current Liabilities"),
                listOf("Quick Ratio", analysis.quickRatio.toString(), "(Current Assets - Inventory) / Current Liabilities"),
                listOf("Debt-to-Equity", analysis.debtToEquity.toString(), ""),
                listOf("Interest Coverage", analysis.interestCoverage.toString(), "EBIT / Interest"),
                listOf("ROA %", analysis.roaPct.toString(), "Annualized"),
                listOf("ROE %", analysis.roePct.toString(), "Annualized"),
                listOf("Receivable Days (DSO)", analysis.receivableDays.toString(), ""),
                listOf("Inventory Days (DIO)", analysis.inventoryDays.toString(), ""),
                listOf("Payable Days (DPO)", analysis.payableDays.toString(), ""),
                listOf("Cash Conversion Cycle", analysis.cashConversionCycle.toString(), "DSO + DIO - DPO"),
                listOf("Net Working Capital", analysis.workingCapital.toString(), "")
            )
            sheets += "IndAS_Analysis" to sheet2Rows
        }

        // Sheet 3: FP&A Forecast
        if (forecast != null) {
            val rows = mutableListOf(
                listOf("FP&A 3-Scenario Forecast", forecast.reportingPeriod, "Break-Even Monthly Rev: ${forecast.breakEvenMonthlyRevenue}"),
                listOf("Month", "Type", "Actual Cash", "Conservative Cash", "Expected Cash", "Optimistic Cash", "Expected Revenue", "Expected Expense")
            )
            forecast.parsedProjections().forEach { p ->
                rows += listOf(
                    p.monthLabel,
                    if (p.forecastFlag) "FORECAST" else "ACTUAL",
                    p.actualCash.toString(),
                    p.conservativeCash.toString(),
                    p.expectedCash.toString(),
                    p.optimisticCash.toString(),
                    p.expectedRevenue.toString(),
                    p.expectedExpense.toString()
                )
            }
            sheets += "FPA_Forecast" to rows
        }

        // Sheet 4: Business Advisory
        if (advisories.isNotEmpty()) {
            val rows = mutableListOf(
                listOf("Priority", "Category", "Problem", "Supporting Evidence", "Business Impact", "Recommended Action", "Expected Outcome", "Assumptions", "Status")
            )
            advisories.forEach { a ->
                rows += listOf(
                    a.priority, a.category, a.identifiedProblem, a.supportingEvidence,
                    a.businessImpact, a.recommendedAction, a.expectedOutcome,
                    a.relevantAssumptions, a.actionStatus
                )
            }
            sheets += "Business_Advisory" to rows
        }

        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("[Content_Types].xml"))
            zip.write(buildContentTypesXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("_rels/.rels"))
            zip.write(ROOT_RELS_XML.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("xl/workbook.xml"))
            zip.write(buildWorkbookXml(sheets.map { it.first }).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zip.write(buildWorkbookRelsXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            sheets.forEachIndexed { idx, (_, rows) ->
                zip.putNextEntry(ZipEntry("xl/worksheets/sheet${idx + 1}.xml"))
                zip.write(buildWorksheetXml(rows).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
    }

    private fun xmlEscape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun colLetter(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + (n % 26)))
            n = (n / 26) - 1
        }
        return sb.toString()
    }

    private fun buildWorksheetXml(rows: List<List<String>>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
        rows.forEachIndexed { rIdx, cols ->
            sb.append("""<row r="${rIdx + 1}">""")
            cols.forEachIndexed { cIdx, value ->
                val ref = "${colLetter(cIdx)}${rIdx + 1}"
                val asNum = value.toDoubleOrNull()
                if (asNum != null && value.isNotBlank() && !value.startsWith("0") || value == "0" || value == "0.0") {
                    sb.append("""<c r="$ref"><v>$asNum</v></c>""")
                } else {
                    sb.append("""<c r="$ref" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>""")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun buildContentTypesXml(sheetCount: Int): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        append("""<Default Extension="xml" ContentType="application/xml"/>""")
        append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        for (i in 1..sheetCount) {
            append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        append("</Types>")
    }

    private fun buildWorkbookXml(names: List<String>): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
        names.forEachIndexed { idx, name ->
            append("""<sheet name="${xmlEscape(name.take(31))}" sheetId="${idx + 1}" r:id="rId${idx + 1}"/>""")
        }
        append("</sheets></workbook>")
    }

    private fun buildWorkbookRelsXml(sheetCount: Int): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..sheetCount) {
            append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
        }
        append("</Relationships>")
    }

    private const val ROOT_RELS_XML =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
}
