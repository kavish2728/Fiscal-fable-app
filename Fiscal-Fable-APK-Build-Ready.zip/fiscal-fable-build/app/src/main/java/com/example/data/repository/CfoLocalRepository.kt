package com.example.data.repository

import com.example.data.local.ApprovalAuditLogRoomEntity
import com.example.data.local.BusinessAdvisoryRoomEntity
import com.example.data.local.CfoDao
import com.example.data.local.CfoProfileRoomEntity
import com.example.data.local.CfoReportRoomEntity
import com.example.data.local.ClientRoomEntity
import com.example.data.local.ExtractedFigureRoomEntity
import com.example.data.local.FinancialAnalysisRoomEntity
import com.example.data.local.FinancialDocumentRoomEntity
import com.example.data.local.FpaForecastRoomEntity
import com.example.data.local.encodeProjectionPoints
import com.example.data.local.encodeStringList
import com.example.data.model.ApprovalAuditLog
import com.example.data.model.BusinessAdvisoryItem
import com.example.data.model.CfoProfile
import com.example.data.model.CfoReportRecord
import com.example.data.model.ClientEntity
import com.example.data.model.ExtractedFigure
import com.example.data.model.FinancialAnalysisRecord
import com.example.data.model.FinancialDocument
import com.example.data.model.FpaForecastRecord
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class CfoLocalRepository(
    private val dao: CfoDao
) {
    private fun newId(): String = UUID.randomUUID().toString()

    fun observeProfile(): Flow<CfoProfile> =
        dao.observeProfile().map { it?.toDomain() ?: CfoProfile() }

    suspend fun saveProfile(profile: CfoProfile): Result<Unit> = runCatchingSafe {
        dao.upsertProfile(
            CfoProfileRoomEntity(
                id = 1,
                partnerName = profile.partnerName.trim().ifBlank { "Managing CFO Partner" },
                partnerTitle = profile.partnerTitle.trim().ifBlank { "Virtual CFO · Ind AS Practice" },
                preferLakhsCrores = profile.preferLakhsCrores
            )
        )
    }

    fun observeClients(): Flow<List<ClientEntity>> =
        dao.observeClients().map { list -> list.map { it.toDomain() } }

    fun observeDocuments(clientId: String): Flow<List<FinancialDocument>> =
        dao.observeDocuments(clientId).map { list -> list.map { it.toDomain() } }

    fun observeExtractedFigures(clientId: String): Flow<List<ExtractedFigure>> =
        dao.observeExtractedFigures(clientId).map { list -> list.map { it.toDomain() } }

    fun observeAnalyses(clientId: String): Flow<List<FinancialAnalysisRecord>> =
        dao.observeAnalyses(clientId).map { list -> list.map { it.toDomain() } }

    fun observeForecasts(clientId: String): Flow<List<FpaForecastRecord>> =
        dao.observeForecasts(clientId).map { list -> list.map { it.toDomain() } }

    fun observeAdvisories(clientId: String): Flow<List<BusinessAdvisoryItem>> =
        dao.observeAdvisories(clientId).map { list -> list.map { it.toDomain() } }

    fun observeReports(clientId: String): Flow<List<CfoReportRecord>> =
        dao.observeReports(clientId).map { list -> list.map { it.toDomain() } }

    fun observeAuditLogs(clientId: String): Flow<List<ApprovalAuditLog>> =
        dao.observeAuditLogs(clientId).map { list -> list.map { it.toDomain() } }

    suspend fun createClient(client: ClientEntity): Result<String> = runCatchingSafe {
        val name = client.companyName.trim()
        require(name.length in 2..120) { "Company name must be 2–120 characters." }
        val now = System.currentTimeMillis()
        val id = newId()
        dao.insertClient(
            ClientRoomEntity(
                id = id,
                companyName = name.take(120),
                industry = client.industry.trim().ifBlank { "Services" }.take(80),
                country = client.country.trim().ifBlank { "India" }.take(60),
                currency = client.currency.trim().ifBlank { "INR" }.take(10),
                financialYear = client.financialYear.trim().ifBlank { "FY 2025-26" }.take(24),
                accountingPeriod = client.accountingPeriod.trim().ifBlank { "Q2 (Jul-Sep 2025)" }.take(48),
                accountingStandard = client.accountingStandard.trim().ifBlank { "Ind AS (Schedule III)" }.take(60),
                businessProfile = client.businessProfile.trim().take(1200),
                contactName = client.contactName.trim().take(100),
                contactEmail = client.contactEmail.trim().take(120),
                contactPhone = client.contactPhone.trim().take(40),
                status = client.status.ifBlank { "ACTIVE" },
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )
        id
    }

    suspend fun updateClient(client: ClientEntity): Result<Unit> = runCatchingSafe {
        require(client.id.isNotBlank()) { "Client ID required." }
        val now = System.currentTimeMillis()
        dao.updateClient(
            ClientRoomEntity(
                id = client.id,
                companyName = client.companyName.trim().take(120),
                industry = client.industry.trim().take(80),
                country = client.country.trim().take(60),
                currency = client.currency.trim().take(10),
                financialYear = client.financialYear.trim().take(24),
                accountingPeriod = client.accountingPeriod.trim().take(48),
                accountingStandard = client.accountingStandard.trim().take(60),
                businessProfile = client.businessProfile.trim().take(1200),
                contactName = client.contactName.trim().take(100),
                contactEmail = client.contactEmail.trim().take(120),
                contactPhone = client.contactPhone.trim().take(40),
                status = client.status,
                createdAtMillis = if (client.createdAtMillis > 0L) client.createdAtMillis else now,
                updatedAtMillis = now
            )
        )
    }

    suspend fun saveDocumentAndFigures(
        clientId: String,
        doc: FinancialDocument,
        figures: List<ExtractedFigure>
    ): Result<String> = runCatchingSafe {
        require(clientId.isNotBlank()) { "Client ID is required." }
        val now = System.currentTimeMillis()
        val docId = newId()
        val docEntity = FinancialDocumentRoomEntity(
            id = docId,
            clientId = clientId,
            fileName = doc.fileName.take(180),
            mimeType = doc.mimeType.take(120),
            documentType = doc.documentType,
            reportingPeriod = doc.reportingPeriod.take(50),
            currency = doc.currency.take(10),
            unitScale = doc.unitScale,
            extractionStatus = doc.extractionStatus,
            ocrUsed = doc.ocrUsed,
            pageCount = doc.pageCount.coerceIn(0L, 500L),
            sourceSummary = doc.sourceSummary.take(2500),
            missingFieldsNote = doc.missingFieldsNote.take(1200),
            createdAtMillis = now,
            updatedAtMillis = now
        )
        val figureEntities = figures.map { fig ->
            ExtractedFigureRoomEntity(
                id = newId(),
                clientId = clientId,
                documentId = docId,
                documentName = doc.fileName.take(180),
                reportingPeriod = fig.reportingPeriod.ifBlank { doc.reportingPeriod }.take(50),
                statementCategory = fig.statementCategory,
                fieldKey = fig.fieldKey.take(80),
                label = fig.label.take(140),
                indAsReference = fig.indAsReference.take(100),
                amount = fig.amount,
                currency = fig.currency.ifBlank { doc.currency }.take(10),
                sourceCitation = fig.sourceCitation.ifBlank { doc.fileName }.take(180),
                confidence = fig.confidence,
                ambiguityNote = fig.ambiguityNote.take(500),
                validated = fig.validated,
                validatedBy = fig.validatedBy.take(120),
                createdAtMillis = now,
                updatedAtMillis = now
            )
        }
        dao.saveDocumentWithFigures(docEntity, figureEntities)
        docId
    }

    suspend fun updateExtractedFigure(
        clientId: String,
        figureId: String,
        amount: Double,
        label: String,
        validated: Boolean,
        validatedBy: String
    ): Result<Unit> = runCatchingSafe {
        dao.updateFigureValidation(
            clientId = clientId,
            figureId = figureId,
            amount = amount,
            label = label.trim().take(140),
            validated = validated,
            validatedBy = validatedBy.trim().take(120),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun validateAllFigures(
        clientId: String,
        figureIds: List<String>,
        documentIds: List<String>,
        validatedBy: String
    ): Result<Unit> = runCatchingSafe {
        dao.validateFiguresAndDocuments(
            clientId = clientId,
            figureIds = figureIds,
            documentIds = documentIds,
            validatedBy = validatedBy.trim().take(120),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun saveAnalysis(clientId: String, record: FinancialAnalysisRecord): Result<String> = runCatchingSafe {
        val id = newId()
        val now = System.currentTimeMillis()
        dao.insertAnalysis(
            FinancialAnalysisRoomEntity(
                id = id,
                clientId = clientId,
                reportingPeriod = record.reportingPeriod.take(50),
                currency = record.currency.take(10),
                revenue = record.revenue,
                cogs = record.cogs,
                grossProfit = record.grossProfit,
                operatingExpenses = record.operatingExpenses,
                ebitda = record.ebitda,
                depreciation = record.depreciation,
                ebit = record.ebit,
                interestExpense = record.interestExpense,
                pbt = record.pbt,
                taxExpense = record.taxExpense,
                netProfit = record.netProfit,
                totalAssets = record.totalAssets,
                currentAssets = record.currentAssets,
                inventory = record.inventory,
                tradeReceivables = record.tradeReceivables,
                cashAndEquivalents = record.cashAndEquivalents,
                totalEquity = record.totalEquity,
                totalDebt = record.totalDebt,
                currentLiabilities = record.currentLiabilities,
                tradePayables = record.tradePayables,
                operatingCashFlow = record.operatingCashFlow,
                investingCashFlow = record.investingCashFlow,
                financingCashFlow = record.financingCashFlow,
                grossMarginPct = record.grossMarginPct,
                ebitdaMarginPct = record.ebitdaMarginPct,
                operatingMarginPct = record.operatingMarginPct,
                netMarginPct = record.netMarginPct,
                currentRatio = record.currentRatio,
                quickRatio = record.quickRatio,
                debtToEquity = record.debtToEquity,
                interestCoverage = record.interestCoverage,
                roaPct = record.roaPct,
                roePct = record.roePct,
                receivableDays = record.receivableDays,
                inventoryDays = record.inventoryDays,
                payableDays = record.payableDays,
                cashConversionCycle = record.cashConversionCycle,
                workingCapital = record.workingCapital,
                profitabilityScore = record.profitabilityScore.coerceIn(0L, 100L),
                liquidityScore = record.liquidityScore.coerceIn(0L, 100L),
                solvencyScore = record.solvencyScore.coerceIn(0L, 100L),
                efficiencyScore = record.efficiencyScore.coerceIn(0L, 100L),
                stabilityScore = record.stabilityScore.coerceIn(0L, 100L),
                executiveSummary = record.executiveSummary.ifBlank { "Ind AS Analysis complete." }.take(5000),
                trendCommentary = record.trendCommentary.take(5000),
                unusualMovementsJson = encodeStringList(record.unusualMovements.take(20)),
                indAsNotesJson = encodeStringList(record.indAsNotes.take(20)),
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )
        id
    }

    suspend fun saveForecast(clientId: String, forecast: FpaForecastRecord): Result<String> = runCatchingSafe {
        val id = newId()
        val now = System.currentTimeMillis()
        dao.insertForecast(
            FpaForecastRoomEntity(
                id = id,
                clientId = clientId,
                reportingPeriod = forecast.reportingPeriod.take(50),
                horizonMonths = forecast.horizonMonths.coerceIn(1L, 36L),
                revenueGrowthExpectedPct = forecast.revenueGrowthExpectedPct,
                cogsPctOfRevenue = forecast.cogsPctOfRevenue,
                opexGrowthPct = forecast.opexGrowthPct,
                targetDsoDays = forecast.targetDsoDays,
                monthlyFixedCosts = forecast.monthlyFixedCosts,
                breakEvenMonthlyRevenue = forecast.breakEvenMonthlyRevenue,
                assumptionsSummary = forecast.assumptionsSummary.ifBlank { "FP&A forecast generated." }.take(3000),
                conservativeSummary = forecast.conservativeSummary.take(2500),
                expectedSummary = forecast.expectedSummary.take(2500),
                optimisticSummary = forecast.optimisticSummary.take(2500),
                projectionsJson = encodeProjectionPoints(forecast.projections.take(36)),
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )
        id
    }

    suspend fun saveAdvisories(clientId: String, items: List<BusinessAdvisoryItem>): Result<Unit> = runCatchingSafe {
        val now = System.currentTimeMillis()
        val entities = items.map { item ->
            BusinessAdvisoryRoomEntity(
                id = newId(),
                clientId = clientId,
                reportingPeriod = item.reportingPeriod.take(50),
                category = item.category,
                identifiedProblem = item.identifiedProblem.take(1000),
                supportingEvidence = item.supportingEvidence.take(1200),
                businessImpact = item.businessImpact.take(1000),
                recommendedAction = item.recommendedAction.take(1200),
                priority = item.priority,
                expectedOutcome = item.expectedOutcome.take(1000),
                relevantAssumptions = item.relevantAssumptions.take(1000),
                actionStatus = item.actionStatus,
                createdAtMillis = now,
                updatedAtMillis = now
            )
        }
        dao.insertAdvisories(entities)
    }

    suspend fun updateAdvisoryStatus(
        clientId: String,
        advisoryId: String,
        newStatus: String
    ): Result<Unit> = runCatchingSafe {
        dao.updateAdvisoryStatus(clientId, advisoryId, newStatus, System.currentTimeMillis())
    }

    suspend fun createReport(
        clientId: String,
        report: CfoReportRecord,
        actorName: String,
        actorRoleLabel: String
    ): Result<String> = runCatchingSafe {
        val reportId = newId()
        val now = System.currentTimeMillis()
        val repEntity = CfoReportRoomEntity(
            id = reportId,
            clientId = clientId,
            clientName = report.clientName.take(120),
            reportType = report.reportType.take(80),
            reportTitle = report.reportTitle.take(160),
            reportingPeriod = report.reportingPeriod.take(50),
            currency = report.currency.take(10),
            executiveSummary = report.executiveSummary.ifBlank { "Summary pending." }.take(6000),
            financialObservations = report.financialObservations.take(6000),
            riskIdentification = report.riskIdentification.take(6000),
            recommendationsText = report.recommendationsText.take(6000),
            managementActionPoints = report.managementActionPoints.take(6000),
            conclusion = report.conclusion.take(4000),
            reviewStatus = "DRAFT",
            cfoReviewNotes = "",
            approvedBy = "",
            approvedByEmail = "",
            approvedAtLabel = "",
            createdAtMillis = now,
            updatedAtMillis = now
        )
        val logEntity = ApprovalAuditLogRoomEntity(
            id = newId(),
            clientId = clientId,
            reportId = reportId,
            reportTitle = report.reportTitle.take(160),
            action = "GENERATED",
            actorName = actorName.ifBlank { "Managing CFO Partner" }.take(120),
            actorEmail = actorRoleLabel.ifBlank { "On-Device CFO" }.take(120),
            notes = "Generated ${report.reportType} draft for review.",
            createdAtMillis = now
        )
        dao.createReportWithAudit(repEntity, logEntity)
        reportId
    }

    suspend fun updateReportDraft(
        clientId: String,
        report: CfoReportRecord,
        newStatus: String,
        actionLabel: String,
        actorName: String,
        actorRoleLabel: String,
        auditNotes: String
    ): Result<Unit> = runCatchingSafe {
        val existing = dao.getReportById(clientId, report.id)
            ?: throw IllegalStateException("Report not found.")
        if (existing.reviewStatus == "APPROVED") {
            throw IllegalStateException("Approved reports are permanently locked and cannot be edited.")
        }
        val now = System.currentTimeMillis()
        val updated = existing.copy(
            reportTitle = report.reportTitle.take(160),
            executiveSummary = report.executiveSummary.take(6000),
            financialObservations = report.financialObservations.take(6000),
            riskIdentification = report.riskIdentification.take(6000),
            recommendationsText = report.recommendationsText.take(6000),
            managementActionPoints = report.managementActionPoints.take(6000),
            conclusion = report.conclusion.take(4000),
            reviewStatus = newStatus,
            cfoReviewNotes = report.cfoReviewNotes.take(2000),
            updatedAtMillis = now
        )
        val log = ApprovalAuditLogRoomEntity(
            id = newId(),
            clientId = clientId,
            reportId = report.id,
            reportTitle = report.reportTitle.take(160),
            action = actionLabel,
            actorName = actorName.ifBlank { "Managing CFO Partner" }.take(120),
            actorEmail = actorRoleLabel.ifBlank { "On-Device CFO" }.take(120),
            notes = auditNotes.take(1000),
            createdAtMillis = now
        )
        dao.updateReportWithAudit(updated, log)
    }

    suspend fun approveReport(
        clientId: String,
        report: CfoReportRecord,
        approverName: String,
        approverRoleLabel: String,
        approvedAtLabel: String,
        reviewNotes: String
    ): Result<Unit> = runCatchingSafe {
        val existing = dao.getReportById(clientId, report.id)
            ?: throw IllegalStateException("Report not found.")
        if (existing.reviewStatus == "APPROVED") {
            throw IllegalStateException("Report is already approved and locked.")
        }
        val now = System.currentTimeMillis()
        val safeName = approverName.ifBlank { "Managing CFO Partner" }.take(120)
        val safeRole = approverRoleLabel.ifBlank { "On-Device CFO" }.take(120)
        val updated = existing.copy(
            reviewStatus = "APPROVED",
            cfoReviewNotes = reviewNotes.take(2000),
            approvedBy = safeName,
            approvedByEmail = safeRole,
            approvedAtLabel = approvedAtLabel.take(80),
            updatedAtMillis = now
        )
        val log = ApprovalAuditLogRoomEntity(
            id = newId(),
            clientId = clientId,
            reportId = report.id,
            reportTitle = report.reportTitle.take(160),
            action = "APPROVED",
            actorName = safeName,
            actorEmail = safeRole,
            notes = reviewNotes.ifBlank { "Approved for final client delivery." }.take(1000),
            createdAtMillis = now
        )
        dao.updateReportWithAudit(updated, log)
    }

    suspend fun logExportAudit(
        clientId: String,
        report: CfoReportRecord,
        action: String,
        actorName: String,
        actorRoleLabel: String
    ): Result<Unit> = runCatchingSafe {
        dao.insertAuditLog(
            ApprovalAuditLogRoomEntity(
                id = newId(),
                clientId = clientId,
                reportId = report.id,
                reportTitle = report.reportTitle.take(160),
                action = action,
                actorName = actorName.ifBlank { "Managing CFO Partner" }.take(120),
                actorEmail = actorRoleLabel.ifBlank { "On-Device CFO" }.take(120),
                notes = "Exported approved report ($action).",
                createdAtMillis = System.currentTimeMillis()
            )
        )
    }

    private suspend inline fun <T> runCatchingSafe(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }
}
