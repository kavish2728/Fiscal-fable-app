package com.example

import com.example.core.IndAsFormatter
import com.example.data.model.ExtractedFigure
import com.example.domain.FinancialCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun deterministicIndAsCalculations_ignoreUnvalidatedFigures() {
        val figures = listOf(
            ExtractedFigure(fieldKey = "revenue", amount = 10_000_000.0, validated = true),
            ExtractedFigure(fieldKey = "cogs", amount = 6_000_000.0, validated = true),
            ExtractedFigure(fieldKey = "operating_expenses", amount = 2_000_000.0, validated = true),
            ExtractedFigure(fieldKey = "depreciation", amount = 200_000.0, validated = true),
            ExtractedFigure(fieldKey = "interest_expense", amount = 100_000.0, validated = true),
            ExtractedFigure(fieldKey = "tax_expense", amount = 400_000.0, validated = true),
            ExtractedFigure(fieldKey = "trade_receivables", amount = 1_500_000.0, validated = true),
            ExtractedFigure(fieldKey = "inventory", amount = 1_000_000.0, validated = true),
            ExtractedFigure(fieldKey = "trade_payables", amount = 800_000.0, validated = true),
            ExtractedFigure(fieldKey = "current_assets", amount = 3_500_000.0, validated = true),
            ExtractedFigure(fieldKey = "current_liabilities", amount = 1_750_000.0, validated = true),
            // Unvalidated figure must be excluded
            ExtractedFigure(fieldKey = "revenue", amount = 99_000_000.0, validated = false)
        )

        val m = FinancialCalculator.computeFromValidatedFigures(figures, periodDays = 365.0)
        assertEquals(10_000_000.0, m.revenue, 0.01)
        assertEquals(4_000_000.0, m.grossProfit, 0.01)
        assertEquals(40.0, m.grossMarginPct, 0.01)
        assertEquals(2_000_000.0, m.ebitda, 0.01)
        assertEquals(1_800_000.0, m.ebit, 0.01)
        assertEquals(1_300_000.0, m.netProfit, 0.01)
        assertEquals(2.0, m.currentRatio, 0.01)
        assertEquals(17.0, m.interestCoverage - 1.0, 0.01) // 1.8M / 0.1M = 18.0
    }

    @Test
    fun indAsFormatter_formatsCroresAndLakhs() {
        assertEquals("₹1.50 Cr", IndAsFormatter.formatMoney(15_000_000.0, "INR", true))
        assertEquals("₹4.50 L", IndAsFormatter.formatMoney(450_000.0, "INR", true))
    }
}
